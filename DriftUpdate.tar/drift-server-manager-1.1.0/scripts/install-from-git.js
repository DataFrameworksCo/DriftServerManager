#!/usr/bin/env node
'use strict';
/**
 * One-shot install after git clone: dependencies, CLI shims, ready for web + TUI.
 * Called by ./install.sh, install.cmd, or: npm run install:git
 */

const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');

function runNpm(args) {
  const r = spawnSync('npm', args, {
    cwd: root,
    stdio: 'inherit',
    env: process.env,
    shell: process.platform === 'win32',
  });
  if (r.status !== 0) process.exit(r.status || 1);
}

const major = parseInt(String(process.version).replace(/^v(\d+).*/, '$1'), 10);
if (!major || major < 14) {
  console.error('[drift] Need Node.js 14 or newer. This is:', process.version);
  process.exit(1);
}

try {
  process.chdir(root);
} catch (e) {
  console.error('[drift]', e.message);
  process.exit(1);
}

console.log('[drift] Installing Drift Server Manager into:\n  ' + root + '\n');

const lock = path.join(root, 'package-lock.json');
const preferCi = process.env.DRIFT_INSTALL_USE_CI === '1' || process.argv.includes('--ci');
if (preferCi && fs.existsSync(lock)) {
  console.log('[drift] npm ci (from package-lock.json)…\n');
  runNpm(['ci', '--no-fund', '--no-audit']);
} else {
  console.log('[drift] npm install…\n');
  runNpm(['install', '--no-fund', '--no-audit']);
}

if (process.platform !== 'win32') {
  const launcher = path.join(root, 'drift-update');
  try {
    if (fs.existsSync(launcher)) fs.chmodSync(launcher, 0o755);
  } catch (_) {}
}

console.log(`
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Drift is ready — terminal (TUI) + web UI in this install
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Web dashboard     npm run web
                    → http://localhost:7473  (set password in Settings)

  Terminal file UI npm start

  Config editor    npm run drift-config

  Check updates    drift-update
                   (also: npm run drift-update)

Optional — same commands in every new terminal:
  cd ${root.replace(/\\/g, '/')}
  npm install -g .

Updates (drift-update) use only what you configure: git in this folder,
package.json repository / driftUpdate.tarballUrl, DRIFT_UPDATE_URL, or npm.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`);
