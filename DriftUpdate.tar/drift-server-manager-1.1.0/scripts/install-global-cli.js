'use strict';
/**
 * Installs `drift-update` into ~/.local/bin so it works from any directory.
 * Runs from npm `postinstall`. Skip with SKIP_DRIFTCLI=1 or CI=true.
 */

const fs = require('fs');
const path = require('path');
const os = require('os');

function pathInPath(dir) {
  const norm = path.normalize(dir);
  return (process.env.PATH || '')
    .split(path.delimiter)
    .some(p => path.normalize(p) === norm);
}

function appendPathLine(home, localBin) {
  const line = `\n# Drift Server Manager — drift-update on PATH\nexport PATH="${localBin}:$PATH"\n`;
  for (const rc of ['.bashrc', '.zshrc']) {
    const p = path.join(home, rc);
    try {
      if (!fs.existsSync(p)) continue;
      const cur = fs.readFileSync(p, 'utf8');
      if (cur.includes('Drift Server Manager — drift-update')) continue;
      fs.appendFileSync(p, line, 'utf8');
      console.error(`[drift] Updated ~/${rc} — open a new terminal or: source ~/${rc}`);
      return true;
    } catch (_) {
      /* next */
    }
  }
  return false;
}

function main() {
  if (process.env.SKIP_DRIFT_CLI_LINK === '1' || process.env.SKIP_DRIFTCLI === '1') return;
  if (process.env.CI === 'true') return;

  const root = path.resolve(__dirname, '..');
  const updater = path.join(root, 'bin', 'drift-update.js');
  if (!fs.existsSync(updater)) return;

  const home = os.homedir();
  if (!home) return;

  const localBin = path.join(home, '.local', 'bin');
  fs.mkdirSync(localBin, { recursive: true });

  const qr = JSON.stringify(root);
  const qu = JSON.stringify(updater);

  if (process.platform === 'win32') {
    const bat = path.join(localBin, 'drift-update.cmd');
    const body = `@echo off\r\nset "DRIFT_INSTALL_DIR=${root}"\r\nnode "${path.join(root, 'bin', 'drift-update.js')}" %*\r\n`;
    fs.writeFileSync(bat, body, 'utf8');
  } else {
    const shim = `#!/usr/bin/env sh
# drift-server-manager — drift-update (npm postinstall)
export DRIFT_INSTALL_DIR=${qr}
exec node ${qu} "$@"
`;
    const target = path.join(localBin, 'drift-update');
    fs.writeFileSync(target, shim, 'utf8');
    try {
      fs.chmodSync(target, 0o755);
    } catch (_) {}
  }

  const onPath = pathInPath(localBin);
  if (!onPath && process.platform !== 'win32') {
    appendPathLine(home, localBin);
  }

  if (!pathInPath(localBin)) {
    console.error('[drift] drift-update is installed at: ' + localBin);
    console.error('[drift] If the command is not found, add that folder to your PATH (see message above or Settings in your OS).');
  }
}

main();
