#!/usr/bin/env node
'use strict';
/**
 * Builds DriftUpdate.tar — same layout drift-update expects (one top-level folder with package.json).
 * Run: npm run release:tar
 * Output: project root / DriftUpdate.tar  (and DriftUpdate.tar.gz for smaller uploads)
 */

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const root = path.resolve(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const ver = pkg.version || '0.0.0';
const folderName = `drift-server-manager-${ver}`;

const include = [
  'bin',
  'src',
  'scripts',
  'package.json',
  'package-lock.json',
  'drift-update',
  'drift-update.cmd',
  'install.sh',
  'install.cmd',
  'README.md',
  '.gitignore',
];

const staging = path.join(root, '.release-staging');
const inner = path.join(staging, folderName);

function main() {
  try {
    execFileSync('tar', ['--version'], { stdio: 'pipe' });
  } catch {
    console.error('Need the tar command to build the release archive.');
    process.exit(1);
  }

  fs.rmSync(staging, { recursive: true, force: true });
  fs.mkdirSync(inner, { recursive: true });

  for (const name of include) {
    const src = path.join(root, name);
    if (!fs.existsSync(src)) continue;
    const dest = path.join(inner, name);
    const st = fs.statSync(src);
    if (st.isDirectory()) {
      fs.cpSync(src, dest, { recursive: true, dereference: true });
    } else {
      fs.copyFileSync(src, dest);
    }
  }

  const tarOut = path.join(root, 'DriftUpdate.tar');
  const tgzOut = path.join(root, 'DriftUpdate.tar.gz');

  for (const p of [tarOut, tgzOut]) {
    try {
      fs.unlinkSync(p);
    } catch (_) {}
  }

  execFileSync('tar', ['-cf', tarOut, '-C', staging, folderName], { stdio: 'inherit' });
  execFileSync('tar', ['-czf', tgzOut, '-C', staging, folderName], { stdio: 'inherit' });

  const sz = fs.statSync(tarOut).size;
  const szGz = fs.statSync(tgzOut).size;
  console.log(`\n[drift] Wrote ${tarOut} (${(sz / 1024 / 1024).toFixed(2)} MiB)`);
  console.log(`[drift] Wrote ${tgzOut} (${(szGz / 1024 / 1024).toFixed(2)} MiB) — use for GitHub Releases or drift-update /path/to/DriftUpdate.tar.gz`);

  fs.rmSync(staging, { recursive: true, force: true });
}

main();
