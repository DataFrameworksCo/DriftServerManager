'use strict';
/**
 * Run once from the package root if you have a full tree but no .git folder.
 * Uses package.json "repository.url" (you must set it to your own remote).
 */

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const root = path.resolve(__dirname, '..');
const gitDir = path.join(root, '.git');

function repoUrlFromPackage() {
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  const r = pkg.repository;
  const u = typeof r === 'string' ? r : r && r.url;
  if (!u) {
    console.error(
      '[drift] Add a repository URL to package.json first, for example:\n' +
        '  "repository": { "type": "git", "url": "git+https://github.com/YOU/your-repo.git" }\n',
    );
    process.exit(1);
  }
  return u.replace(/^git\+/, '');
}

function run(args, opts = {}) {
  const r = spawnSync('git', args, { cwd: root, stdio: 'inherit', ...opts });
  return r.status === 0;
}

const url = repoUrlFromPackage();
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const branch = (pkg.driftUpdate && pkg.driftUpdate.branch) || 'main';

if (fs.existsSync(gitDir)) {
  console.log('[drift] This folder is already a git repository:\n  ' + root + '\n');
  spawnSync('git', ['remote', '-v'], { cwd: root, stdio: 'inherit' });
  process.exit(0);
}

console.log('[drift] Initializing git and linking origin:\n  ' + url + '\n');
if (!run(['init'])) process.exit(1);
if (!run(['remote', 'add', 'origin', url])) {
  run(['remote', 'set-url', 'origin', url]);
}

console.log('\n[drift] Fetching from origin…');
run(['fetch', 'origin']);

const okRemote = spawnSync('git', ['rev-parse', '--verify', `origin/${branch}`], { cwd: root });
if (okRemote.status === 0) {
  console.log(`
[drift] Remote branch origin/${branch} exists.

  If this PC should MATCH the remote exactly (tracked local changes may be reset):
    cd ${root}
    git checkout -B ${branch} origin/${branch}

  If the remote is empty and THIS folder is the source of truth, publish it:
    cd ${root}
    git add -A
    git commit -m "Drift Server Manager"
    git branch -M ${branch}
    git push -u origin ${branch}
`);
} else {
  console.log(`
[drift] Could not find origin/${branch} after fetch (new repo or network).

  Publish this folder to your remote:
    cd ${root}
    git add -A
    git commit -m "Drift Server Manager"
    git branch -M ${branch}
    git push -u origin ${branch}
`);
}
