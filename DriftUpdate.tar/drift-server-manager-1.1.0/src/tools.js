'use strict';

const os   = require('os');
const fs   = require('fs');
const path = require('path');
const { exec } = require('child_process');
const dns  = require('dns');
const http = require('http');
const https = require('https');

// ─── Tool catalogue ───────────────────────────────────────────────────────────

const TOOLS = [
  {
    category: '  System Monitor',
    items: [
      { id: 'sysinfo',    label: 'System Info',       description: 'OS, CPU model, uptime, hostname' },
      { id: 'cpu',        label: 'CPU Usage',          description: 'Load averages + per-core usage', autoRefresh: 3000 },
      { id: 'memory',     label: 'Memory Usage',       description: 'RAM usage with usage bar',        autoRefresh: 3000 },
      { id: 'disk',       label: 'Disk Usage',         description: 'Filesystem usage (df -h)' },
      { id: 'processes',  label: 'Top Processes',      description: 'Top CPU/memory processes',        autoRefresh: 5000 },
    ],
  },
  {
    category: '  Network',
    items: [
      { id: 'interfaces',  label: 'Network Interfaces', description: 'All interfaces with IP and MAC' },
      { id: 'ports',       label: 'Listening Ports',    description: 'Open TCP/UDP ports (ss -tulnp)' },
      { id: 'connections', label: 'Active Connections', description: 'Established TCP connections' },
      { id: 'ping',        label: 'Ping',               description: 'Ping a host (4 packets)',         prompt: 'Host (e.g. google.com)' },
      { id: 'dns',         label: 'DNS Lookup',         description: 'Resolve domain → A/MX records',  prompt: 'Domain name' },
      { id: 'http',        label: 'HTTP Check',         description: 'Check status code + headers',    prompt: 'URL (e.g. https://example.com)' },
      { id: 'traceroute',  label: 'Traceroute',         description: 'Trace route to host',            prompt: 'Host' },
    ],
  },
  {
    category: '  Dev Tools',
    items: [
      { id: 'run',         label: 'Run Command',        description: 'Run any shell command',          prompt: 'Command' },
      { id: 'git-status',  label: 'Git Status',         description: 'git status in current directory' },
      { id: 'git-log',     label: 'Git Log',            description: 'Last 20 commits (graph)' },
      { id: 'git-diff',    label: 'Git Diff',           description: 'Unstaged changes (--stat)' },
      { id: 'git-branch',  label: 'Git Branches',       description: 'All local and remote branches' },
      { id: 'versions',    label: 'Runtime Versions',   description: 'Node, npm, Python, Go, Rust…' },
      { id: 'env',         label: 'Environment Vars',   description: 'Current process environment' },
      { id: 'which',       label: 'Which',              description: 'Find command in PATH',           prompt: 'Command name' },
      { id: 'pathlist',    label: 'PATH Entries',       description: 'All directories in $PATH' },
    ],
  },
  {
    category: '  Snippets',
    items: [
      { id: 'run-selected', label: 'Run Selected File',  description: 'Auto-detect interpreter and run selected file' },
      { id: 'run-node',     label: 'Run with Node.js',   description: 'node <file>',   prompt: 'Script path (blank = selected file)' },
      { id: 'run-python',   label: 'Run with Python 3',  description: 'python3 <file>', prompt: 'Script path (blank = selected file)' },
      { id: 'run-bash',     label: 'Run with Bash',      description: 'bash <file>',    prompt: 'Script path (blank = selected file)' },
      { id: 'run-ruby',     label: 'Run with Ruby',      description: 'ruby <file>',    prompt: 'Script path (blank = selected file)' },
    ],
  },
];

// ─── Flat navigation list ─────────────────────────────────────────────────────

function flatList() {
  const rows = [];
  for (const section of TOOLS) {
    rows.push({ type: 'category', label: section.category });
    for (const item of section.items) {
      rows.push({ type: 'tool', ...item });
    }
  }
  return rows;
}

// ─── Dispatcher ───────────────────────────────────────────────────────────────

function runTool(id, arg, context) {
  const cwd        = (context && context.cwd)          || process.cwd();
  const file       = (context && context.selectedFile) || '';
  const credential = (context && context.credential)   || null;

  switch (id) {
    case 'sysinfo':    return sysInfo();
    case 'cpu':        return cpuInfo();
    case 'memory':     return memInfo();
    case 'disk':       return diskInfo();
    case 'processes':  return processes();

    case 'interfaces':  return netInterfaces();
    case 'ports':       return openPorts();
    case 'connections': return connections();
    case 'ping':        return !arg ? needArg('host') : ping(arg);
    case 'dns':         return !arg ? needArg('domain') : dnsLookup(arg);
    case 'http':        return !arg ? needArg('URL')    : httpCheck(arg);
    case 'traceroute':  return !arg ? needArg('host')   : traceroute(arg);

    case 'run':         return !arg ? needArg('command') : runCmd(arg, cwd, credential);
    case 'git-status':  return gitCmd('status', cwd);
    case 'git-log':     return gitCmd('log --oneline --graph --decorate -20', cwd);
    case 'git-diff':    return gitCmd('diff --stat', cwd);
    case 'git-branch':  return gitCmd('branch -av', cwd);
    case 'versions':    return runtimeVersions();
    case 'env':         return envVars();
    case 'which':       return !arg ? needArg('command') : whichCmd(arg);
    case 'pathlist':    return pathEntries();

    case 'run-selected': return runFile(file, cwd);
    case 'run-node':     return runFile(arg || file, cwd, 'node');
    case 'run-python':   return runFile(arg || file, cwd, 'python3');
    case 'run-bash':     return runFile(arg || file, cwd, 'bash');
    case 'run-ruby':     return runFile(arg || file, cwd, 'ruby');

    default: return Promise.resolve(fmt.header('Unknown tool: ' + id));
  }
}

function needArg(what) {
  return Promise.resolve(fmt.header('Input required') + '\n\n  Please provide a ' + what + ' (press Enter on the tool to be prompted).');
}

// ─── System Monitor ───────────────────────────────────────────────────────────

function sysInfo() {
  const cpus = os.cpus();
  const load = os.loadavg();
  return Promise.resolve([
    fmt.header('System Information'),
    '',
    fmt.row('Hostname',   os.hostname()),
    fmt.row('Platform',   os.platform()),
    fmt.row('OS Release', os.release()),
    fmt.row('Arch',       os.arch()),
    fmt.row('Uptime',     fmtUptime(os.uptime())),
    fmt.row('CPUs',       cpus.length + 'x ' + (cpus[0]?.model?.trim() || '?')),
    fmt.row('CPU Speed',  (cpus[0]?.speed || '?') + ' MHz'),
    fmt.row('Total RAM',  fmtBytes(os.totalmem())),
    fmt.row('Free RAM',   fmtBytes(os.freemem())),
    fmt.row('Home Dir',   os.homedir()),
    fmt.row('Shell',      process.env.SHELL || '?'),
    fmt.row('Node',       process.version),
    fmt.row('PID',        process.pid),
    '',
    fmt.header('Load Averages'),
    '',
    fmt.row('1 min',  load[0].toFixed(2)),
    fmt.row('5 min',  load[1].toFixed(2)),
    fmt.row('15 min', load[2].toFixed(2)),
  ].join('\n'));
}

function cpuInfo() {
  const cpus = os.cpus();
  const load = os.loadavg();
  const lines = [
    fmt.header('CPU'),
    '',
    fmt.row('Model',  cpus[0]?.model?.trim() || '?'),
    fmt.row('Cores',  cpus.length),
    fmt.row('Speed',  (cpus[0]?.speed || '?') + ' MHz'),
    '',
    fmt.header('Load Averages'),
    '',
    fmt.row('1 min',  load[0].toFixed(2)),
    fmt.row('5 min',  load[1].toFixed(2)),
    fmt.row('15 min', load[2].toFixed(2)),
    '',
    fmt.header('Per-Core Usage'),
    '',
  ];
  for (let i = 0; i < cpus.length; i++) {
    const times = cpus[i].times;
    const total = Object.values(times).reduce((a, b) => a + b, 0);
    const pct   = Math.round((1 - times.idle / total) * 100);
    lines.push('  Core ' + String(i).padStart(2) + '  ' + progressBar(pct, 20) + '  ' + String(pct).padStart(3) + '%');
  }
  return Promise.resolve(lines.join('\n'));
}

function memInfo() {
  const total = os.totalmem();
  const free  = os.freemem();
  const used  = total - free;
  const pct   = Math.round(used / total * 100);
  return Promise.resolve([
    fmt.header('Memory'),
    '',
    fmt.row('Total',    fmtBytes(total)),
    fmt.row('Used',     fmtBytes(used) + '  ' + progressBar(pct, 20) + '  ' + pct + '%'),
    fmt.row('Free',     fmtBytes(free)),
    fmt.row('Used %',   pct + '%'),
  ].join('\n'));
}

function diskInfo() {
  const cmd = process.platform === 'darwin'
    ? 'df -h'
    : 'df -h --output=source,fstype,size,used,avail,pcent,target 2>/dev/null || df -h';
  return sh(cmd).then(out => fmt.header('Disk Usage') + '\n\n' + out);
}

function processes() {
  const cmd = process.platform === 'darwin'
    ? 'ps aux -r | head -20'
    : 'ps aux --sort=-%cpu 2>/dev/null | head -20 || ps aux | head -20';
  return sh(cmd).then(out => fmt.header('Top Processes (by CPU)') + '\n\n' + out);
}

// ─── Network ──────────────────────────────────────────────────────────────────

function netInterfaces() {
  const ifaces = os.networkInterfaces();
  const lines  = [fmt.header('Network Interfaces'), ''];
  for (const [name, addrs] of Object.entries(ifaces)) {
    lines.push('  ' + name);
    for (const a of addrs) {
      const mac = a.mac && a.mac !== '00:00:00:00:00:00' ? '  mac: ' + a.mac : '';
      lines.push('    ' + a.family.padEnd(6) + ' ' + a.address + (a.cidr ? '  (' + a.cidr + ')' : '') + mac);
    }
    lines.push('');
  }
  return Promise.resolve(lines.join('\n'));
}

function openPorts() {
  const cmd = process.platform === 'darwin'
    ? 'netstat -anvp tcp 2>/dev/null | grep LISTEN || lsof -iTCP -sTCP:LISTEN -nP'
    : 'ss -tulnp 2>/dev/null || netstat -tulnp 2>/dev/null || echo "ss/netstat not available"';
  return sh(cmd).then(out => fmt.header('Listening Ports') + '\n\n' + out);
}

function connections() {
  const cmd = process.platform === 'darwin'
    ? 'netstat -an 2>/dev/null | grep ESTABLISHED | head -30'
    : 'ss -tn state established 2>/dev/null || netstat -tn 2>/dev/null | grep ESTABLISHED | head -30';
  return sh(cmd).then(out => fmt.header('Established Connections') + '\n\n' + (out || '  (none)'));
}

function ping(host) {
  const n   = process.platform === 'darwin' ? '' : '-c 4 ';
  return sh('ping ' + n + host, 12000).then(out => fmt.header('Ping: ' + host) + '\n\n' + out);
}

function dnsLookup(domain) {
  return new Promise(resolve => {
    const lines = [fmt.header('DNS: ' + domain), ''];
    dns.lookup(domain, { all: true }, (err, addrs) => {
      if (err) {
        lines.push('  Error: ' + err.message);
        resolve(lines.join('\n'));
        return;
      }
      lines.push('  A / AAAA records:');
      for (const a of (addrs || [])) {
        lines.push('    ' + a.address + '  (IPv' + a.family + ')');
      }
      lines.push('');
      dns.resolveMx(domain, (err2, mx) => {
        if (!err2 && mx && mx.length) {
          lines.push('  MX records:');
          for (const m of mx) lines.push('    ' + m.exchange + '  priority: ' + m.priority);
          lines.push('');
        }
        dns.resolveTxt(domain, (err3, txt) => {
          if (!err3 && txt && txt.length) {
            lines.push('  TXT records:');
            for (const t of txt) lines.push('    ' + (Array.isArray(t) ? t.join('') : t));
          }
          resolve(lines.join('\n'));
        });
      });
    });
  });
}

function httpCheck(url) {
  if (!url.startsWith('http')) url = 'https://' + url;
  return new Promise(resolve => {
    const start = Date.now();
    const mod   = url.startsWith('https') ? https : http;
    try {
      const req = mod.get(url, { timeout: 10000 }, res => {
        const ms   = Date.now() - start;
        const lines = [
          fmt.header('HTTP: ' + url),
          '',
          fmt.row('Status',    res.statusCode + ' ' + (res.statusMessage || '')),
          fmt.row('Time',      ms + ' ms'),
          fmt.row('Protocol',  'HTTP/' + res.httpVersion),
          '',
          '  Headers:',
        ];
        for (const [k, v] of Object.entries(res.headers)) {
          lines.push('    ' + k.padEnd(28) + v);
        }
        res.destroy();
        resolve(lines.join('\n'));
      });
      req.on('error', err => resolve(fmt.header('HTTP: ' + url) + '\n\n  Error: ' + err.message));
      req.on('timeout', () => { req.destroy(); resolve(fmt.header('HTTP: ' + url) + '\n\n  Timed out after 10s'); });
    } catch (e) {
      resolve(fmt.header('HTTP: ' + url) + '\n\n  Error: ' + e.message);
    }
  });
}

function traceroute(host) {
  const cmd = process.platform === 'darwin' ? 'traceroute -m 15 ' + host : 'traceroute -m 15 ' + host + ' 2>/dev/null || tracepath -m 15 ' + host;
  return sh(cmd, 30000).then(out => fmt.header('Traceroute: ' + host) + '\n\n' + out);
}

// ─── Dev Tools ────────────────────────────────────────────────────────────────

function runCmd(cmd, cwd, credential) {
  let actualCmd = cmd;
  // If a credential is supplied and the command uses sudo, pipe it via sudo -S
  if (credential) {
    const trimmed = cmd.trimStart();
    if (trimmed.startsWith('sudo ')) {
      // Replace leading "sudo" with "sudo -S" and pipe the password to stdin
      const rest = trimmed.slice(5); // everything after "sudo "
      actualCmd = `echo ${JSON.stringify(credential)} | sudo -S ${rest} 2>&1`;
    }
    // For non-sudo commands, pipe credential to stdin in case the command reads it
    else {
      actualCmd = `echo ${JSON.stringify(credential)} | ${cmd} 2>&1`;
    }
  }
  return sh(actualCmd, 30000, cwd)
    .then(out => fmt.header('$ ' + cmd) + '\n\n' + (out.trim() || '(no output)'));
}

function gitCmd(sub, cwd) {
  return sh('git -C "' + cwd + '" ' + sub + ' 2>&1')
    .then(out => fmt.header('git ' + sub.split(' ')[0]) + '\n\n' + (out.trim() || '(no output)'));
}

function runtimeVersions() {
  const checks = [
    ['Node.js',  'node --version'],
    ['npm',      'npm --version'],
    ['npx',      'npx --version'],
    ['Python 3', 'python3 --version 2>&1'],
    ['Python',   'python --version 2>&1'],
    ['Ruby',     'ruby --version 2>&1'],
    ['Go',       'go version 2>&1'],
    ['Rust',     'rustc --version 2>&1'],
    ['Java',     'java -version 2>&1 | head -1'],
    ['Git',      'git --version'],
    ['Docker',   'docker --version 2>&1'],
    ['kubectl',  'kubectl version --client --short 2>&1 | head -1'],
  ];
  const lines = [fmt.header('Runtime Versions'), ''];
  return Promise.all(
    checks.map(([name, cmd]) =>
      sh(cmd, 4000)
        .then(v => ({ name, v: v.trim() || 'not found' }))
        .catch(() => ({ name, v: 'not found' }))
    )
  ).then(results => {
    for (const { name, v } of results) {
      if (v !== 'not found') lines.push(fmt.row(name, v));
    }
    const missing = results.filter(r => r.v === 'not found').map(r => r.name);
    if (missing.length) {
      lines.push('', '  Not found: ' + missing.join(', '));
    }
    return lines.join('\n');
  });
}

function envVars() {
  const env  = process.env;
  const keys = Object.keys(env).sort();
  const lines = [fmt.header('Environment Variables (' + keys.length + ')'), ''];
  for (const k of keys) {
    const v = String(env[k]);
    lines.push('  ' + k.padEnd(26) + (v.length > 72 ? v.slice(0, 69) + '…' : v));
  }
  return Promise.resolve(lines.join('\n'));
}

function whichCmd(cmd) {
  return sh('which ' + cmd + ' 2>/dev/null && type ' + cmd + ' 2>/dev/null || echo "not found"')
    .then(out => fmt.header('which: ' + cmd) + '\n\n  ' + out.trim());
}

function pathEntries() {
  const entries = (process.env.PATH || '').split(':').filter(Boolean);
  const lines   = [fmt.header('$PATH  (' + entries.length + ' entries)'), ''];
  for (let i = 0; i < entries.length; i++) {
    const exists = safeExists(entries[i]);
    lines.push('  ' + String(i + 1).padStart(2) + '  ' + (exists ? '' : '{missing} ') + entries[i]);
  }
  return Promise.resolve(lines.join('\n'));
}

function runFile(filePath, cwd, interpreter) {
  if (!filePath) return Promise.resolve(fmt.header('No file') + '\n\n  Select a file in the explorer first, or provide a path.');
  const ext  = path.extname(filePath).slice(1).toLowerCase();
  const runners = { js:'node', mjs:'node', ts:'ts-node', py:'python3', rb:'ruby', sh:'bash', bash:'bash', php:'php', go:'go run', lua:'lua' };
  const runner = interpreter || runners[ext];
  if (!runner) return Promise.resolve(fmt.header('Cannot run: .' + ext) + '\n\n  No known runner for this extension.');
  return sh(runner + ' "' + filePath + '" 2>&1', 30000, cwd)
    .then(out => fmt.header(runner + ' ' + path.basename(filePath)) + '\n\n' + (out.trim() || '(no output)'));
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function sh(cmd, timeout, cwd) {
  return new Promise(resolve => {
    exec(cmd, { timeout: timeout || 10000, cwd: cwd || process.cwd(), maxBuffer: 512 * 1024 },
      (err, stdout, stderr) => {
        const out = (stdout + (stderr && !stdout ? stderr : '')).trim();
        resolve(stripAnsi(out));
      }
    );
  });
}

function stripAnsi(s) {
  return s
    .replace(/\x1B\[[0-9;]*[A-Za-z]/g, '')
    .replace(/\x1B\][^\x07]*\x07/g, '')
    .replace(/\x1B[()][AB012]/g, '');
}

function safeExists(p) { try { return fs.existsSync(p); } catch (_) { return false; } }

function fmtBytes(b) {
  if (!b) return '0 B';
  if (b < 1024)           return b + ' B';
  if (b < 1024 ** 2)      return (b / 1024).toFixed(1) + ' KB';
  if (b < 1024 ** 3)      return (b / 1024 ** 2).toFixed(1) + ' MB';
  return (b / 1024 ** 3).toFixed(2) + ' GB';
}

function fmtUptime(s) {
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  return (d ? d + 'd ' : '') + (h ? h + 'h ' : '') + m + 'm';
}

function progressBar(pct, len) {
  const filled = Math.round(pct / 100 * len);
  return '[' + '█'.repeat(filled) + '░'.repeat(len - filled) + ']';
}

const fmt = {
  header: text => '\n  ── ' + text + ' ──\n',
  row:    (label, value) => '  ' + String(label).padEnd(20) + String(value),
};

module.exports = { TOOLS, flatList, runTool };
