'use strict';

const fs = require('fs');
const fse = require('fs-extra');
const path = require('path');

/**
 * Read a directory and return sorted entries (dirs first, then files).
 * @param {string} dirPath
 * @param {boolean} showHidden
 * @returns {{ entries: Array, error: string|null }}
 */
function listDirectory(dirPath, showHidden = false) {
  try {
    const raw = fs.readdirSync(dirPath, { withFileTypes: true });
    const dirs = [];
    const files = [];

    for (const dirent of raw) {
      if (!showHidden && dirent.name.startsWith('.')) continue;

      const fullPath = path.join(dirPath, dirent.name);
      let stat = null;
      try {
        stat = fs.statSync(fullPath);
      } catch (_) {
        // permission error or broken symlink — keep entry, stat stays null
      }

      const entry = {
        name: dirent.name,
        path: fullPath,
        isDirectory: dirent.isDirectory() || (dirent.isSymbolicLink() && stat && stat.isDirectory()),
        isSymlink: dirent.isSymbolicLink(),
        size: stat ? stat.size : 0,
        mtime: stat ? stat.mtime : null,
        stat,
      };

      if (entry.isDirectory) {
        dirs.push(entry);
      } else {
        files.push(entry);
      }
    }

    const byName = (a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase());
    dirs.sort(byName);
    files.sort(byName);

    return { entries: [...dirs, ...files], error: null };
  } catch (e) {
    return { entries: [], error: e.message };
  }
}

function deleteEntry(entryPath) {
  try {
    fse.removeSync(entryPath);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

function renameEntry(oldPath, newPath) {
  try {
    fs.renameSync(oldPath, newPath);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

function copyEntry(src, dest) {
  try {
    fse.copySync(src, dest);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

function moveEntry(src, dest) {
  try {
    fse.moveSync(src, dest, { overwrite: false });
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

function createFile(filePath) {
  try {
    fse.ensureFileSync(filePath);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

function createDirectory(dirPath) {
  try {
    fse.ensureDirSync(dirPath);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

function formatSize(bytes) {
  if (bytes == null || isNaN(bytes)) return '—';
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[Math.min(i, units.length - 1)]}`;
}

module.exports = {
  listDirectory,
  deleteEntry,
  renameEntry,
  copyEntry,
  moveEntry,
  createFile,
  createDirectory,
  formatSize,
};
