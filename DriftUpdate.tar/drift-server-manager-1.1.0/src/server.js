'use strict';

const express = require('express');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { exec, spawn } = require('child_process');

const { loadConfig, saveConfig, resetCache, CONFIG_PATH } = require('./config');
const { listDirectory, deleteEntry, renameEntry, copyEntry, moveEntry, createFile, createDirectory, formatSize } = require('./fileops');
const { getFilePreview } = require('./preview');
const { flatList, runTool } = require('./tools');

// ─── Session store (in-memory tokens) ────────────────────────────────────────

const sessions = new Set();
const sudoCredentials = new Map(); // token → sudo password (session-scoped)
const terminalCwds = new Map();   // token → current working directory

function createToken() {
  const t = crypto.randomBytes(32).toString('hex');
  sessions.add(t);
  return t;
}
function validToken(t) { return t && sessions.has(t); }
function revokeToken(t) { sessions.delete(t); sudoCredentials.delete(t); terminalCwds.delete(t); }

// ─── Sudo helper ──────────────────────────────────────────────────────────────

function sudoRun(cred, cmd, timeout = 20000) {
  return new Promise(resolve => {
    const child = spawn('sudo', ['-S', 'bash', '-c', cmd], {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, SUDO_PROMPT: '' },
    });
    let out = '';
    let timer = setTimeout(() => {
      try {
        child.kill('SIGTERM');
      } catch (_) {}
    }, timeout);
    const done = (code, output) => {
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      const trimmed = (output || '').trim();
      resolve({ ok: code === 0, output: trimmed, code: code == null ? 1 : code });
    };
    child.stdout.on('data', d => { out += d.toString(); });
    child.stderr.on('data', d => { out += d.toString(); });
    child.on('error', err => done(1, out + err.message));
    child.on('close', code => done(code, out));
    const pw = cred == null || cred === undefined ? '' : String(cred).replace(/\r\n/g, '\n').replace(/\r/g, '');
    child.stdin.write(pw + '\n');
    child.stdin.end();
  });
}

/** Run a shell command as the same user as Drift (no sudo). Used for pm2 — each user has their own PM2 daemon/socket. */
function runUserCmd(cmd, timeout = 20000) {
  return new Promise(resolve => {
    exec(cmd, { timeout, maxBuffer: 2 * 1024 * 1024 }, (err, stdout) => {
      const output = (stdout || '').trim();
      resolve({ ok: !err, output, code: err ? (err.code || 1) : 0 });
    });
  });
}

function getPm2RunAsUser(cfg) {
  const fromEnv = (process.env.DRIFT_PM2_USER || '').trim();
  const fromCfg = cfg && cfg.web && String(cfg.web.pm2User || '').trim();
  return (fromEnv || fromCfg || '').trim();
}

/** True if PM2 control does not need browser sudo (same user as process, or Drift is root and can sudo -u target without a stored session). */
function pm2RunsAsDriftUser(cfg) {
  const target = getPm2RunAsUser(cfg);
  if (!target) return true;
  try {
    if (typeof process.getuid === 'function' && process.getuid() === 0) return true;
  } catch (_) {}
  try {
    return target === os.userInfo().username;
  } catch (_) {
    return false;
  }
}

/**
 * Run a PM2 shell snippet as the configured PM2 owner (see web.pm2User / DRIFT_PM2_USER).
 * Uses sudo -u when Drift’s Unix user differs from that owner; root needs no UI sudo, other users need a sudo session.
 */
async function runPm2Cmd(cfg, cred, innerCmd, timeout = 20000) {
  const target = getPm2RunAsUser(cfg);
  let current = '';
  try {
    current = os.userInfo().username;
  } catch (_) {}
  const needImpersonate = target && target !== current;
  if (!needImpersonate) return runUserCmd(innerCmd, timeout);
  if (!/^[a-zA-Z0-9_.-]+$/.test(target)) {
    return { ok: false, output: 'Invalid web.pm2User / DRIFT_PM2_USER (use a Unix login name).', code: 1 };
  }
  const asUser = `sudo -u ${target} -H bash -c ${JSON.stringify(innerCmd)}`;
  try {
    if (typeof process.getuid === 'function' && process.getuid() === 0) {
      return runUserCmd(asUser, timeout);
    }
  } catch (_) {}
  if (!cred) {
    return {
      ok: false,
      output: 'Sudo required in the UI to control PM2 as another user, or run Drift as that user / as root.',
      code: 1,
    };
  }
  return sudoRun(cred, asUser, timeout);
}

// ─── Path safety ──────────────────────────────────────────────────────────────

function safePath(cfg, requestedPath) {
  const root = cfg.web.rootDir;
  // default to rootDir if no path given
  const resolved = path.resolve(requestedPath || root);
  if (!resolved.startsWith(root)) {
    const err = new Error('Access denied: path is outside the root directory');
    err.code = 'EACCES';
    throw err;
  }
  return resolved;
}

// ─── Auth middleware ──────────────────────────────────────────────────────────

function requireAuth(cfg) {
  return (req, res, next) => {
    if (!cfg.web.password) return next();            // no password set = open
    const token = req.headers['x-drift-token'] || '';
    if (validToken(token)) return next();
    res.status(401).json({ error: 'Unauthorized' });
  };
}

// ─── Build express app ────────────────────────────────────────────────────────

function buildApp(cfg) {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  const auth = requireAuth(cfg);
  const webDir = path.join(__dirname, 'web');
  const MYAPPS_USER_STORE = path.join(os.homedir(), '.drift-myapps-user.json');

  // ── Static web UI ─────────────────────────────────────────────────────────
  app.get('/', (req, res) => {
    res.sendFile(path.join(webDir, 'index.html'));
  });
  app.use('/static', express.static(webDir));

  // ── Auth ──────────────────────────────────────────────────────────────────
  app.post('/api/auth/login', (req, res) => {
    const { password } = req.body || {};
    if (!cfg.web.password || password === cfg.web.password) {
      const token = createToken();
      res.json({ token, rootDir: cfg.web.rootDir });
    } else {
      res.status(401).json({ error: 'Wrong password' });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    revokeToken(req.headers['x-drift-token'] || '');
    res.json({ ok: true });
  });

  app.get('/api/auth/check', (req, res) => {
    const needsAuth = Boolean(cfg.web.password);
    const authed = !needsAuth || validToken(req.headers['x-drift-token'] || '');
    res.json({ needsAuth, authed, rootDir: cfg.web.rootDir });
  });

  // ── Filesystem: list ──────────────────────────────────────────────────────
  app.get('/api/fs/list', auth, (req, res) => {
    try {
      const dir = safePath(cfg, req.query.path || cfg.web.rootDir);
      const { entries, error } = listDirectory(dir, false);
      if (error) return res.status(500).json({ error });

      const home = os.homedir();
      const displayPath = dir.startsWith(home) ? '~' + dir.slice(home.length) : dir;

      res.json({
        path: dir,
        displayPath,
        parent: dir !== cfg.web.rootDir ? path.dirname(dir) : null,
        entries: entries.map(e => ({
          name: e.name,
          path: e.path,
          isDirectory: e.isDirectory,
          isSymlink: e.isSymlink,
          size: e.size,
          sizeDisplay: formatSize(e.size),
          mtime: e.mtime,
          ext: path.extname(e.name).slice(1).toLowerCase(),
        })),
      });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: read file ─────────────────────────────────────────────────
  app.get('/api/fs/read', auth, (req, res) => {
    try {
      const filePath = safePath(cfg, req.query.path);
      const stat = fs.statSync(filePath);

      if (stat.isDirectory()) {
        return res.status(400).json({ error: 'Path is a directory' });
      }
      if (stat.size > 5 * 1024 * 1024) {
        return res.status(413).json({ error: 'File too large to preview (> 5 MB)' });
      }

      const content = fs.readFileSync(filePath);
      const isBin = isBinary(content.slice(0, 512));

      if (isBin) {
        return res.json({
          type: 'binary',
          name: path.basename(filePath),
          size: stat.size,
          sizeDisplay: formatSize(stat.size),
          mtime: stat.mtime,
        });
      }

      const text = content.toString('utf8');
      res.json({
        type: 'text',
        content: text,
        size: stat.size,
        mtime: stat.mtime,
      });
    } catch (e) {
      res.status(e.code === 'ENOENT' ? 404 : e.code === 'EACCES' ? 403 : 500)
        .json({ error: e.message });
    }
  });

  // ── Filesystem: download ─────────────────────────────────────────────────
  app.get('/api/fs/download', (req, res) => {
    const token = req.headers['x-drift-token'] || req.query.token || '';
    if (cfg.web.password && !validToken(token)) return res.status(401).end();
    try {
      const filePath = safePath(cfg, req.query.path);
      res.download(filePath);
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: serve image / binary preview ──────────────────────────────
  app.get('/api/fs/serve', (req, res) => {
    const token = req.headers['x-drift-token'] || req.query.token || '';
    if (cfg.web.password && !validToken(token)) return res.status(401).end();
    try {
      const filePath = safePath(cfg, req.query.path);
      const ext = path.extname(filePath).slice(1).toLowerCase();
      const mimes = {
        png:'image/png', jpg:'image/jpeg', jpeg:'image/jpeg',
        gif:'image/gif', svg:'image/svg+xml', webp:'image/webp',
        ico:'image/x-icon', bmp:'image/bmp', pdf:'application/pdf',
      };
      if (mimes[ext]) res.set('Content-Type', mimes[ext]);
      fs.createReadStream(filePath).pipe(res);
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).end();
    }
  });

  // ── Filesystem: upload (text or base64 binary) ────────────────────────────
  app.post('/api/fs/upload', auth, express.raw({ type: '*/*', limit: '50mb' }), (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const destPath = safePath(cfg, req.query.path);
      fs.writeFileSync(destPath, req.body);
      res.json({ ok: true });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: write file ────────────────────────────────────────────────
  app.post('/api/fs/write', auth, (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const { path: filePath, content } = req.body;
      const safe = safePath(cfg, filePath);
      fs.writeFileSync(safe, content, 'utf8');
      res.json({ ok: true });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: delete ────────────────────────────────────────────────────
  app.post('/api/fs/delete', auth, (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const safe = safePath(cfg, req.body.path);
      const result = deleteEntry(safe);
      if (!result.success) return res.status(500).json({ error: result.error });
      res.json({ ok: true });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: rename ────────────────────────────────────────────────────
  app.post('/api/fs/rename', auth, (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const from = safePath(cfg, req.body.from);
      const to = safePath(cfg, req.body.to);
      const result = renameEntry(from, to);
      if (!result.success) return res.status(500).json({ error: result.error });
      res.json({ ok: true });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: mkdir ─────────────────────────────────────────────────────
  app.post('/api/fs/mkdir', auth, (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const safe = safePath(cfg, req.body.path);
      const result = createDirectory(safe);
      if (!result.success) return res.status(500).json({ error: result.error });
      res.json({ ok: true });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: new file ──────────────────────────────────────────────────
  app.post('/api/fs/touch', auth, (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const safe = safePath(cfg, req.body.path);
      const result = createFile(safe);
      if (!result.success) return res.status(500).json({ error: result.error });
      res.json({ ok: true });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Export / convert ──────────────────────────────────────────────────────
  app.post('/api/fs/export', auth, (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const src = safePath(cfg, req.body.src);
      const dest = safePath(cfg, req.body.dest);
      const destExt = path.extname(dest).slice(1).toLowerCase();

      if (destExt === 'pdf') {
        exec('which pandoc', pandocErr => {
          if (pandocErr) {
            return res.status(501).json({ error: 'PDF export requires pandoc (apt install pandoc)' });
          }
          exec(`pandoc "${src}" -o "${dest}"`, err => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ ok: true, dest });
          });
        });
      } else {
        const result = copyEntry(src, dest);
        if (!result.success) return res.status(500).json({ error: result.error });
        res.json({ ok: true, dest });
      }
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Tools: list ───────────────────────────────────────────────────────────
  app.get('/api/tools/list', auth, (req, res) => {
    res.json(flatList());
  });

  // ── Tools: run ────────────────────────────────────────────────────────────
  app.post('/api/tools/run', auth, async (req, res) => {
    const { id, arg, context, credential } = req.body || {};
    try {
      const ctx = Object.assign({}, context || {}, { credential: credential || null });
      const raw = await runTool(id, arg || null, ctx);
      const output = raw.replace(/\{\/?\w[\w-]*\}/g, '');
      res.json({ output });
    } catch (e) {
      res.json({ output: 'Error: ' + e.message });
    }
  });

  // ── Terminal: stateful command runner with persistent cwd ─────────────────
  app.post('/api/terminal/run', auth, async (req, res) => {
    const token = req.headers['x-drift-token'] || '';
    const { cmd } = req.body || {};
    if (!cmd || typeof cmd !== 'string') return res.status(400).json({ error: 'Missing cmd' });

    // Initialize session cwd to rootDir on first use
    if (!terminalCwds.has(token)) terminalCwds.set(token, cfg.web.rootDir);
    const cwd = terminalCwds.get(token);

    // Handle `cd` natively — exec spawns a subshell so cd has no effect otherwise
    const cdMatch = cmd.trim().match(/^cd(?:\s+(.+))?$/);
    if (cdMatch) {
      const target = (cdMatch[1] || '').trim();
      let newDir;
      if (!target || target === '~') {
        newDir = os.homedir();
      } else if (target.startsWith('~/')) {
        newDir = path.join(os.homedir(), target.slice(2));
      } else {
        newDir = path.resolve(cwd, target);
      }
      try {
        const stat = fs.statSync(newDir);
        if (!stat.isDirectory()) return res.json({ output: `cd: not a directory: ${target || '~'}`, cwd });
        terminalCwds.set(token, newDir);
        return res.json({ output: '', cwd: newDir });
      } catch (_) {
        return res.json({ output: `cd: ${target || '~'}: No such file or directory`, cwd });
      }
    }

    // Execute the command in the session's cwd
    const output = await new Promise(resolve => {
      exec(cmd, { cwd, timeout: 30000, maxBuffer: 512 * 1024, shell: '/bin/bash' }, (err, stdout, stderr) => {
        const out = (stdout || '') + (stderr || '');
        resolve(out || (err ? `Exit code ${err.code || 1}` : ''));
      });
    });

    // Strip ANSI escape sequences (terminal div can't render them)
    const clean = output
      .replace(/\x1B\[[0-9;]*[A-Za-z]/g, '')
      .replace(/\x1B\][^\x07]*\x07/g, '')
      .replace(/\x1B[()][AB012]/g, '');

    res.json({ output: clean, cwd });
  });

  // ── Keys: list names (values never sent to client) ────────────────────────
  app.get('/api/keys/list', auth, (req, res) => {
    const keys = cfg.keys || {};
    res.json(Object.keys(keys));
  });

  // ── Keys: get value for a specific key ────────────────────────────────────
  app.get('/api/keys/get', auth, (req, res) => {
    const name = req.query.name;
    if (!name) return res.status(400).json({ error: 'Missing name' });
    const value = (cfg.keys || {})[name];
    if (value === undefined) return res.status(404).json({ error: 'Key not found' });
    res.json({ value });
  });

  // ── Keys: set / update ────────────────────────────────────────────────────
  app.post('/api/keys/set', auth, (req, res) => {
    const { name, value } = req.body || {};
    if (!name) return res.status(400).json({ error: 'Missing name' });
    const { saveConfig, loadConfig: lc } = require('./config');
    const current = lc();
    const keys = Object.assign({}, current.keys || {}, { [name]: value || '' });
    const result = saveConfig({ keys });
    if (result.success) {
      // Update live cfg so new runs can use it immediately
      if (!cfg.keys) cfg.keys = {};
      cfg.keys[name] = value || '';
      res.json({ ok: true });
    } else {
      res.status(500).json({ error: result.error });
    }
  });

  // ── Keys: delete ──────────────────────────────────────────────────────────
  app.post('/api/keys/delete', auth, (req, res) => {
    const { name } = req.body || {};
    if (!name) return res.status(400).json({ error: 'Missing name' });
    const { saveConfig, loadConfig: lc } = require('./config');
    const current = lc();
    const keys = Object.assign({}, current.keys || {});
    delete keys[name];
    const result = saveConfig({ keys });
    if (result.success) {
      if (cfg.keys) delete cfg.keys[name];
      res.json({ ok: true });
    } else {
      res.status(500).json({ error: result.error });
    }
  });

  // ── Config: get (passwords masked) ─────────────────────────────────────────
  app.get('/api/config', auth, (req, res) => {
    const c = JSON.parse(JSON.stringify(cfg));
    if (c.web && c.web.password) c.web.password = '__SET__';
    if (c.keys) {
      for (const k of Object.keys(c.keys)) c.keys[k] = c.keys[k] ? '__SET__' : '';
    }
    const pm2u = getPm2RunAsUser(cfg);
    c.runtime = {
      pm2User: pm2u || null,
      pm2ControlAsSelf: pm2RunsAsDriftUser(cfg),
    };
    res.json(c);
  });

  // ── Config: save ────────────────────────────────────────────────────────────
  app.post('/api/config', auth, (req, res) => {
    const updates = req.body || {};
    // Don't overwrite password/keys with masked placeholders
    if (updates.web && updates.web.password === '__SET__') delete updates.web.password;
    if (updates.keys) {
      for (const k of Object.keys(updates.keys)) {
        if (updates.keys[k] === '__SET__') delete updates.keys[k];
      }
    }
    const { saveConfig } = require('./config');
    const result = saveConfig(updates);
    if (result.success) {
      // Merge into live cfg
      Object.assign(cfg, require('./config').loadConfig());
      res.json({ ok: true });
    } else {
      res.status(500).json({ error: result.error });
    }
  });

  // ── Search: find in files ───────────────────────────────────────────────────
  app.post('/api/fs/search', auth, (req, res) => {
    const { query, path: searchPath, caseSensitive, wholeWord } = req.body || {};
    if (!query) return res.json({ results: [] });
    try {
      const dir = safePath(cfg, searchPath || cfg.web.rootDir);
      let flags = '-r -n --include="*.{js,ts,jsx,tsx,json,md,txt,py,go,rs,sh,css,scss,html,yaml,yml,env,conf,cfg,ini,sql}" -l';
      if (!caseSensitive) flags += ' -i';
      const wordFlag = wholeWord ? ' -w' : '';
      const { execSync } = require('child_process');
      // First get matching files
      let fileList;
      try {
        fileList = execSync(`grep ${flags}${wordFlag} ${JSON.stringify(query)} ${JSON.stringify(dir)} 2>/dev/null`, { maxBuffer: 1024*1024, timeout: 10000 }).toString().trim().split('\n').filter(Boolean).slice(0, 50);
      } catch (e) { fileList = []; }

      const results = [];
      for (const filePath of fileList) {
        if (!filePath) continue;
        try {
          safePath(cfg, filePath); // security check
          let lineFlags = caseSensitive ? '-n' : '-ni';
          if (wholeWord) lineFlags += ' -w';
          const lines = execSync(`grep ${lineFlags} ${JSON.stringify(query)} ${JSON.stringify(filePath)} 2>/dev/null`, { maxBuffer: 512*1024, timeout: 5000 }).toString().trim().split('\n').filter(Boolean).slice(0, 20);
          const matches = lines.map(l => {
            const m = l.match(/^(\d+):(.*)$/);
            return m ? { line: parseInt(m[1]), text: m[2].trim().slice(0, 200) } : null;
          }).filter(Boolean);
          if (matches.length) results.push({ file: filePath, name: require('path').basename(filePath), matches });
        } catch (_) {}
      }
      res.json({ results, query });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Git: status ─────────────────────────────────────────────────────────────
  app.get('/api/git/status', auth, (req, res) => {
    try {
      const dir = safePath(cfg, req.query.path || cfg.web.rootDir);
      const { execSync } = require('child_process');
      const branch = execSync(`git -C ${JSON.stringify(dir)} rev-parse --abbrev-ref HEAD 2>/dev/null`, { timeout: 5000 }).toString().trim();
      const status = execSync(`git -C ${JSON.stringify(dir)} status --porcelain 2>/dev/null`, { timeout: 5000 }).toString().trim();
      const files = status.split('\n').filter(Boolean).map(l => ({ code: l.slice(0,2).trim(), file: l.slice(3).trim() }));
      const ahead = (() => { try { return execSync(`git -C ${JSON.stringify(dir)} rev-list @{u}..HEAD --count 2>/dev/null`, { timeout: 3000 }).toString().trim(); } catch(_) { return '?'; } })();
      const behind = (() => { try { return execSync(`git -C ${JSON.stringify(dir)} rev-list HEAD..@{u} --count 2>/dev/null`, { timeout: 3000 }).toString().trim(); } catch(_) { return '?'; } })();
      res.json({ branch, files, ahead, behind });
    } catch (e) {
      res.json({
        error: 'Not a git repository',
        hint:
          'This directory has no .git folder. From your Drift install root run: npm run init-git-remote — or clone the repo from GitHub instead of copying files.',
        branch: null,
        files: [],
      });
    }
  });

  // ── Git: log ─────────────────────────────────────────────────────────────────
  app.get('/api/git/log', auth, (req, res) => {
    try {
      const dir = safePath(cfg, req.query.path || cfg.web.rootDir);
      const { execSync } = require('child_process');
      const raw = execSync(`git -C ${JSON.stringify(dir)} log --oneline -30 2>/dev/null`, { timeout: 5000 }).toString().trim();
      const commits = raw.split('\n').filter(Boolean).map(l => {
        const m = l.match(/^([a-f0-9]+)\s(.+)$/);
        return m ? { hash: m[1], message: m[2] } : null;
      }).filter(Boolean);
      res.json({ commits });
    } catch (e) {
      res.json({ commits: [], error: e.message });
    }
  });

  // ── Git: diff for a file ─────────────────────────────────────────────────────
  app.get('/api/git/diff', auth, (req, res) => {
    try {
      const dir = safePath(cfg, req.query.path || cfg.web.rootDir);
      const file = req.query.file ? safePath(cfg, req.query.file) : null;
      const { execSync } = require('child_process');
      const cmd = file
        ? `git -C ${JSON.stringify(dir)} diff HEAD -- ${JSON.stringify(file)} 2>/dev/null`
        : `git -C ${JSON.stringify(dir)} diff HEAD 2>/dev/null`;
      const diff = execSync(cmd, { maxBuffer: 512*1024, timeout: 8000 }).toString();
      res.json({ diff });
    } catch (e) {
      res.json({ diff: '', error: e.message });
    }
  });

  // ── Sudo: authenticate / check / clear ────────────────────────────────────
  app.post('/api/auth/sudo', auth, async (req, res) => {
    const { credential } = req.body || {};
    if (!credential) return res.status(400).json({ error: 'Missing credential' });
    const token = req.headers['x-drift-token'] || '';
    const result = await sudoRun(credential, 'true', 5000);
    if (!result.ok) {
      const low = (result.output || '').toLowerCase();
      let detail = '';
      if (low.includes('not in the sudoers') || low.includes('not allowed to run sudo')) {
        detail = ' The system account running Drift is not allowed to use sudo.';
      } else if (low.includes('no passwd entry')) {
        detail = ' Sudo could not resolve the Drift process user.';
      }
      return res.status(401).json({ error: 'Sudo failed — wrong password or no sudo access for this user.' + detail });
    }
    sudoCredentials.set(token, credential);
    res.json({ ok: true });
  });

  app.post('/api/auth/sudo/clear', auth, (req, res) => {
    sudoCredentials.delete(req.headers['x-drift-token'] || '');
    res.json({ ok: true });
  });

  app.get('/api/auth/sudo/check', auth, (req, res) => {
    res.json({ hasSudo: sudoCredentials.has(req.headers['x-drift-token'] || '') });
  });

  // ── Users ─────────────────────────────────────────────────────────────────
  app.get('/api/users/list', auth, (req, res) => {
    try {
      const raw = fs.readFileSync('/etc/passwd', 'utf8');
      const users = raw.trim().split('\n').map(l => {
        const p = l.split(':');
        return { username: p[0], uid: parseInt(p[2]), gid: parseInt(p[3]), comment: p[4], home: p[5], shell: p[6] };
      }).filter(u => u.uid >= 1000 || u.username === 'root');

      let sudoers = ['root'];
      try {
        const { execSync: es } = require('child_process');
        const sg = es('getent group sudo 2>/dev/null || getent group wheel 2>/dev/null', { timeout: 3000 }).toString().trim();
        const members = sg.split(':')[3];
        if (members) sudoers = sudoers.concat(members.split(',').filter(Boolean));
      } catch (_) {}

      res.json({ users: users.map(u => ({
        ...u,
        hasSudo: sudoers.includes(u.username),
        active: u.shell && !u.shell.includes('nologin') && !u.shell.includes('false'),
      }))});
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.post('/api/users/create', auth, async (req, res) => {
    const token = req.headers['x-drift-token'] || '';
    const cred = sudoCredentials.get(token);
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { username, password, shell = '/bin/bash' } = req.body || {};
    if (!username || !/^[a-z_][a-z0-9_-]{0,30}$/.test(username))
      return res.status(400).json({ error: 'Invalid username' });
    const r = await sudoRun(cred, `useradd -m -s ${shell} ${username}`);
    if (!r.ok) return res.status(500).json({ error: r.output || 'useradd failed' });
    if (password) {
      const r2 = await sudoRun(cred, `echo ${JSON.stringify(username + ':' + password)} | chpasswd`);
      if (!r2.ok) return res.json({ ok: true, warning: 'User created but password not set: ' + r2.output });
    }
    res.json({ ok: true });
  });

  app.post('/api/users/delete', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { username, removeHome } = req.body || {};
    if (!username) return res.status(400).json({ error: 'Missing username' });
    const flag = removeHome ? '-r' : '';
    const r = await sudoRun(cred, `userdel ${flag} ${username}`);
    if (!r.ok) return res.status(500).json({ error: r.output || 'userdel failed' });
    res.json({ ok: true });
  });

  app.post('/api/users/passwd', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { username, password } = req.body || {};
    if (!username || !password) return res.status(400).json({ error: 'Missing fields' });
    const r = await sudoRun(cred, `echo ${JSON.stringify(username + ':' + password)} | chpasswd`);
    if (!r.ok) return res.status(500).json({ error: r.output || 'chpasswd failed' });
    res.json({ ok: true });
  });

  app.post('/api/users/sudo', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { username, grant } = req.body || {};
    if (!username) return res.status(400).json({ error: 'Missing username' });
    const sudoGroup = await sudoRun(cred, 'getent group sudo >/dev/null 2>&1 && echo sudo || echo wheel');
    const grpLines = sudoGroup.output.split('\n').map(l => l.trim());
    const grp = grpLines.find(l => l === 'sudo' || l === 'wheel') || 'sudo';
    const cmd = grant ? `usermod -aG ${grp} ${username}` : `gpasswd -d ${username} ${grp}`;
    const r = await sudoRun(cred, cmd);
    if (!r.ok) return res.status(500).json({ error: r.output || 'group change failed' });
    res.json({ ok: true });
  });

  app.get('/api/users/groups', auth, (req, res) => {
    try {
      const raw = fs.readFileSync('/etc/group', 'utf8');
      const groups = raw.trim().split('\n').map(l => {
        const p = l.split(':');
        return { name: p[0], gid: parseInt(p[2]), members: p[3] ? p[3].split(',').filter(Boolean) : [] };
      });
      res.json({ groups });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // ── Services ──────────────────────────────────────────────────────────────
  app.get('/api/services/list', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    try {
      const raw = es('systemctl list-units --type=service --all --no-pager --no-legend 2>/dev/null', { timeout: 10000, maxBuffer: 2*1024*1024 }).toString().trim();
      const services = raw.split('\n').filter(Boolean).map(l => {
        const m = l.trim().match(/^(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(.*)$/);
        if (!m) return null;
        return { unit: m[1].replace('.service',''), load: m[2], active: m[3], sub: m[4], description: m[5] };
      }).filter(Boolean).slice(0, 200);
      res.json({ services });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.post('/api/services/action', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { name, action } = req.body || {};
    const allowed = ['start', 'stop', 'restart', 'enable', 'disable', 'reload'];
    if (!name || !allowed.includes(action)) return res.status(400).json({ error: 'Invalid action' });
    const r = await sudoRun(cred, `systemctl ${action} ${name}`);
    res.json({ ok: r.ok, output: r.output });
  });

  app.get('/api/services/status', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    const { name } = req.query;
    if (!name) return res.status(400).json({ error: 'Missing name' });
    try {
      const out = es(`systemctl status ${name} --no-pager 2>&1`, { timeout: 5000, maxBuffer: 512*1024 }).toString();
      res.json({ output: out });
    } catch (e) { res.json({ output: (e.stdout || e.message || '').toString() }); }
  });

  // ── Packages ──────────────────────────────────────────────────────────────
  app.get('/api/packages/list', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    try {
      const raw = es('dpkg -l 2>/dev/null | grep "^ii"', { timeout: 15000, maxBuffer: 4*1024*1024 }).toString();
      const pkgs = raw.trim().split('\n').filter(Boolean).map(l => {
        const p = l.trim().split(/\s+/);
        return { name: p[1], version: p[2], arch: p[3], description: p.slice(4).join(' ') };
      });
      res.json({ packages: pkgs });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.post('/api/packages/search', auth, (req, res) => {
    const { query } = req.body || {};
    if (!query) return res.json({ results: [] });
    const { execSync: es } = require('child_process');
    try {
      const raw = es(`apt-cache search ${JSON.stringify(query)} 2>/dev/null | head -50`, { timeout: 10000, maxBuffer: 1024*1024 }).toString();
      const results = raw.trim().split('\n').filter(Boolean).map(l => {
        const i = l.indexOf(' - ');
        return i > -1 ? { name: l.slice(0, i), description: l.slice(i + 3) } : { name: l, description: '' };
      });
      res.json({ results });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.get('/api/packages/updates', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    try {
      const raw = es('apt list --upgradable 2>/dev/null | grep -v "Listing..." | head -100', { timeout: 15000, maxBuffer: 1024*1024 }).toString();
      const updates = raw.trim().split('\n').filter(Boolean).map(l => {
        const m = l.match(/^(\S+)\/\S+\s+(\S+)\s+\S+\s+\[upgradable from:\s+(\S+)\]/);
        return m ? { name: m[1], newVersion: m[2], oldVersion: m[3] } : { name: l, newVersion: '', oldVersion: '' };
      });
      res.json({ updates });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.post('/api/packages/action', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { name, action } = req.body || {};
    const allowed = ['install', 'remove', 'purge', 'update'];
    if (!allowed.includes(action)) return res.status(400).json({ error: 'Invalid action' });
    const cmd = action === 'update'
      ? 'DEBIAN_FRONTEND=noninteractive apt-get update -q'
      : `DEBIAN_FRONTEND=noninteractive apt-get ${action} -y ${name}`;
    const r = await sudoRun(cred, cmd, 120000);
    res.json({ ok: r.ok, output: r.output });
  });

  // ── Logs ──────────────────────────────────────────────────────────────────
  app.get('/api/logs/journal', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    const { unit, lines = 200, priority } = req.query;
    const unitFlag = unit ? `-u ${unit}` : '';
    const prioFlag = priority ? `-p ${priority}` : '';
    try {
      const raw = es(`journalctl ${unitFlag} ${prioFlag} -n ${parseInt(lines)} --no-pager --output=short-iso 2>/dev/null`, { timeout: 10000, maxBuffer: 2*1024*1024 }).toString();
      res.json({ output: raw });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.get('/api/logs/files', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    try {
      const raw = es('find /var/log -maxdepth 2 -type f -name "*.log" 2>/dev/null | head -60', { timeout: 5000 }).toString();
      res.json({ files: raw.trim().split('\n').filter(Boolean) });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.get('/api/logs/file', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    const { file, lines = 200 } = req.query;
    if (!file || !file.startsWith('/var/log/')) return res.status(400).json({ error: 'Invalid log path' });
    try {
      const raw = es(`tail -n ${parseInt(lines)} ${JSON.stringify(file)} 2>/dev/null`, { timeout: 5000, maxBuffer: 2*1024*1024 }).toString();
      res.json({ output: raw });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // ── Firewall ──────────────────────────────────────────────────────────────
  app.get('/api/firewall/status', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    try {
      const raw = es('ufw status verbose 2>/dev/null || echo "ufw not available"', { timeout: 5000 }).toString();
      const enabled = raw.includes('Status: active');
      res.json({ output: raw.trim(), enabled });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.post('/api/firewall/action', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { action, rule } = req.body || {};
    const allowed = ['enable', 'disable', 'allow', 'deny', 'delete', 'reload'];
    if (!allowed.includes(action)) return res.status(400).json({ error: 'Invalid action' });
    const cmd = rule ? `ufw ${action} ${rule}` : `ufw --force ${action}`;
    const r = await sudoRun(cred, cmd);
    res.json({ ok: r.ok, output: r.output });
  });

  app.get('/api/firewall/rules', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    try {
      const raw = es('ufw status numbered 2>/dev/null || echo "ufw not available"', { timeout: 5000 }).toString();
      const rules = [];
      raw.split('\n').forEach(l => {
        const m = l.match(/^\[\s*(\d+)\]\s+(.+?)\s{2,}(.+?)\s{2,}(.+)$/);
        if (m) rules.push({ num: m[1], to: m[2].trim(), action: m[3].trim(), from: m[4].trim() });
      });
      res.json({ rules, raw: raw.trim() });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // ── Cron ──────────────────────────────────────────────────────────────────
  app.get('/api/cron/list', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    const { user } = req.query;
    try {
      const cmd = user ? `crontab -u ${user} -l 2>/dev/null` : 'crontab -l 2>/dev/null';
      const raw = es(cmd, { timeout: 5000 }).toString();
      const lines = raw.trim().split('\n').filter(l => l && !l.startsWith('#'));
      res.json({ entries: lines, raw: raw.trim() });
    } catch (e) { res.json({ entries: [], raw: '' }); }
  });

  app.post('/api/cron/save', auth, (req, res) => {
    const { content, user } = req.body || {};
    if (content === undefined) return res.status(400).json({ error: 'Missing content' });
    const { execSync: es } = require('child_process');
    const tmpFile = require('os').tmpdir() + '/drift-cron-' + Date.now() + '.txt';
    try {
      fs.writeFileSync(tmpFile, content, 'utf8');
      const cmd = user ? `crontab -u ${user} ${tmpFile}` : `crontab ${tmpFile}`;
      es(cmd, { timeout: 5000 });
      fs.unlinkSync(tmpFile);
      res.json({ ok: true });
    } catch (e) {
      try { fs.unlinkSync(tmpFile); } catch (_) {}
      res.status(500).json({ error: e.message });
    }
  });

  // ── System: dashboard stats ───────────────────────────────────────────────
  app.get('/api/system/stats', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    const cpus = os.cpus();
    const total = os.totalmem();
    const free = os.freemem();
    const load = os.loadavg();
    let disk = '';
    try { disk = es('df -h / 2>/dev/null | tail -1', { timeout: 3000 }).toString().trim(); } catch (_) {}
    let netStats = '';
    try { netStats = es('cat /proc/net/dev 2>/dev/null | grep -v lo | tail -5', { timeout: 2000 }).toString().trim(); } catch (_) {}
    res.json({
      hostname: os.hostname(),
      platform: os.platform(),
      release: os.release(),
      uptime: os.uptime(),
      cpu: { cores: cpus.length, model: cpus[0]?.model?.trim() || '?', load1: load[0], load5: load[1], load15: load[2] },
      memory: { total, free, used: total - free, usedPct: Math.round((total - free) / total * 100) },
      disk,
      netStats,
    });
  });

  /** Parse last JSON line from drift-update --json (stdout may only contain that line). */
  function parseDriftUpdateStdout(stdout) {
    const lines = String(stdout || '')
      .trim()
      .split('\n')
      .filter(Boolean);
    for (let i = lines.length - 1; i >= 0; i--) {
      try {
        const j = JSON.parse(lines[i]);
        if (j && typeof j.ok === 'boolean') return j;
      } catch (_) {
        /* next line */
      }
    }
    return null;
  }

  // ── Apply upstream update (same as CLI drift-update --yes) ─────────────────
  app.post('/api/system/drift-update', auth, (req, res) => {
    req.socket.setTimeout(900000);
    const installRoot = path.resolve(__dirname, '..');
    const script = path.join(installRoot, 'bin', 'drift-update.js');
    if (!fs.existsSync(script)) {
      return res.status(500).json({ ok: false, error: 'drift-update script not found', log: '' });
    }
    const child = spawn(process.execPath, [script, '--yes', '--json'], {
      cwd: installRoot,
      env: { ...process.env, DRIFT_INSTALL_DIR: installRoot, FORCE_COLOR: '0', NO_COLOR: '1' },
    });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', d => {
      stdout += d.toString();
    });
    child.stderr.on('data', d => {
      stderr += d.toString();
    });
    child.on('error', err => {
      res.status(500).json({
        ok: false,
        error: err.message,
        log: (stderr + stdout).trim(),
      });
    });
    child.on('close', code => {
      const log = [stderr, stdout].filter(Boolean).join('\n').trim();
      const summary = parseDriftUpdateStdout(stdout);
      if (!summary) {
        return res.status(500).json({
          ok: false,
          error: code
            ? `Updater exited ${code}${log ? ': ' + log.slice(-1500) : ''}`
            : 'Updater produced no JSON result',
          log,
          code,
        });
      }
      if (!summary.ok) {
        return res.status(500).json({
          ...summary,
          error: summary.error || 'Update failed',
          log,
          code,
        });
      }
      res.json({ ...summary, log, code: code || 0 });
    });
  });

  // ── Apps: discover all running applications ───────────────────────────────
  app.get('/api/apps/list', auth, async (req, res) => {
    const tokenCred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    function sh(cmd, timeout = 8000) {
      return new Promise(r => {
        require('child_process').exec(cmd, { timeout, maxBuffer: 2 * 1024 * 1024 }, (e, o) => r((o || '').trim()));
      });
    }
    async function shPm2List(timeout = 8000) {
      const inner = 'pm2 jlist 2>/dev/null || echo "[]"';
      const r = await runPm2Cmd(cfg, tokenCred, inner, timeout);
      const out = (r.output || '').trim();
      return out || '[]';
    }

    const [ssOut, svcOut, dockerOut, pm2Out, supOut, procOut] = await Promise.all([
      sh('ss -tulnp 2>/dev/null'),
      sh('systemctl list-units --type=service --all --no-pager --no-legend 2>/dev/null'),
      sh('docker ps -a --format "{{.ID}}\\t{{.Image}}\\t{{.Status}}\\t{{.Ports}}\\t{{.Names}}" 2>/dev/null'),
      shPm2List(8000),
      sh('supervisorctl status 2>/dev/null || echo ""'),
      sh('ps -eo pid,ppid,user,%cpu,%mem,etime,cmd --no-header 2>/dev/null | grep -E "(node|python3?|ruby|php|gunicorn|uvicorn|puma|unicorn|bun|deno|go\\s)" | grep -v grep | head -60'),
    ]);

    // Parse ss: port → { pid, pname }
    const portsByPid = new Map();
    for (const line of ssOut.split('\n')) {
      const m = line.match(/(?:tcp|udp)\s+\S+\s+\d+\s+\d+\s+\S+:(\d+)\s+\S+\s+users:\(\("([^"]+)",pid=(\d+)/);
      if (!m) continue;
      const [, port, pname, pid] = [, m[1], m[2], m[3]];
      const k = parseInt(pid);
      if (!portsByPid.has(k)) portsByPid.set(k, { ports: [], pname });
      portsByPid.get(k).ports.push(parseInt(port));
    }

    // Parse systemctl
    const services = {};
    for (const line of svcOut.split('\n')) {
      const m = line.trim().match(/^(\S+)\.service\s+\S+\s+(\S+)\s+(\S+)\s+(.*)/);
      if (m) services[m[1]] = { active: m[2], sub: m[3], desc: m[4].trim() };
    }

    const iconMap = {
      nginx:'🌐', apache2:'🌐', httpd:'🌐', caddy:'🌐', traefik:'🌐',
      mysql:'🗄️', mariadb:'🗄️', mysqld:'🗄️',
      postgresql:'🐘', postgres:'🐘', 'postgresql@14':'🐘', 'postgresql@15':'🐘', 'postgresql@16':'🐘',
      redis:'🔴', 'redis-server':'🔴',
      mongodb:'🍃', mongod:'🍃',
      docker:'🐳', containerd:'🐳',
      ssh:'🔑', sshd:'🔑', openssh:'🔑',
      ufw:'🛡️', fail2ban:'🛡️', firewalld:'🛡️',
      node:'💚', nodejs:'💚',
      python3:'🐍', python:'🐍', gunicorn:'🐍', uvicorn:'🐍',
      php:'🔷', 'php-fpm':'🔷', php8:'🔷',
      certbot:'🔒', 'acme.sh':'🔒',
      grafana:'📊', 'grafana-server':'📊', prometheus:'📊',
      elasticsearch:'🔍', kibana:'🔍',
      rabbitmq:'🐰', kafka:'📨',
      nextcloud:'☁️', wordpress:'🌀',
      'minecraft-server':'⛏️', minecraft:'⛏️',
      plesk:'💼', cpanel:'💼',
      postfix:'📧', dovecot:'📧', sendmail:'📧',
      haproxy:'⚖️',
      varnish:'🚀',
    };

    function getIcon(name) {
      const lower = name.toLowerCase().replace(/-service$/, '').replace(/\.service$/, '');
      for (const [k, v] of Object.entries(iconMap)) {
        if (lower === k || lower.startsWith(k)) return v;
      }
      return '⚙️';
    }

    // Get MainPID for each running service
    const pidToService = new Map();
    const runningServices = Object.entries(services).filter(([, s]) => s.sub === 'running');
    await Promise.all(runningServices.map(async ([name]) => {
      const out = await sh(`systemctl show -p MainPID ${name} 2>/dev/null`, 2000);
      const m = out.match(/MainPID=(\d+)/);
      if (m && parseInt(m[1]) > 0) pidToService.set(parseInt(m[1]), name);
    }));

    const apps = [];
    const addedServices = new Set();

    // Build process/service apps from ports
    for (const [pid, { ports, pname }] of portsByPid) {
      const svcName = pidToService.get(pid);
      if (svcName && !addedServices.has(svcName)) {
        addedServices.add(svcName);
        apps.push({ id: 'svc:' + svcName, name: svcName, type: 'service', serviceName: svcName, pid, status: 'running', ports, icon: getIcon(svcName) || getIcon(pname), description: services[svcName]?.desc || '' });
      } else if (!svcName) {
        const ex = apps.find(a => a.type === 'process' && a.name === pname);
        if (ex) ex.ports.push(...ports);
        else apps.push({ id: 'proc:' + pname + ':' + pid, name: pname, type: 'process', pid, status: 'running', ports, icon: getIcon(pname), description: 'PID ' + pid });
      }
    }

    // Add all running services that didn't show up in ports
    for (const [name, info] of Object.entries(services)) {
      if (info.sub !== 'running') continue;
      if (addedServices.has(name)) continue;
      if (apps.find(a => a.id === 'svc:' + name)) continue;
      const skip = ['getty','systemd-','dbus','udev','accounts-','polkit','logind','timesyncd','networkd-','resolved','snapd','colord','rtkit','avahi','bluetooth','cups','ModemManager','packagekit','udisks'];
      if (skip.some(s => name.startsWith(s))) continue;
      apps.push({ id: 'svc:' + name, name, type: 'service', serviceName: name, status: 'running', ports: [], icon: getIcon(name), description: info.desc });
    }

    // Add known stopped services
    const known = ['nginx','apache2','httpd','mysql','mariadb','postgresql','redis','redis-server','mongodb','fail2ban','grafana-server','prometheus','postfix','dovecot','haproxy','varnish','caddy','traefik'];
    for (const name of known) {
      if (services[name] && services[name].sub !== 'running' && !apps.find(a => a.id === 'svc:' + name)) {
        const info = services[name];
        apps.push({ id: 'svc:' + name, name, type: 'service', serviceName: name, status: info.sub === 'failed' ? 'failed' : 'stopped', ports: [], icon: getIcon(name), description: info.desc });
      }
    }

    // Docker containers
    for (const line of dockerOut.split('\n').filter(Boolean)) {
      const parts = line.split('\t');
      if (parts.length < 5) continue;
      const [cid, image, status, portStr, name] = parts.map(p => p.trim());
      const running = status.startsWith('Up');
      const ports = [];
      for (const m of portStr.matchAll(/(\d+)->(\d+)\/tcp/g)) ports.push(parseInt(m[1]));
      apps.push({ id: 'docker:' + cid.slice(0, 12), name: name || cid.slice(0, 12), type: 'docker', image, status: running ? 'running' : 'stopped', ports, icon: '🐳', containerId: cid, description: image });
    }

    // ── pm2 managed apps ────────────────────────────────────────────────────
    try {
      const pm2Apps = JSON.parse(pm2Out || '[]');
      for (const p of pm2Apps) {
        const env = p.pm2_env || {};
        const id = 'pm2:' + (p.pm_id ?? p.name);
        if (apps.find(a => a.id === id)) continue;
        const running = env.status === 'online';
        const uptime = running && env.pm_uptime ? Math.floor((Date.now() - env.pm_uptime) / 1000) : null;
        const script = env.pm_exec_path || env.script || '';
        const pmArgs = env.args;
        apps.push({
          id,
          name: p.name || ('pm2-' + p.pm_id),
          type: 'custom',
          source: 'pm2',
          pid: p.pid || null,
          status: running ? 'running' : (env.status === 'errored' ? 'failed' : 'stopped'),
          ports: [],
          icon: getIcon(p.name) || '💚',
          description: script ? script.replace(/^.*\//, '') : ('pm2 #' + p.pm_id),
          uptime,
          cpu: env.monit ? env.monit.cpu : null,
          mem: env.monit ? env.monit.memory : null,
          // For “Add to My Apps”: /proc/cmdline is often overwritten by PM2 / process.title — use PM2 metadata.
          pmExecPath: script || null,
          pmCwd: env.pm_cwd || null,
          pmArgs: Array.isArray(pmArgs) ? pmArgs : (pmArgs != null && pmArgs !== '' ? [pmArgs] : []),
          pmInterpreter: env.exec_interpreter || 'node',
        });
      }
    } catch (_) {}

    // ── supervisor managed apps ──────────────────────────────────────────────
    if (supOut) {
      for (const line of supOut.split('\n').filter(Boolean)) {
        const m = line.match(/^(\S+)\s+(RUNNING|STOPPED|FATAL|STARTING|STOPPING|EXITED|BACKOFF)\s+(.*)$/i);
        if (!m) continue;
        const [, name, rawStatus, detail] = m;
        const id = 'sup:' + name;
        if (apps.find(a => a.id === id)) continue;
        const status = rawStatus.toLowerCase() === 'running' ? 'running'
          : rawStatus.toLowerCase() === 'fatal' ? 'failed' : 'stopped';
        const pidM = detail.match(/pid (\d+)/);
        apps.push({
          id,
          name,
          type: 'custom',
          source: 'supervisor',
          pid: pidM ? parseInt(pidM[1]) : null,
          status,
          ports: [],
          icon: getIcon(name) || '⚙️',
          description: detail.trim(),
        });
      }
    }

    // ── bare custom processes (node/python/etc not already captured) ─────────
    const customProcPids = new Set(apps.map(a => a.pid).filter(Boolean));
    for (const line of procOut.split('\n').filter(Boolean)) {
      const parts = line.trim().split(/\s+/);
      if (parts.length < 7) continue;
      const [pid, , user, cpu, mem, etime, ...cmdParts] = parts;
      const pidNum = parseInt(pid);
      if (customProcPids.has(pidNum)) continue;
      // Skip system/root processes that are clearly not custom apps
      const cmd = cmdParts.join(' ');
      const exe = cmdParts[0] || '';
      if (exe.startsWith('-') || cmd.includes('apt') || cmd.includes('systemd') || cmd.includes('sshd') || cmd.includes('/usr/lib')) continue;
      // Use the script name as app name
      const scriptArg = cmdParts.find(a => a.endsWith('.js') || a.endsWith('.py') || a.endsWith('.rb') || a.endsWith('.ts'));
      const appName = scriptArg ? scriptArg.replace(/^.*\//, '') : exe.replace(/^.*\//, '');
      if (!appName || appName.length < 2) continue;
      const existingId = 'proc:' + appName + ':' + pidNum;
      if (apps.find(a => a.id === existingId || (a.pid === pidNum))) continue;
      customProcPids.add(pidNum);
      apps.push({
        id: existingId,
        name: appName,
        type: 'custom',
        source: 'process',
        pid: pidNum,
        user,
        status: 'running',
        ports: portsByPid.has(pidNum) ? portsByPid.get(pidNum).ports : [],
        icon: getIcon(appName) || (exe.includes('node') || exe.includes('bun') ? '💚' : exe.includes('python') ? '🐍' : exe.includes('ruby') ? '💎' : '⚙️'),
        description: cmd.slice(0, 80),
        cpu: parseFloat(cpu),
        mem: parseFloat(mem),
        etime,
      });
    }

    apps.sort((a, b) => {
      const rank = { running: 0, failed: 1, stopped: 2 };
      const ra = rank[a.status] ?? 3, rb = rank[b.status] ?? 3;
      if (ra !== rb) return ra - rb;
      // custom apps float to top within their status group
      if (a.type === 'custom' && b.type !== 'custom') return -1;
      if (b.type === 'custom' && a.type !== 'custom') return 1;
      return a.name.localeCompare(b.name);
    });

    let myAppsDiscoveryIds = [];
    try {
      const raw = fs.readFileSync(MYAPPS_USER_STORE, 'utf8');
      const st = JSON.parse(raw);
      myAppsDiscoveryIds = (st.entries || []).map(e => e.discoveryId).filter(Boolean);
    } catch (_) {}

    res.json({ apps, myAppsDiscoveryIds });
  });

  // ── Apps: start / stop / restart ──────────────────────────────────────────
  app.post('/api/apps/action', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    const { id, action } = req.body || {};
    const allowed = ['start', 'stop', 'restart', 'enable', 'disable'];
    if (!allowed.includes(action)) return res.status(400).json({ error: 'Invalid action' });
    const isPm2 = typeof id === 'string' && id.startsWith('pm2:');
    const needsSudo = !isPm2 || !pm2RunsAsDriftUser(cfg);
    if (needsSudo && !cred) return res.status(403).json({ error: 'Sudo auth required' });

    if (id.startsWith('svc:')) {
      const r = await sudoRun(cred, `systemctl ${action} ${id.slice(4)}`);
      return res.json({ ok: r.ok, output: r.output });
    }
    if (id.startsWith('docker:')) {
      const act = action === 'enable' ? 'start' : action === 'disable' ? 'stop' : action;
      const r = await sudoRun(cred, `docker ${act} ${id.slice(7)}`);
      return res.json({ ok: r.ok, output: r.output });
    }
    if (id.startsWith('pm2:')) {
      const target = id.slice(4);
      const pm2Action = action === 'enable' ? 'start' : action === 'disable' ? 'stop' : action;
      if (/[^a-zA-Z0-9_.:@/-]/.test(target)) {
        return res.status(400).json({ ok: false, output: 'Invalid PM2 process id/name' });
      }
      const safe = target;
      const r = await runPm2Cmd(cfg, cred, `pm2 ${pm2Action} ${safe} 2>&1`, 20000);
      return res.json({ ok: r.ok, output: r.output });
    }
    if (id.startsWith('sup:')) {
      const name = id.slice(4);
      const supAction = action === 'enable' ? 'start' : action === 'disable' ? 'stop' : action;
      const r = await sudoRun(cred, `supervisorctl ${supAction} ${name}`);
      return res.json({ ok: r.ok, output: r.output });
    }
    if ((id.startsWith('proc:') || id.startsWith('pm2:') || id.startsWith('sup:')) && action === 'stop') {
      const pid = id.split(':')[2];
      if (pid) {
        const r = await sudoRun(cred, `kill ${pid}`);
        return res.json({ ok: r.ok, output: r.output });
      }
    }
    res.status(400).json({ error: 'Cannot perform this action on this app type' });
  });

  // ── Apps: logs ────────────────────────────────────────────────────────────
  app.get('/api/apps/logs', auth, async (req, res) => {
    const { id, lines = 150 } = req.query;
    if (!id) return res.status(400).json({ error: 'Missing id' });
    const n = parseInt(lines);
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    let cmd;
    if (id.startsWith('svc:')) cmd = `journalctl -u ${id.slice(4)} -n ${n} --no-pager --output=short-iso 2>/dev/null`;
    else if (id.startsWith('docker:')) cmd = `docker logs --tail ${n} ${id.slice(7)} 2>&1`;
    else if (id.startsWith('pm2:')) {
      const log = id.slice(4);
      if (/[^a-zA-Z0-9_.:@/-]/.test(log)) return res.status(400).json({ error: 'Unsupported type' });
      if (!pm2RunsAsDriftUser(cfg) && !cred) return res.status(403).json({ error: 'Sudo auth required' });
      const inner = `pm2 logs ${log} --lines ${n} --nostream 2>/dev/null || pm2 logs ${log} --lines ${n} 2>&1 | head -${n}`;
      const r = await runPm2Cmd(cfg, cred, inner, 10000);
      return res.json({ output: (r.output || '').trim() });
    } else if (id.startsWith('sup:')) cmd = `tail -n ${n} /var/log/supervisor/${id.slice(4)}-stdout.log 2>/dev/null || journalctl -t ${id.slice(4)} -n ${n} --no-pager 2>/dev/null || echo "No logs available"`;
    else if (id.startsWith('proc:')) { const pid = id.split(':')[2]; cmd = `journalctl _PID=${pid} -n ${n} --no-pager 2>/dev/null || echo "No logs available for this process"`; }
    else return res.status(400).json({ error: 'Unsupported type' });
    require('child_process').exec(cmd, { timeout: 10000, maxBuffer: 2 * 1024 * 1024 }, (e, o) => res.json({ output: (o || '').trim() }));
  });

  // ── Apps: change port ─────────────────────────────────────────────────────
  app.post('/api/apps/port', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { id, oldPort, newPort } = req.body || {};
    if (!oldPort || !newPort || isNaN(newPort) || newPort < 1 || newPort > 65535)
      return res.status(400).json({ error: 'Invalid port values' });
    if (!id.startsWith('svc:')) return res.status(400).json({ error: 'Port editing only supported for system services' });

    const svcName = id.slice(4);
    const configFiles = {
      nginx: ['/etc/nginx/nginx.conf', '/etc/nginx/sites-enabled/default'],
      apache2: ['/etc/apache2/ports.conf'],
      httpd: ['/etc/httpd/conf/httpd.conf'],
      mysql: ['/etc/mysql/mysql.conf.d/mysqld.cnf', '/etc/mysql/my.cnf'],
      redis: ['/etc/redis/redis.conf'],
      mongodb: ['/etc/mongod.conf'],
      caddy: ['/etc/caddy/Caddyfile'],
    };
    const files = configFiles[svcName];
    if (!files) return res.status(400).json({ error: `Auto port-change not supported for "${svcName}". Edit the config file in the Files manager.` });

    // Try each known config file
    const { execSync: es } = require('child_process');
    let changed = false;
    let changedFile = '';
    for (const f of files) {
      try {
        const content = es(`cat ${f} 2>/dev/null`, { timeout: 2000 }).toString();
        if (content.includes(String(oldPort))) {
          const r = await sudoRun(cred, `sed -i 's/\\b${oldPort}\\b/${newPort}/g' ${f}`);
          if (r.ok) { changed = true; changedFile = f; break; }
        }
      } catch (_) {}
    }
    if (!changed) return res.status(404).json({ error: `Port ${oldPort} not found in config files for ${svcName}` });

    const r2 = await sudoRun(cred, `systemctl restart ${svcName}`);
    res.json({ ok: true, message: `Port changed in ${changedFile}. ${svcName} restarted.`, restarted: r2.ok });
  });

  // ── PM2: list ─────────────────────────────────────────────────────────────
  app.get('/api/pm2/list', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    try {
      const r = await runPm2Cmd(cfg, cred, 'pm2 jlist 2>/dev/null', 8000);
      const out = (r.output || '').trim();
      if (!out || out === '[]') return res.json({ apps: [], unavailable: true });
      try {
        const raw = JSON.parse(out);
        const apps = raw.map(p => ({
          id: p.pm_id,
          name: p.name,
          pid: p.pid || null,
          status: p.pm2_env?.status || 'stopped',
          cpu: p.monit?.cpu ?? null,
          mem: p.monit?.memory ?? null,
          uptime: (p.pm2_env?.status === 'online' && p.pm2_env?.pm_uptime)
            ? Math.floor((Date.now() - p.pm2_env.pm_uptime) / 1000) : null,
          restarts: p.pm2_env?.restart_time ?? 0,
          script: p.pm2_env?.pm_exec_path || p.pm2_env?.script || '',
          mode: p.pm2_env?.exec_mode || 'fork',
          watching: p.pm2_env?.watch || false,
          namespace: p.pm2_env?.namespace || 'default',
        }));
        res.json({ apps });
      } catch (e) {
        res.json({ apps: [], error: 'Parse error: ' + e.message });
      }
    } catch (e) {
      res.json({ apps: [], error: e.message || String(e) });
    }
  });

  // ── PM2: action (same PM2 user as Applications — see web.pm2User / DRIFT_PM2_USER)
  app.post('/api/pm2/action', auth, async (req, res) => {
    const { id, action } = req.body || {};
    const allowed = ['start', 'stop', 'restart', 'reload', 'delete'];
    if (!allowed.includes(action)) return res.status(400).json({ error: 'Invalid action' });
    if (id === undefined || id === null) return res.status(400).json({ error: 'Missing id' });
    const idStr = String(id);
    if (!/^[\w@.-]+$/.test(idStr)) return res.status(400).json({ error: 'Invalid id' });
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!pm2RunsAsDriftUser(cfg) && !cred) return res.status(403).json({ error: 'Sudo auth required' });
    const r = await runPm2Cmd(cfg, cred, `pm2 ${action} ${idStr} 2>&1`, 15000);
    res.json({ ok: r.ok, output: r.output });
  });

  // ── PM2: start a new process ───────────────────────────────────────────────
  app.post('/api/pm2/start', auth, async (req, res) => {
    const { script, name, args, watch } = req.body || {};
    if (!script) return res.status(400).json({ error: 'Missing script path' });
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!pm2RunsAsDriftUser(cfg) && !cred) return res.status(403).json({ error: 'Sudo auth required' });
    const safeName = name ? `--name ${JSON.stringify(String(name).replace(/[^a-zA-Z0-9_.-]/g, '_'))} ` : '';
    const safeScript = JSON.stringify(String(script));
    const watchFlag = watch ? '--watch ' : '';
    const argsStr = args ? ` -- ${String(args)}` : '';
    const inner = `pm2 start ${safeScript} ${safeName}${watchFlag}2>&1${argsStr}`;
    const r = await runPm2Cmd(cfg, cred, inner, 20000);
    res.json({ ok: r.ok, output: r.output });
  });

  // ── PM2: logs ─────────────────────────────────────────────────────────────
  app.get('/api/pm2/logs', auth, async (req, res) => {
    const { id, lines = 120 } = req.query;
    const n = parseInt(lines);
    const target = id !== undefined ? String(id) : 'all';
    if (target !== 'all' && !/^[\w@.-]+$/.test(target)) return res.status(400).json({ error: 'Invalid id' });
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!pm2RunsAsDriftUser(cfg) && !cred) return res.status(403).json({ error: 'Sudo auth required' });
    const inner = `pm2 logs ${target} --lines ${n} --nostream --raw 2>&1 | tail -n ${n}`;
    const r = await runPm2Cmd(cfg, cred, inner, 12000);
    res.json({ output: (r.output || 'No logs available').trim() });
  });

  // ── PM2: save process list ─────────────────────────────────────────────────
  app.post('/api/pm2/save', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!pm2RunsAsDriftUser(cfg) && !cred) return res.status(403).json({ error: 'Sudo auth required' });
    const r = await runPm2Cmd(cfg, cred, 'pm2 save 2>&1', 10000);
    res.json({ ok: r.ok, output: r.output });
  });

  // ── Apps: get config file paths for a service ─────────────────────────────
  app.get('/api/apps/config', auth, (req, res) => {
    const { id } = req.query;
    if (!id || !id.startsWith('svc:')) return res.status(400).json({ error: 'Services only' });
    const svcName = id.slice(4);
    const { execSync: es } = require('child_process');
    let unitFile = '';
    let configFiles = [];
    try {
      unitFile = es(`systemctl show -p FragmentPath ${svcName} 2>/dev/null`, { timeout: 3000 }).toString().match(/FragmentPath=(.*)/)?.[1]?.trim() || '';
    } catch (_) {}
    const knownConfigs = {
      nginx: ['/etc/nginx/nginx.conf', '/etc/nginx/sites-available', '/etc/nginx/sites-enabled'],
      apache2: ['/etc/apache2/apache2.conf', '/etc/apache2/ports.conf', '/etc/apache2/sites-enabled'],
      mysql: ['/etc/mysql/mysql.conf.d/mysqld.cnf'],
      mariadb: ['/etc/mysql/mariadb.conf.d/50-server.cnf'],
      redis: ['/etc/redis/redis.conf'],
      postgresql: ['/etc/postgresql'],
      mongodb: ['/etc/mongod.conf'],
      caddy: ['/etc/caddy/Caddyfile'],
      postfix: ['/etc/postfix/main.cf'],
    };
    configFiles = knownConfigs[svcName] || [];
    res.json({ unitFile, configFiles });
  });

  // ── My Apps ───────────────────────────────────────────────────────────────────
  const MYAPPS_PID_FILE = path.join(os.homedir(), '.drift-myapps-pids.json');

  function myappReadPids() {
    try { return JSON.parse(fs.readFileSync(MYAPPS_PID_FILE, 'utf8')); } catch { return {}; }
  }
  function myappWritePids(pids) {
    try { fs.writeFileSync(MYAPPS_PID_FILE, JSON.stringify(pids, null, 2), 'utf8'); } catch {}
  }
  function myappIsAlive(pid) {
    const n = parseInt(pid, 10);
    if (!n || n < 1) return false;
    try {
      process.kill(n, 0);
      return true;
    } catch (e) {
      // Other users' PIDs: kill(0) returns EPERM even when the process is running.
      if (process.platform === 'linux' && e && e.code === 'EPERM') {
        try {
          return fs.existsSync(`/proc/${n}`);
        } catch (_) {
          return false;
        }
      }
      return false;
    }
  }

  // No bundled presets — My Apps is filled only via Applications (this host) + manual add.
  const MY_APPS = [];

  /** Real path to this package's bin/drift.js (for matching discovered / PM2 shortcuts). */
  function myappDriftEntryScriptPath() {
    try {
      return fs.realpathSync(path.join(__dirname, '..', 'bin', 'drift.js'));
    } catch {
      return null;
    }
  }
  function myappPortCfgIfDriftWeb(scriptPath, portHint) {
    const driftEntry = myappDriftEntryScriptPath();
    if (!driftEntry || !scriptPath) return null;
    try {
      const rp = fs.realpathSync(scriptPath);
      if (rp === driftEntry) {
        const d = parseInt(portHint, 10);
        return { type: 'drift-config', default: Number.isFinite(d) && d > 0 ? d : 7473 };
      }
    } catch (_) {}
    return null;
  }
  function myappSpawnPortCfg(primaryScript, a) {
    const hint = a.ports && a.ports[0];
    const drift = primaryScript && myappPortCfgIfDriftWeb(primaryScript, hint);
    if (drift) return drift;
    return { type: 'static', default: hint || 3000 };
  }

  function myappReadUserStore() {
    try {
      const d = JSON.parse(fs.readFileSync(MYAPPS_USER_STORE, 'utf8'));
      return {
        entries: Array.isArray(d.entries) ? d.entries : [],
        hiddenBuiltinIds: Array.isArray(d.hiddenBuiltinIds) ? d.hiddenBuiltinIds : [],
      };
    } catch {
      return { entries: [], hiddenBuiltinIds: [] };
    }
  }
  function myappWriteUserStore(store) {
    try {
      fs.writeFileSync(MYAPPS_USER_STORE, JSON.stringify(store, null, 2) + '\n', 'utf8');
    } catch (_) {}
  }
  function myappGetMergedDefs() {
    const store = myappReadUserStore();
    const hidden = new Set(store.hiddenBuiltinIds || []);
    const builtin = MY_APPS.filter(d => !hidden.has(d.id));
    const user = (store.entries || []).map(e => ({ ...e, kind: e.kind || 'spawn' }));
    return { defs: [...builtin, ...user], store };
  }
  function myappFindDef(id) {
    const { defs } = myappGetMergedDefs();
    return defs.find(d => d.id === id);
  }
  function readProcCmdline(pid) {
    try {
      const raw = fs.readFileSync(`/proc/${parseInt(pid, 10)}/cmdline`, 'utf8');
      return raw.split('\0').filter(Boolean);
    } catch {
      return null;
    }
  }
  function readProcCwd(pid) {
    try {
      return fs.realpathSync(`/proc/${parseInt(pid, 10)}/cwd`);
    } catch {
      return null;
    }
  }
  function myappIsNodeInterpreter(cmdPath) {
    if (!cmdPath) return false;
    const b = path.basename(cmdPath).replace(/\.exe$/i, '');
    return b === 'node' || b === 'nodejs';
  }
  /** Integers, shells, and common language runtimes (for argv parsing and empty-args rules). */
  function myappIsRuntimeInterpreter(cmdPath) {
    if (!cmdPath) return false;
    const b = path.basename(cmdPath).replace(/\.exe$/i, '');
    return ['node', 'nodejs', 'bun', 'deno', 'python', 'python3', 'ruby', 'ruby3'].includes(b);
  }
  const MYAPP_SCRIPT_EXT = /\.(js|cjs|mjs|ts|tsx|mts|cts|py|rb)$/i;
  const MYAPP_SHELL_BASE = new Set(['sh', 'bash', 'dash', 'zsh', 'fish']);
  const MYAPP_FLAG_TAKES_NEXT = new Set([
    '-r', '--require', '--import', '-e', '--eval', '-p', '--print',
    '--inspect', '--inspect-brk', '--inspect-port', '--loader',
    '-C', '--config', '--openssl-config', '--cpu-prof', '--heap-prof',
    '-i', '--interactive',
  ]);
  /** `/usr/bin/env node app.js` / `env VAR=1 node app.js` / `env -S "node --harmony app.js"` → real interpreter + argv */
  function myappUnwrapEnvIfNeeded(exe, args) {
    const base = path.basename(exe || '').replace(/\.exe$/i, '');
    if (base !== 'env') return { exe, args: args.slice() };
    const a = args.slice();
    if (a.length >= 2 && a[0] === '-S') {
      const parts = String(a[1] || '').trim().split(/\s+/).filter(Boolean);
      if (parts.length) return { exe: parts[0], args: parts.slice(1) };
    }
    let i = 0;
    while (i < a.length && /^[A-Za-z_][A-Za-z0-9_]*=/.test(a[i])) i++;
    while (i < a.length) {
      const x = a[i];
      if (x === '-u' || x === '--unset') {
        if (i + 1 < a.length) i += 2;
        else i += 1;
        continue;
      }
      if (x === '-S' || x === '--split-arguments') {
        if (i + 1 < a.length) {
          const parts = String(a[i + 1]).trim().split(/\s+/).filter(Boolean);
          return { exe: parts[0] || exe, args: parts.slice(1) };
        }
        break;
      }
      if (x === '-i' || x === '--ignore-environment' || x === '-0' || x === '--null' || x === '-v' || x === '--version' || x === '--help') {
        i += 1;
        continue;
      }
      if (x.startsWith('-')) {
        i += 1;
        continue;
      }
      break;
    }
    if (i >= a.length) return { exe, args: a };
    return { exe: a[i], args: a.slice(i + 1) };
  }
  function myappShellDashCIndex(exe, args) {
    const base = path.basename(exe || '').replace(/\.exe$/i, '');
    if (!MYAPP_SHELL_BASE.has(base)) return -1;
    const idx = args.findIndex((a, i) => a === '-c' && args[i + 1] != null && args[i + 1] !== '');
    return idx;
  }
  /** Collect main script paths from argv (skip runtimes flags; `--`; `--require=` forms). */
  function myappCollectDetectInFromArgs(args, cwd) {
    const detectIn = [];
    const pushCandidate = (raw, abs) => {
      try {
        if (fs.existsSync(abs) && fs.statSync(abs).isFile()) detectIn.push(abs);
      } catch (_) {}
      if (MYAPP_SCRIPT_EXT.test(raw) && !detectIn.includes(abs)) detectIn.push(abs);
    };
    for (let i = 0; i < args.length; i++) {
      const arg = args[i];
      if (!arg) continue;
      const longEq = arg.match(/^--(require|import|preload)=(.+)$/);
      if (longEq && longEq[2]) {
        const val = longEq[2];
        const abs = path.isAbsolute(val) ? val : path.join(cwd, val);
        pushCandidate(val, abs);
        continue;
      }
      if (MYAPP_FLAG_TAKES_NEXT.has(arg)) {
        if (i + 1 < args.length) i++;
        continue;
      }
      if (arg === '--') {
        for (let j = i + 1; j < args.length; j++) {
          const a2 = args[j];
          if (!a2) continue;
          const abs2 = path.isAbsolute(a2) ? a2 : path.join(cwd, a2);
          pushCandidate(a2, abs2);
        }
        break;
      }
      if (arg.startsWith('-')) continue;
      const abs = path.isAbsolute(arg) ? arg : path.join(cwd, arg);
      pushCandidate(arg, abs);
    }
    return detectIn;
  }
  /** Last non-flag token is often the entry script (node --experimental… ./app.js). */
  function myappFallbackDetectScript(exe, args, cwd) {
    if (!myappIsRuntimeInterpreter(exe)) return [];
    for (let i = args.length - 1; i >= 0; i--) {
      const arg = args[i];
      if (!arg || arg.startsWith('-')) continue;
      const abs = path.isAbsolute(arg) ? arg : path.join(cwd, arg);
      try {
        if (fs.existsSync(abs) && fs.statSync(abs).isFile()) return [abs];
      } catch (_) {}
      if (MYAPP_SCRIPT_EXT.test(arg)) return [abs];
    }
    return [];
  }
  /** Parse `sh -c "node app.js --flags"` / npm env prefixes. */
  function myappDetectFromDashC(inner, cwd) {
    if (!inner || typeof inner !== 'string') return [];
    let s = inner.trim()
      .replace(/^\s*(?:export\s+)?(?:[A-Za-z_][A-Za-z0-9_]*=(?:'[^']*'|"[^"]*"|[^\s]+)\s+)+/i, '');
    const tokens = s.split(/\s+/).filter(Boolean);
    const skipBase = new Set(['node', 'nodejs', 'bun', 'deno', 'python', 'python3', 'ruby', 'ruby3', 'npm', 'npx', 'yarn', 'pnpm', 'corepack']);
    const out = [];
    for (const t of tokens) {
      if (!t || t.startsWith('-') || /^[A-Za-z_][A-Za-z0-9_]*=/.test(t)) continue;
      const base = path.basename(t).replace(/\.exe$/i, '');
      if (skipBase.has(base)) continue;
      const abs = path.isAbsolute(t) ? t : path.join(cwd, t);
      try {
        if (fs.existsSync(abs) && fs.statSync(abs).isFile()) {
          out.push(abs);
          break;
        }
      } catch (_) {}
      if (MYAPP_SCRIPT_EXT.test(t)) {
        out.push(abs);
        break;
      }
    }
    return out;
  }
  function myappSpawnExe(def) {
    if (def.cmd === 'node') return process.env.DRIFT_MYAPPS_NODE || process.execPath;
    if (myappIsNodeInterpreter(def.cmd)) return process.env.DRIFT_MYAPPS_NODE || def.cmd;
    return def.cmd;
  }
  function buildUserEntryFromDiscovery(a) {
    const isDocker = a.type === 'docker' || (a.id && String(a.id).startsWith('docker:'));
    if (isDocker && a.containerId) {
      return {
        entry: {
          id: `user:${crypto.randomBytes(6).toString('hex')}`,
          discoveryId: a.id,
          kind: 'docker',
          name: a.name || 'Container',
          icon: a.icon || '🐳',
          description: a.description || a.image || '',
          containerId: a.containerId,
          port: { type: 'static', default: (a.ports && a.ports[0]) || 80 },
        },
      };
    }

    // PM2: process.title / argv masking often yields useless /proc/<pid>/cmdline — use jlist fields we already have.
    if (a.source === 'pm2' && a.pmExecPath && String(a.pmExecPath).trim()) {
      const scriptPath = path.resolve(String(a.pmExecPath).trim());
      if (fs.existsSync(scriptPath) && fs.statSync(scriptPath).isFile()) {
        const cwdOptRaw = (a.pmCwd && String(a.pmCwd).trim()) || '';
        let dir = cwdOptRaw && fs.existsSync(cwdOptRaw) ? path.resolve(cwdOptRaw) : path.dirname(scriptPath);
        if (!fs.existsSync(dir)) dir = path.dirname(scriptPath);
        let extra = [];
        if (Array.isArray(a.pmArgs)) extra = a.pmArgs.map(String);
        else if (a.pmArgs != null && a.pmArgs !== '') extra = [String(a.pmArgs)];
        const interpRaw = String(a.pmInterpreter || 'node').trim() || 'node';
        const il = interpRaw.toLowerCase();
        let cmd = 'node';
        if (il.includes('python')) cmd = il.includes('python3') || il.includes('3') ? 'python3' : 'python';
        else if (il.includes('bun')) cmd = 'bun';
        else if (il.includes('deno')) cmd = 'deno';
        else if (il.includes('ruby')) cmd = 'ruby';
        else if (il.includes('node') || il === 'none' || il === '') cmd = 'node';
        else cmd = interpRaw;
        const args = [scriptPath, ...extra];
        return {
          entry: {
            id: `user:${crypto.randomBytes(6).toString('hex')}`,
            discoveryId: a.id,
            kind: 'spawn',
            name: (a.name || path.basename(scriptPath)).slice(0, 80),
            icon: a.icon || '💚',
            description: (a.description || '').slice(0, 200),
            dir,
            cmd,
            args,
            detectIn: [scriptPath],
            port: myappSpawnPortCfg(scriptPath, a),
          },
        };
      }
    }

    const pid = parseInt(a.pid, 10);
    if (!pid || !myappIsAlive(pid)) return { error: 'Process not found — start the app first, then add it while it is running.' };
    if (process.platform !== 'linux') return { error: 'Adding processes from discovery requires Linux (/proc).' };
    const cmdline = readProcCmdline(pid);
    const cwd = readProcCwd(pid);
    if (!cmdline || cmdline.length === 0 || !cwd) return { error: 'Cannot read process command line' };
    let exe = cmdline[0];
    let args = cmdline.slice(1);
    const envUnwrapped = myappUnwrapEnvIfNeeded(exe, args);
    exe = envUnwrapped.exe;
    args = envUnwrapped.args;
    const shellIdx = myappShellDashCIndex(exe, args);
    const exeBaseNoDash = path.basename(exe || '').replace(/^-/, '').replace(/\.exe$/i, '');
    // Many runtimes expose only argv[0] as the script/binary path (packaging, some supervisors).
    if (args.length === 0 && !myappIsRuntimeInterpreter(exe)) {
      if (MYAPP_SHELL_BASE.has(exeBaseNoDash)) {
        return { error: 'Unsupported process (no script arguments)' };
      }
      let solePath = null;
      try {
        const cand = path.isAbsolute(exe) ? exe : path.join(cwd, exe);
        const rp = fs.realpathSync(cand);
        if (fs.existsSync(rp) && fs.statSync(rp).isFile()) solePath = rp;
      } catch (_) {}
      if (!solePath) {
        return { error: 'Unsupported process (no script arguments)' };
      }
      const runWithNode = MYAPP_SCRIPT_EXT.test(solePath);
      return {
        entry: {
          id: `user:${crypto.randomBytes(6).toString('hex')}`,
          discoveryId: a.id,
          kind: 'spawn',
          name: (a.name || path.basename(solePath)).slice(0, 80),
          icon: a.icon || '⚙️',
          description: (a.description || '').slice(0, 200),
          dir: cwd,
          cmd: runWithNode ? 'node' : solePath,
          args: runWithNode ? [solePath] : [],
          detectIn: [solePath],
          port: myappSpawnPortCfg(solePath, a),
        },
      };
    }

    if (shellIdx >= 0) {
      const inner = String(args[shellIdx + 1] || '');
      let detectIn = myappDetectFromDashC(inner, cwd);
      if (detectIn.length === 0) {
        try {
          const pseudo = inner.trim().split(/\s+/).filter(Boolean);
          detectIn = myappCollectDetectInFromArgs(pseudo, cwd);
        } catch (_) {}
      }
      if (detectIn.length === 0) {
        return {
          error: 'Could not resolve a script path (e.g. npm run / complex shell -c). Use My Apps → Add app and enter the start command manually.',
        };
      }
      return {
        entry: {
          id: `user:${crypto.randomBytes(6).toString('hex')}`,
          discoveryId: a.id,
          kind: 'spawn',
          name: (a.name || path.basename(detectIn[0])).slice(0, 80),
          icon: a.icon || '⚙️',
          description: (a.description || '').slice(0, 200),
          dir: cwd,
          cmd: exe,
          args: ['-c', inner],
          detectIn: [...new Set(detectIn)],
          port: myappSpawnPortCfg(detectIn[0], a),
        },
      };
    }

    let detectIn = myappCollectDetectInFromArgs(args, cwd);
    if (detectIn.length === 0) detectIn = myappFallbackDetectScript(exe, args, cwd);
    if (detectIn.length === 0) {
      return {
        error: 'Could not resolve a script path for this process — try My Apps → Add app manually, or start the app with a normal node/bun command line (not only npm run without a file in argv).',
      };
    }
    const spawnArgs = args.map(arg => {
      if (!path.isAbsolute(arg) && MYAPP_SCRIPT_EXT.test(arg)) return path.join(cwd, arg);
      return arg;
    });
    const cmd = myappIsNodeInterpreter(exe) ? 'node' : exe;
    const normArgs = myappIsRuntimeInterpreter(exe) ? spawnArgs : args;
    return {
      entry: {
        id: `user:${crypto.randomBytes(6).toString('hex')}`,
        discoveryId: a.id,
        kind: 'spawn',
        name: (a.name || path.basename(detectIn[0])).slice(0, 80),
        icon: a.icon || '⚙️',
        description: (a.description || '').slice(0, 200),
        dir: cwd,
        cmd,
        args: normArgs,
        detectIn: [...new Set(detectIn)],
        port: myappSpawnPortCfg(detectIn[0], a),
      },
    };
  }

  function myappReadPort(portCfg) {
    try {
      if (portCfg.type === 'static') return portCfg.default;
      if (portCfg.type === 'env') {
        if (!fs.existsSync(portCfg.file)) return portCfg.default;
        const line = fs.readFileSync(portCfg.file, 'utf8').split('\n').find(l => l.startsWith(portCfg.key + '='));
        return line ? (parseInt(line.split('=')[1]) || portCfg.default) : portCfg.default;
      }
      if (portCfg.type === 'json') {
        const data = JSON.parse(fs.readFileSync(portCfg.file, 'utf8'));
        let v = data;
        for (const k of portCfg.key.split('.')) v = v?.[k];
        return parseInt(v) || portCfg.default;
      }
      if (portCfg.type === 'drift-config') {
        resetCache();
        return loadConfig().web.port;
      }
    } catch {}
    return portCfg.default;
  }

  function myappWritePort(portCfg, newPort) {
    if (portCfg.type === 'env') {
      let content = '';
      try { content = fs.readFileSync(portCfg.file, 'utf8'); } catch {}
      const lines = content.split('\n');
      let found = false;
      const updated = lines.map(l => {
        if (l.startsWith(portCfg.key + '=')) { found = true; return `${portCfg.key}=${newPort}`; }
        return l;
      });
      if (!found) updated.unshift(`${portCfg.key}=${newPort}`);
      fs.writeFileSync(portCfg.file, updated.join('\n'), 'utf8');
    } else if (portCfg.type === 'json') {
      const data = JSON.parse(fs.readFileSync(portCfg.file, 'utf8'));
      const keys = portCfg.key.split('.');
      let v = data;
      for (let i = 0; i < keys.length - 1; i++) v = v[keys[i]];
      v[keys[keys.length - 1]] = newPort;
      fs.writeFileSync(portCfg.file, JSON.stringify(data, null, 2) + '\n', 'utf8');
    } else if (portCfg.type === 'drift-config') {
      saveConfig({ web: { port: newPort } });
      resetCache();
    }
  }

  app.get('/api/myapps/list', auth, (req, res) => {
    const pids = myappReadPids();
    const { execSync: es } = require('child_process');
    let psOut = '';
    try { psOut = es('ps -eo pid,cmd --no-header 2>/dev/null', { timeout: 3000 }).toString(); } catch {}

    const { defs } = myappGetMergedDefs();
    const result = defs.map(def => {
      const isUser = def.id.startsWith('user:');
      const isBuiltin = def.id.startsWith('myapp:');
      const discoveryId = def.discoveryId || null;

      if (def.kind === 'docker') {
        let running = false;
        try {
          const o = es(`docker inspect -f '{{.State.Running}}' ${def.containerId} 2>/dev/null`, { timeout: 8000 }).toString().trim();
          running = o === 'true';
        } catch (_) {}
        return {
          id: def.id, name: def.name, icon: def.icon, description: def.description, dir: '',
          status: running ? 'running' : 'stopped', pid: null, port: myappReadPort(def.port),
          portType: def.port?.type || 'static',
          kind: 'docker', userManaged: isUser, isBuiltin, discoveryId,
        };
      }

      let pid = pids[def.id] ? parseInt(pids[def.id]) : null;
      let running = !!(pid && myappIsAlive(pid));

      if (!running) {
        pid = null;
        for (const line of psOut.split('\n')) {
          if (def.detectIn && def.detectIn.some(p => line.includes(p))) {
            const m = line.trim().match(/^(\d+)/);
            if (m) { pid = parseInt(m[1]); running = true; break; }
          }
        }
        if (running && pid) { pids[def.id] = pid; myappWritePids(pids); }
        else if (!running && pids[def.id]) { delete pids[def.id]; myappWritePids(pids); }
      }

      return {
        id: def.id, name: def.name, icon: def.icon, description: def.description, dir: def.dir,
        status: running ? 'running' : 'stopped', pid: pid || null, port: myappReadPort(def.port),
        portType: def.port?.type || 'static',
        kind: 'spawn', userManaged: isUser, isBuiltin, discoveryId,
      };
    });

    const discoveryIds = myappReadUserStore().entries.map(e => e.discoveryId).filter(Boolean);
    res.json({ apps: result, discoveryIds });
  });

  app.post('/api/myapps/action', auth, (req, res) => {
    const { id, action } = req.body || {};
    const def = myappFindDef(id);
    if (!def) return res.status(404).json({ error: 'Unknown app' });
    if (!['start', 'stop', 'restart'].includes(action)) return res.status(400).json({ error: 'Invalid action' });

    const pids = myappReadPids();
    const { spawn, execSync: es, execFile, execFileSync } = require('child_process');

    if (def.kind === 'docker') {
      try {
        if (action === 'stop') {
          execFileSync('docker', ['stop', def.containerId], { timeout: 120000, stdio: 'pipe' });
          return res.json({ ok: true, message: `${def.name} stopped` });
        }
        if (action === 'start') {
          execFile('docker', ['start', def.containerId], { timeout: 120000 }, err => {
            if (err) return res.status(400).json({ ok: false, error: err.message });
            res.json({ ok: true, message: `${def.name} started`, pid: null });
          });
          return;
        }
        if (action === 'restart') {
          try { execFileSync('docker', ['stop', def.containerId], { timeout: 120000, stdio: 'pipe' }); } catch (_) {}
          setTimeout(() => {
            execFile('docker', ['start', def.containerId], { timeout: 120000 }, err => {
              if (err) return res.status(400).json({ ok: false, error: err.message });
              res.json({ ok: true, message: `${def.name} restarted`, pid: null });
            });
          }, 800);
          return;
        }
      } catch (e) {
        return res.status(400).json({ ok: false, error: e.message || String(e) });
      }
    }

    function doStop() {
      const pid = pids[def.id] ? parseInt(pids[def.id]) : null;
      if (pid && myappIsAlive(pid)) try { process.kill(pid, 'SIGTERM'); } catch {}
      try {
        const psOut = es('ps -eo pid,cmd --no-header 2>/dev/null', { timeout: 3000 }).toString();
        if (def.detectIn) {
          for (const line of psOut.split('\n')) {
            if (def.detectIn.some(p => line.includes(p))) {
              const m = line.trim().match(/^(\d+)/);
              if (m) try { process.kill(parseInt(m[1]), 'SIGTERM'); } catch {}
            }
          }
        }
      } catch {}
      delete pids[def.id];
      myappWritePids(pids);
    }

    /**
     * Spawn detached app and only report success if the process is still alive
     * after a short grace period. Immediate exits (bad cwd, port in use, etc.)
     * were previously reported as "started" even though nothing was running.
     */
    function doStart(cb) {
      if (!fs.existsSync(def.dir)) {
        cb({ ok: false, error: `Working directory missing: ${def.dir}` });
        return;
      }
      const port = def.port ? myappReadPort(def.port) : 3000;
      const env = { ...process.env };
      if (def.port?.type === 'env') env[def.port.key] = String(port);
      if (def.port?.type === 'static') env.PORT = String(port);
      const exe = myappSpawnExe(def);
      const mainJs = def.args[0];
      if ((def.cmd === 'node' || myappIsNodeInterpreter(def.cmd)) && mainJs && /\.(js|cjs|mjs|ts|tsx)$/i.test(mainJs) && !fs.existsSync(mainJs)) {
        cb({ ok: false, error: `Entry script not found: ${mainJs}` });
        return;
      }
      let stderrBuf = '';
      let stdoutBuf = '';
      const child = spawn(exe, def.args, {
        cwd: def.dir,
        detached: true,
        stdio: ['ignore', 'pipe', 'pipe'],
        env,
        shell: false,
        windowsHide: true,
      });
      child.unref();
      if (child.stdout) {
        child.stdout.setEncoding('utf8');
        child.stdout.on('data', chunk => {
          stdoutBuf += chunk;
          if (stdoutBuf.length > 4000) stdoutBuf = stdoutBuf.slice(-4000);
        });
      }
      if (child.stderr) {
        child.stderr.setEncoding('utf8');
        child.stderr.on('data', chunk => {
          stderrBuf += chunk;
          if (stderrBuf.length > 4000) stderrBuf = stderrBuf.slice(-4000);
        });
      }
      let exitedEarly = false;
      let settled = false;
      const finish = result => {
        if (settled) return;
        settled = true;
        cb(result);
      };
      child.on('error', err => finish({ ok: false, error: err.message }));
      child.on('exit', () => {
        exitedEarly = true;
      });
      setTimeout(() => {
        if (settled) return;
        if (!child.pid) {
          finish({ ok: false, error: 'Failed to launch process' });
          return;
        }
        if (exitedEarly || !myappIsAlive(child.pid)) {
          const merged = (stderrBuf + '\n' + stdoutBuf).trim();
          const hint = merged ? merged.split('\n').filter(Boolean).pop() : '';
          finish({
            ok: false,
            error: hint || 'Process quit immediately — check port is free, cwd, and that the app command runs on this host',
          });
          return;
        }
        pids[def.id] = child.pid;
        myappWritePids(pids);
        finish({ ok: true, message: `${def.name} started`, pid: child.pid });
      }, 1400);
    }

    if (action === 'stop') {
      doStop();
      return res.json({ ok: true, message: `${def.name} stopped` });
    }

    const send = result => {
      if (result.ok) res.json(result);
      else res.status(400).json(result);
    };

    if (action === 'start') {
      doStart(send);
      return;
    }

    if (action === 'restart') {
      doStop();
      setTimeout(() => doStart(send), 1100);
      return;
    }
  });

  app.post('/api/myapps/port', auth, (req, res) => {
    const { id, port } = req.body || {};
    const def = myappFindDef(id);
    if (!def) return res.status(404).json({ error: 'Unknown app' });
    const newPort = parseInt(port, 10);
    if (!newPort || newPort < 1 || newPort > 65535) return res.status(400).json({ error: 'Invalid port number' });

    if (def.id.startsWith('user:') && def.port && def.port.type === 'static') {
      const store = myappReadUserStore();
      const ent = store.entries.find(e => e.id === id);
      if (ent) {
        ent.port = { type: 'static', default: newPort };
        myappWriteUserStore(store);
        return res.json({ ok: true, message: `Port set to ${newPort} for this shortcut (does not edit the app's config files).` });
      }
    }

    try {
      myappWritePort(def.port, newPort);
      res.json({ ok: true, message: `Port updated to ${newPort} in config. Restart the app to apply.` });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/myapps/user/add-from-apps', auth, (req, res) => {
    const body = req.body || {};
    const discovered = body.discovery || body.app;
    if (!discovered || !discovered.id) return res.status(400).json({ error: 'Missing app payload' });
    const store = myappReadUserStore();
    if (store.entries.some(e => e.discoveryId === discovered.id)) {
      return res.status(409).json({ error: 'Already in My Apps' });
    }
    const built = buildUserEntryFromDiscovery(discovered);
    if (built.error) return res.status(400).json({ error: built.error });
    store.entries.push(built.entry);
    myappWriteUserStore(store);
    res.json({ ok: true, id: built.entry.id, message: `Added "${built.entry.name}" to My Apps` });
  });

  app.post('/api/myapps/user/add-manual', auth, (req, res) => {
    const { name, dir, cmd, args, port } = req.body || {};
    if (!name || !dir || !cmd) return res.status(400).json({ error: 'name, dir, and cmd are required' });
    if (!fs.existsSync(dir)) return res.status(400).json({ error: 'Working directory does not exist' });
    const argArr = Array.isArray(args)
      ? args.map(String)
      : String(args || '').trim().split(/\s+/).filter(Boolean);
    const detectIn = [];
    for (const a of argArr) {
      const abs = path.isAbsolute(a) ? a : path.join(dir, a);
      try {
        if (fs.existsSync(abs) && fs.statSync(abs).isFile()) detectIn.push(abs);
      } catch (_) {}
    }
    if (detectIn.length === 0) {
      for (const a of argArr) {
        if (/\.(js|cjs|mjs|ts|py)$/i.test(a)) {
          const abs = path.isAbsolute(a) ? a : path.join(dir, a);
          detectIn.push(abs);
        }
      }
    }
    const entry = {
      id: `user:${crypto.randomBytes(6).toString('hex')}`,
      discoveryId: null,
      kind: 'spawn',
      name: String(name).slice(0, 80),
      icon: '⚙️',
      description: 'Custom shortcut',
      dir,
      cmd: String(cmd),
      args: argArr,
      detectIn: detectIn.length ? [...new Set(detectIn)] : argArr.map(a => (path.isAbsolute(a) ? a : path.join(dir, a))),
      port: { type: 'static', default: parseInt(port, 10) || 3000 },
    };
    const st = myappReadUserStore();
    st.entries.push(entry);
    myappWriteUserStore(st);
    res.json({ ok: true, id: entry.id, message: `Added "${entry.name}"` });
  });

  app.post('/api/myapps/user/remove', auth, (req, res) => {
    const { id } = req.body || {};
    if (!id) return res.status(400).json({ error: 'Missing id' });
    const store = myappReadUserStore();
    if (id.startsWith('user:')) {
      const before = store.entries.length;
      store.entries = store.entries.filter(e => e.id !== id);
      if (store.entries.length === before) return res.status(404).json({ error: 'Not found' });
      myappWriteUserStore(store);
      return res.json({ ok: true, message: 'Removed from My Apps' });
    }
    if (id.startsWith('myapp:')) {
      if (!store.hiddenBuiltinIds.includes(id)) store.hiddenBuiltinIds.push(id);
      myappWriteUserStore(store);
      return res.json({ ok: true, message: 'Preset hidden from My Apps' });
    }
    res.status(400).json({ error: 'Invalid id' });
  });

  app.post('/api/myapps/user/restore-builtin', auth, (req, res) => {
    const { id } = req.body || {};
    if (!id || !id.startsWith('myapp:')) return res.status(400).json({ error: 'Invalid id' });
    const store = myappReadUserStore();
    store.hiddenBuiltinIds = (store.hiddenBuiltinIds || []).filter(x => x !== id);
    myappWriteUserStore(store);
    res.json({ ok: true });
  });

  app.get('/api/myapps/user/hidden-builtins', auth, (req, res) => {
    const valid = new Set(MY_APPS.map(b => b.id));
    const all = myappReadUserStore().hiddenBuiltinIds || [];
    res.json({ ids: all.filter(x => valid.has(x)) });
  });

  return app;
}

// ─── Helper ───────────────────────────────────────────────────────────────────

function isBinary(buf) {
  for (let i = 0; i < buf.length; i++) {
    if (buf[i] === 0) return true;
  }
  return false;
}

// ─── Start server ─────────────────────────────────────────────────────────────

function startServer() {
  const cfg = loadConfig();
  const port = cfg.web.port;
  const app = buildApp(cfg);

  const server = app.listen(port, '0.0.0.0', () => {
    const authNote = cfg.web.password
      ? `  Password:  set in ${CONFIG_PATH}\n`
      : `  Auth:      none (set web.password in ${CONFIG_PATH} to enable)\n`;
    const rootNote = `  Root dir:  ${cfg.web.rootDir}\n`;

    process.stdout.write(
      '\n' +
      '  ██████╗ ██████╗ ██╗███████╗████████╗\n' +
      '  ██╔══██╗██╔══██╗██║██╔════╝╚══██╔══╝\n' +
      '  ██║  ██║██████╔╝██║█████╗     ██║\n' +
      '  ██║  ██║██╔══██╗██║██╔══╝     ██║\n' +
      '  ██████╔╝██║  ██║██║██║        ██║\n' +
      '  ╚═════╝ ╚═╝  ╚═╝╚═╝╚═╝        ╚═╝  web\n' +
      '\n' +
      `  Listening: http://localhost:${port}\n` +
      authNote +
      rootNote +
      '\n' +
      '  Updates:  drift-update  (configure your own git/npm/URL in package.json or env)\n' +
      '\n  Press Ctrl+C to stop\n\n'
    );
  });

  // ── WebSocket PTY terminal ─────────────────────────────────────────────────
  let pty, WebSocketServer;
  try {
    pty = require('@homebridge/node-pty-prebuilt-multiarch');
    ({ WebSocketServer } = require('ws'));
  } catch (e) {
    console.error('  [terminal] PTY or WS module not found — terminal disabled:', e.message);
  }

  if (pty && WebSocketServer) {
    const wss = new WebSocketServer({ noServer: true });

    server.on('upgrade', (req, socket, head) => {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname !== '/ws/terminal') { socket.destroy(); return; }

      const token = url.searchParams.get('token') || '';
      if (cfg.web.password && !validToken(token)) {
        socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
        socket.destroy();
        return;
      }

      wss.handleUpgrade(req, socket, head, ws => {
        const cols = Math.max(10, parseInt(url.searchParams.get('cols') || '220'));
        const rows = Math.max(5,  parseInt(url.searchParams.get('rows') || '50'));
        const cwd  = terminalCwds.get(token) || cfg.web.rootDir;
        const shell = process.env.SHELL || '/bin/bash';

        let proc;
        try {
          proc = pty.spawn(shell, [], {
            name: 'xterm-256color',
            cols, rows, cwd,
            env: { ...process.env, TERM: 'xterm-256color', COLORTERM: 'truecolor' },
          });
        } catch (e) {
          ws.send(JSON.stringify({ type: 'output', data: `\r\nFailed to start shell: ${e.message}\r\n` }));
          ws.close();
          return;
        }

        proc.onData(data => {
          if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ type: 'output', data }));
        });

        proc.onExit(() => {
          if (ws.readyState === ws.OPEN) {
            ws.send(JSON.stringify({ type: 'exit' }));
            ws.close();
          }
        });

        ws.on('message', raw => {
          try {
            const msg = JSON.parse(raw);
            if (msg.type === 'input')  proc.write(msg.data);
            if (msg.type === 'resize') proc.resize(
              Math.max(10, msg.cols),
              Math.max(5,  msg.rows)
            );
          } catch (_) {}
        });

        ws.on('close', () => { try { proc.kill(); } catch (_) {} });
      });
    });
  }

  server.on('error', err => {
    if (err.code === 'EADDRINUSE') {
      console.error(`\n  Port ${port} is already in use. Change web.port in ${CONFIG_PATH}\n`);
    } else {
      console.error('\n  Server error:', err.message);
    }
    process.exit(1);
  });
}

module.exports = { startServer };

// Allow running directly: node src/server.js
if (require.main === module) {
  startServer();
}
