'use strict';

const fs = require('fs');
const path = require('path');
const { formatSize } = require('./fileops');

const TEXT_EXTENSIONS = new Set([
  'txt', 'md', 'markdown', 'rst', 'log',
  'js', 'mjs', 'cjs', 'ts', 'jsx', 'tsx',
  'css', 'scss', 'sass', 'less',
  'html', 'htm', 'xml', 'svg',
  'yaml', 'yml', 'toml', 'ini', 'cfg', 'conf', 'env',
  'sh', 'bash', 'zsh', 'fish', 'ps1',
  'py', 'rb', 'go', 'rs', 'java', 'c', 'cpp', 'h',
  'hpp', 'cs', 'php', 'swift', 'kt', 'lua', 'r',
  'sql', 'graphql', 'gql',
  'dockerfile', 'makefile', 'cmake',
  'gitignore', 'gitattributes', 'editorconfig',
  'csv', 'tsv',
]);

const MAX_PREVIEW_BYTES = 40 * 1024; // 40 KB

/**
 * Generate preview content for a file list entry.
 * Returns a blessed-tagged string.
 */
function getFilePreview(entry) {
  if (!entry) return '';

  if (entry.isDirectory) {
    return getDirectoryPreview(entry);
  }

  const ext = path.extname(entry.name).replace('.', '').toLowerCase();

  if (ext === 'json') {
    return getJsonPreview(entry);
  }

  const isText = TEXT_EXTENSIONS.has(ext) || !ext;
  if (isText) {
    return getTextPreview(entry);
  }

  return getFileInfo(entry);
}

// ─── Directory preview ────────────────────────────────────────────────────────

function getDirectoryPreview(entry) {
  try {
    const raw = fs.readdirSync(entry.path, { withFileTypes: true });
    const dirs = raw.filter(d => d.isDirectory()).map(d => d.name).sort();
    const files = raw.filter(d => !d.isDirectory()).map(d => d.name).sort();

    const lines = [
      `{cyan-fg}{bold}  Directory{/bold}{/cyan-fg}`,
      ``,
      `{yellow-fg}  ${dirs.length} folder(s)   ${files.length} file(s){/yellow-fg}`,
      ``,
    ];

    const shown = [...dirs.slice(0, 15), ...files.slice(0, 15)];
    const total = dirs.length + files.length;

    for (const name of dirs.slice(0, 15)) {
      lines.push(`  {cyan-fg}▸ ${escTag(name)}/{/cyan-fg}`);
    }
    for (const name of files.slice(0, 15)) {
      lines.push(`    ${escTag(name)}`);
    }
    if (total > shown.length) {
      lines.push(``, `  {gray-fg}… and ${total - shown.length} more{/gray-fg}`);
    }

    return lines.join('\n');
  } catch (e) {
    if (e.code === 'EACCES') return `{red-fg}  Permission denied{/red-fg}`;
    return `{red-fg}  Cannot read: ${escTag(e.message)}{/red-fg}`;
  }
}

// ─── JSON preview ─────────────────────────────────────────────────────────────

function getJsonPreview(entry) {
  try {
    const raw = readFileChunk(entry.path);
    if (raw === null) return getFileInfo(entry);

    const parsed = JSON.parse(raw);
    const pretty = JSON.stringify(parsed, null, 2);
    const lines = pretty.split('\n').slice(0, 300).join('\n');
    return `{green-fg}// JSON{/green-fg}\n\n${escTag(lines)}`;
  } catch (_) {
    // Not valid JSON — fall back to plain text
    return getTextPreview(entry);
  }
}

// ─── Text preview ─────────────────────────────────────────────────────────────

function getTextPreview(entry) {
  try {
    const chunk = readFileChunk(entry.path);
    if (chunk === null) return getFileInfo(entry);
    if (isBinary(chunk)) return getFileInfo(entry);

    const text = chunk.toString('utf8');
    const lines = text.split('\n').slice(0, 500).join('\n');
    return escTag(lines);
  } catch (e) {
    if (e.code === 'EACCES') return `{red-fg}  Permission denied{/red-fg}`;
    return `{red-fg}  Cannot read: ${escTag(e.message)}{/red-fg}`;
  }
}

// ─── Generic file info ────────────────────────────────────────────────────────

function getFileInfo(entry) {
  try {
    const stat = entry.stat || fs.statSync(entry.path);
    const ext = path.extname(entry.name || '').replace('.', '').toUpperCase() || 'File';
    return [
      ``,
      `{yellow-fg}{bold}  File Info{/bold}{/yellow-fg}`,
      ``,
      `  Name     ${escTag(path.basename(entry.path))}`,
      `  Type     ${ext}`,
      `  Size     ${formatSize(stat.size)}`,
      `  Modified ${stat.mtime ? stat.mtime.toLocaleString() : '—'}`,
      ``,
      `  {gray-fg}(Binary or unsupported format){/gray-fg}`,
    ].join('\n');
  } catch (_) {
    return `{red-fg}  Cannot read file info{/red-fg}`;
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Read up to MAX_PREVIEW_BYTES from a file. Returns a Buffer or null. */
function readFileChunk(filePath) {
  let fd;
  try {
    fd = fs.openSync(filePath, 'r');
    const buf = Buffer.alloc(MAX_PREVIEW_BYTES);
    const bytesRead = fs.readSync(fd, buf, 0, MAX_PREVIEW_BYTES, 0);
    return buf.slice(0, bytesRead);
  } catch (_) {
    return null;
  } finally {
    if (fd != null) try { fs.closeSync(fd); } catch (_) {}
  }
}

/** Heuristic: if the first 512 bytes contain a null byte, treat as binary. */
function isBinary(buf) {
  const check = Math.min(buf.length, 512);
  for (let i = 0; i < check; i++) {
    if (buf[i] === 0) return true;
  }
  return false;
}

/** Escape blessed tag syntax so file content is displayed literally. */
function escTag(str) {
  return String(str).replace(/\{/g, '\\{');
}

module.exports = { getFilePreview };
