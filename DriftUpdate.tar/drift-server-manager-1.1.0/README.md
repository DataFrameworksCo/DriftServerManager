# Drift Server Manager

A **terminal file explorer** and **web dashboard** for the computer where it runs. **Applications** and **My Apps** only discover processes, services, and containers **on that host**—there are no bundled presets or vendor defaults.

---

## Install (your copy)

**Requirements:** Node.js **v14+** and npm.

Unpack or clone **your** distribution, then from the folder that contains `package.json`:

```bash
chmod +x install.sh   # Unix/macOS
./install.sh
```

**Windows:** double-click `install.cmd` or run it from a terminal in that folder.

Or:

```bash
npm run install:git
```

That runs `npm install` and sets up local CLI shims. Nothing phones home unless **you** configure an update source (see below).

### Run

| | Command |
|--|---------|
| **Web UI** | `npm run web` → `http://localhost:7473` |
| **Terminal UI** | `npm start` |
| **Config** | `npm run drift-config` |

Optional global commands on all terminals (install still lives on disk where you ran this):

```bash
npm install -g .
```

---

## Updates (`drift-update`)

Update behavior is **whatever you configure on that machine**—in order:

1. Environment **`DRIFT_UPDATE_URL`** (HTTPS `.tar.gz`), or  
2. **`driftUpdate.tarballUrl`** in `package.json`, or  
3. **GitHub source tarball** — only if you add a **`repository`** field to **your** `package.json`, or  
4. **`git pull`** — if this directory is **your** git clone, or  
5. **npm** — `npm view <this package name>@latest` if you publish that name.

**This repo ships with no `repository` field** so a stock install does not pull from any third-party GitHub org. To use GitHub tarballs, add to `package.json` after install:

```json
"repository": {
  "type": "git",
  "url": "git+https://github.com/YOUR_ORG/YOUR_REPO.git"
},
"driftUpdate": {
  "branch": "main"
}
```

To attach **git** to an existing folder (optional):

```bash
npm run init-git-remote
```

(requires `repository` in `package.json` as above.)

---

## Configuration

`~/.drift-config.json` — use **`npm run drift-config`** or **Web → Settings**. Set **`web.password`** and **`web.rootDir`** before exposing the service to a network.

---

## Systemd example

```ini
[Service]
WorkingDirectory=/path/to/this/install
ExecStart=/usr/bin/node bin/drift.js --web
```

---

## License

MIT (see `package.json`).
