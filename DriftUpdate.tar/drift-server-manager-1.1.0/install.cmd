@echo off
setlocal
cd /d "%~dp0"
node "%~dp0scripts\install-from-git.js" %*
exit /b %ERRORLEVEL%
