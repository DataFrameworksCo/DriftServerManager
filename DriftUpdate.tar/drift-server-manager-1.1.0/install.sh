#!/usr/bin/env sh
# GitHub / clean install — run from the repo root after clone.
set -e
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P) || exit 1
cd "$DIR" || exit 1
exec node "$DIR/scripts/install-from-git.js" "$@"
