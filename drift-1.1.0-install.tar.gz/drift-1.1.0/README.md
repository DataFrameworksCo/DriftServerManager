# Drift

Drift is a fast, keyboard-driven terminal file explorer with an optional **web UI** for browsing and managing files on a server.

## Requirements

- **Node.js** 14 or newer ([nodejs.org](https://nodejs.org/) or your OS package manager)
- **Linux or macOS** recommended for the full feature set (embedded terminal uses a PTY)
- On **Windows**, the CLI may work; the web terminal depends on native bindings and may be limited

## Installation

### 1. Unpack

```bash
tar -xzf drift-1.1.0-install.tar.gz
cd drift-1.1.0
```

### 2. Install dependencies

From the application directory (where `package.json` is):

```bash
npm install
```

For a reproducible install from the lockfile:

```bash
npm ci
```

### 3. Configure (optional but recommended for servers)

Configuration is stored in **`~/.drift-config.json`** (created on first run or when you save settings).

**Interactive editor (terminal UI):**

```bash
./node_modules/.bin/drift-config
# or, if you linked the package globally: drift-config
```

**Important web settings** (edit `~/.drift-config.json` or use the Web section in `drift-config`):

| Key | Purpose |
|-----|--------|
| `web.port` | HTTP port (default **7473**) |
| `web.password` | If set, the UI requires login; if empty, **anyone who can reach the port can use the UI** |
| `web.rootDir` | Files outside this directory cannot be opened via the web UI |
| `web.readOnly` | When `true`, blocks destructive/write API actions |
| `web.allowUpload` | Allow uploads through the web UI |

Always set a **strong password** and restrict **`rootDir`** before exposing the service to a network.

### 4. Run

**Web UI** (listens on **0.0.0.0** — all interfaces):

```bash
npm run web
```

Or:

```bash
node bin/drift.js --web
```

Then open `http://YOUR_SERVER_IP:7473` (or the port you configured).

**Terminal UI** (no web server):

```bash
npm start
```

## Running as a background service (optional)

Example **systemd** user unit — adjust paths and user:

```ini
[Unit]
Description=Drift web file explorer
After=network.target

[Service]
Type=simple
WorkingDirectory=/path/to/drift-1.1.0
ExecStart=/usr/bin/node bin/drift.js --web
Restart=on-failure

[Install]
WantedBy=default.target
```

Put the file in `~/.config/systemd/user/drift.service`, then:

```bash
systemctl --user daemon-reload
systemctl --user enable --now drift.service
```

Use a **firewall** or **reverse proxy** (TLS + access control) if the service is reachable from untrusted networks.

## Troubleshooting

- **Port already in use:** Change `web.port` in `~/.drift-config.json` or stop the other service.
- **`npm install` fails on native modules:** Ensure build tools match your OS; this project uses prebuilt PTY binaries for many platforms. Try upgrading Node and retrying.
- **Cannot connect remotely:** Confirm the process is running, the port is open in the firewall, and you are using the correct IP and port.

## License

MIT (see `package.json`).
