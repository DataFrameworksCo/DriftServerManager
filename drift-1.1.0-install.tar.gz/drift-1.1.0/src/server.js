'use strict';

const express = require('express');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { exec } = require('child_process');

const { loadConfig, saveConfig, resetCache, CONFIG_PATH } = require('./config');
const { listDirectory, deleteEntry, renameEntry, copyEntry, moveEntry, createFile, createDirectory, formatSize } = require('./fileops');
const { getFilePreview } = require('./preview');
const { flatList, runTool } = require('./tools');

// ─── Session store (in-memory tokens) ────────────────────────────────────────

const sessions = new Set();
const sudoCredentials = new Map(); // token → sudo password (session-scoped)
const terminalCwds = new Map();   // token → current working directory

function createToken() {
  const t = crypto.randomBytes(32).toString('hex');
  sessions.add(t);
  return t;
}
function validToken(t) { return t && sessions.has(t); }
function revokeToken(t) { sessions.delete(t); sudoCredentials.delete(t); terminalCwds.delete(t); }

// ─── Sudo helper ──────────────────────────────────────────────────────────────

function sudoRun(cred, cmd, timeout = 20000) {
  return new Promise(resolve => {
    const { exec: _exec } = require('child_process');
    const full = `echo ${JSON.stringify(cred)} | sudo -S bash -c ${JSON.stringify(cmd)} 2>&1`;
    _exec(full, { timeout, maxBuffer: 2 * 1024 * 1024 }, (err, stdout) => {
      const output = (stdout || '').trim();
      resolve({ ok: !err, output, code: err ? (err.code || 1) : 0 });
    });
  });
}

// ─── Path safety ──────────────────────────────────────────────────────────────

function safePath(cfg, requestedPath) {
  const root = cfg.web.rootDir;
  // default to rootDir if no path given
  const resolved = path.resolve(requestedPath || root);
  if (!resolved.startsWith(root)) {
    const err = new Error('Access denied: path is outside the root directory');
    err.code = 'EACCES';
    throw err;
  }
  return resolved;
}

// ─── Auth middleware ──────────────────────────────────────────────────────────

function requireAuth(cfg) {
  return (req, res, next) => {
    if (!cfg.web.password) return next();            // no password set = open
    const token = req.headers['x-drift-token'] || '';
    if (validToken(token)) return next();
    res.status(401).json({ error: 'Unauthorized' });
  };
}

// ─── Build express app ────────────────────────────────────────────────────────

function buildApp(cfg) {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  const auth = requireAuth(cfg);
  const webDir = path.join(__dirname, 'web');

  // ── Static web UI ─────────────────────────────────────────────────────────
  app.get('/', (req, res) => {
    res.sendFile(path.join(webDir, 'index.html'));
  });
  app.use('/static', express.static(webDir));

  // ── Auth ──────────────────────────────────────────────────────────────────
  app.post('/api/auth/login', (req, res) => {
    const { password } = req.body || {};
    if (!cfg.web.password || password === cfg.web.password) {
      const token = createToken();
      res.json({ token, rootDir: cfg.web.rootDir });
    } else {
      res.status(401).json({ error: 'Wrong password' });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    revokeToken(req.headers['x-drift-token'] || '');
    res.json({ ok: true });
  });

  app.get('/api/auth/check', (req, res) => {
    const needsAuth = Boolean(cfg.web.password);
    const authed = !needsAuth || validToken(req.headers['x-drift-token'] || '');
    res.json({ needsAuth, authed, rootDir: cfg.web.rootDir });
  });

  // ── Filesystem: list ──────────────────────────────────────────────────────
  app.get('/api/fs/list', auth, (req, res) => {
    try {
      const dir = safePath(cfg, req.query.path || cfg.web.rootDir);
      const { entries, error } = listDirectory(dir, false);
      if (error) return res.status(500).json({ error });

      const home = os.homedir();
      const displayPath = dir.startsWith(home) ? '~' + dir.slice(home.length) : dir;

      res.json({
        path: dir,
        displayPath,
        parent: dir !== cfg.web.rootDir ? path.dirname(dir) : null,
        entries: entries.map(e => ({
          name: e.name,
          path: e.path,
          isDirectory: e.isDirectory,
          isSymlink: e.isSymlink,
          size: e.size,
          sizeDisplay: formatSize(e.size),
          mtime: e.mtime,
          ext: path.extname(e.name).slice(1).toLowerCase(),
        })),
      });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: read file ─────────────────────────────────────────────────
  app.get('/api/fs/read', auth, (req, res) => {
    try {
      const filePath = safePath(cfg, req.query.path);
      const stat = fs.statSync(filePath);

      if (stat.isDirectory()) {
        return res.status(400).json({ error: 'Path is a directory' });
      }
      if (stat.size > 5 * 1024 * 1024) {
        return res.status(413).json({ error: 'File too large to preview (> 5 MB)' });
      }

      const content = fs.readFileSync(filePath);
      const isBin = isBinary(content.slice(0, 512));

      if (isBin) {
        return res.json({
          type: 'binary',
          name: path.basename(filePath),
          size: stat.size,
          sizeDisplay: formatSize(stat.size),
          mtime: stat.mtime,
        });
      }

      const text = content.toString('utf8');
      res.json({
        type: 'text',
        content: text,
        size: stat.size,
        mtime: stat.mtime,
      });
    } catch (e) {
      res.status(e.code === 'ENOENT' ? 404 : e.code === 'EACCES' ? 403 : 500)
        .json({ error: e.message });
    }
  });

  // ── Filesystem: download ─────────────────────────────────────────────────
  app.get('/api/fs/download', (req, res) => {
    const token = req.headers['x-drift-token'] || req.query.token || '';
    if (cfg.web.password && !validToken(token)) return res.status(401).end();
    try {
      const filePath = safePath(cfg, req.query.path);
      res.download(filePath);
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: serve image / binary preview ──────────────────────────────
  app.get('/api/fs/serve', (req, res) => {
    const token = req.headers['x-drift-token'] || req.query.token || '';
    if (cfg.web.password && !validToken(token)) return res.status(401).end();
    try {
      const filePath = safePath(cfg, req.query.path);
      const ext = path.extname(filePath).slice(1).toLowerCase();
      const mimes = {
        png:'image/png', jpg:'image/jpeg', jpeg:'image/jpeg',
        gif:'image/gif', svg:'image/svg+xml', webp:'image/webp',
        ico:'image/x-icon', bmp:'image/bmp', pdf:'application/pdf',
      };
      if (mimes[ext]) res.set('Content-Type', mimes[ext]);
      fs.createReadStream(filePath).pipe(res);
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).end();
    }
  });

  // ── Filesystem: upload (text or base64 binary) ────────────────────────────
  app.post('/api/fs/upload', auth, express.raw({ type: '*/*', limit: '50mb' }), (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const destPath = safePath(cfg, req.query.path);
      fs.writeFileSync(destPath, req.body);
      res.json({ ok: true });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: write file ────────────────────────────────────────────────
  app.post('/api/fs/write', auth, (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const { path: filePath, content } = req.body;
      const safe = safePath(cfg, filePath);
      fs.writeFileSync(safe, content, 'utf8');
      res.json({ ok: true });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: delete ────────────────────────────────────────────────────
  app.post('/api/fs/delete', auth, (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const safe = safePath(cfg, req.body.path);
      const result = deleteEntry(safe);
      if (!result.success) return res.status(500).json({ error: result.error });
      res.json({ ok: true });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: rename ────────────────────────────────────────────────────
  app.post('/api/fs/rename', auth, (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const from = safePath(cfg, req.body.from);
      const to = safePath(cfg, req.body.to);
      const result = renameEntry(from, to);
      if (!result.success) return res.status(500).json({ error: result.error });
      res.json({ ok: true });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: mkdir ─────────────────────────────────────────────────────
  app.post('/api/fs/mkdir', auth, (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const safe = safePath(cfg, req.body.path);
      const result = createDirectory(safe);
      if (!result.success) return res.status(500).json({ error: result.error });
      res.json({ ok: true });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Filesystem: new file ──────────────────────────────────────────────────
  app.post('/api/fs/touch', auth, (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const safe = safePath(cfg, req.body.path);
      const result = createFile(safe);
      if (!result.success) return res.status(500).json({ error: result.error });
      res.json({ ok: true });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Export / convert ──────────────────────────────────────────────────────
  app.post('/api/fs/export', auth, (req, res) => {
    if (cfg.web.readOnly) return res.status(403).json({ error: 'Server is read-only' });
    try {
      const src = safePath(cfg, req.body.src);
      const dest = safePath(cfg, req.body.dest);
      const destExt = path.extname(dest).slice(1).toLowerCase();

      if (destExt === 'pdf') {
        exec('which pandoc', pandocErr => {
          if (pandocErr) {
            return res.status(501).json({ error: 'PDF export requires pandoc (apt install pandoc)' });
          }
          exec(`pandoc "${src}" -o "${dest}"`, err => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ ok: true, dest });
          });
        });
      } else {
        const result = copyEntry(src, dest);
        if (!result.success) return res.status(500).json({ error: result.error });
        res.json({ ok: true, dest });
      }
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Tools: list ───────────────────────────────────────────────────────────
  app.get('/api/tools/list', auth, (req, res) => {
    res.json(flatList());
  });

  // ── Tools: run ────────────────────────────────────────────────────────────
  app.post('/api/tools/run', auth, async (req, res) => {
    const { id, arg, context, credential } = req.body || {};
    try {
      const ctx = Object.assign({}, context || {}, { credential: credential || null });
      const raw = await runTool(id, arg || null, ctx);
      const output = raw.replace(/\{\/?\w[\w-]*\}/g, '');
      res.json({ output });
    } catch (e) {
      res.json({ output: 'Error: ' + e.message });
    }
  });

  // ── Terminal: stateful command runner with persistent cwd ─────────────────
  app.post('/api/terminal/run', auth, async (req, res) => {
    const token = req.headers['x-drift-token'] || '';
    const { cmd } = req.body || {};
    if (!cmd || typeof cmd !== 'string') return res.status(400).json({ error: 'Missing cmd' });

    // Initialize session cwd to rootDir on first use
    if (!terminalCwds.has(token)) terminalCwds.set(token, cfg.web.rootDir);
    const cwd = terminalCwds.get(token);

    // Handle `cd` natively — exec spawns a subshell so cd has no effect otherwise
    const cdMatch = cmd.trim().match(/^cd(?:\s+(.+))?$/);
    if (cdMatch) {
      const target = (cdMatch[1] || '').trim();
      let newDir;
      if (!target || target === '~') {
        newDir = os.homedir();
      } else if (target.startsWith('~/')) {
        newDir = path.join(os.homedir(), target.slice(2));
      } else {
        newDir = path.resolve(cwd, target);
      }
      try {
        const stat = fs.statSync(newDir);
        if (!stat.isDirectory()) return res.json({ output: `cd: not a directory: ${target || '~'}`, cwd });
        terminalCwds.set(token, newDir);
        return res.json({ output: '', cwd: newDir });
      } catch (_) {
        return res.json({ output: `cd: ${target || '~'}: No such file or directory`, cwd });
      }
    }

    // Execute the command in the session's cwd
    const output = await new Promise(resolve => {
      exec(cmd, { cwd, timeout: 30000, maxBuffer: 512 * 1024, shell: '/bin/bash' }, (err, stdout, stderr) => {
        const out = (stdout || '') + (stderr || '');
        resolve(out || (err ? `Exit code ${err.code || 1}` : ''));
      });
    });

    // Strip ANSI escape sequences (terminal div can't render them)
    const clean = output
      .replace(/\x1B\[[0-9;]*[A-Za-z]/g, '')
      .replace(/\x1B\][^\x07]*\x07/g, '')
      .replace(/\x1B[()][AB012]/g, '');

    res.json({ output: clean, cwd });
  });

  // ── Keys: list names (values never sent to client) ────────────────────────
  app.get('/api/keys/list', auth, (req, res) => {
    const keys = cfg.keys || {};
    res.json(Object.keys(keys));
  });

  // ── Keys: get value for a specific key ────────────────────────────────────
  app.get('/api/keys/get', auth, (req, res) => {
    const name = req.query.name;
    if (!name) return res.status(400).json({ error: 'Missing name' });
    const value = (cfg.keys || {})[name];
    if (value === undefined) return res.status(404).json({ error: 'Key not found' });
    res.json({ value });
  });

  // ── Keys: set / update ────────────────────────────────────────────────────
  app.post('/api/keys/set', auth, (req, res) => {
    const { name, value } = req.body || {};
    if (!name) return res.status(400).json({ error: 'Missing name' });
    const { saveConfig, loadConfig: lc } = require('./config');
    const current = lc();
    const keys = Object.assign({}, current.keys || {}, { [name]: value || '' });
    const result = saveConfig({ keys });
    if (result.success) {
      // Update live cfg so new runs can use it immediately
      if (!cfg.keys) cfg.keys = {};
      cfg.keys[name] = value || '';
      res.json({ ok: true });
    } else {
      res.status(500).json({ error: result.error });
    }
  });

  // ── Keys: delete ──────────────────────────────────────────────────────────
  app.post('/api/keys/delete', auth, (req, res) => {
    const { name } = req.body || {};
    if (!name) return res.status(400).json({ error: 'Missing name' });
    const { saveConfig, loadConfig: lc } = require('./config');
    const current = lc();
    const keys = Object.assign({}, current.keys || {});
    delete keys[name];
    const result = saveConfig({ keys });
    if (result.success) {
      if (cfg.keys) delete cfg.keys[name];
      res.json({ ok: true });
    } else {
      res.status(500).json({ error: result.error });
    }
  });

  // ── Config: get (passwords masked) ─────────────────────────────────────────
  app.get('/api/config', auth, (req, res) => {
    const c = JSON.parse(JSON.stringify(cfg));
    if (c.web && c.web.password) c.web.password = '__SET__';
    if (c.keys) {
      for (const k of Object.keys(c.keys)) c.keys[k] = c.keys[k] ? '__SET__' : '';
    }
    res.json(c);
  });

  // ── Config: save ────────────────────────────────────────────────────────────
  app.post('/api/config', auth, (req, res) => {
    const updates = req.body || {};
    // Don't overwrite password/keys with masked placeholders
    if (updates.web && updates.web.password === '__SET__') delete updates.web.password;
    if (updates.keys) {
      for (const k of Object.keys(updates.keys)) {
        if (updates.keys[k] === '__SET__') delete updates.keys[k];
      }
    }
    const { saveConfig } = require('./config');
    const result = saveConfig(updates);
    if (result.success) {
      // Merge into live cfg
      Object.assign(cfg, require('./config').loadConfig());
      res.json({ ok: true });
    } else {
      res.status(500).json({ error: result.error });
    }
  });

  // ── Search: find in files ───────────────────────────────────────────────────
  app.post('/api/fs/search', auth, (req, res) => {
    const { query, path: searchPath, caseSensitive, wholeWord } = req.body || {};
    if (!query) return res.json({ results: [] });
    try {
      const dir = safePath(cfg, searchPath || cfg.web.rootDir);
      let flags = '-r -n --include="*.{js,ts,jsx,tsx,json,md,txt,py,go,rs,sh,css,scss,html,yaml,yml,env,conf,cfg,ini,sql}" -l';
      if (!caseSensitive) flags += ' -i';
      const wordFlag = wholeWord ? ' -w' : '';
      const { execSync } = require('child_process');
      // First get matching files
      let fileList;
      try {
        fileList = execSync(`grep ${flags}${wordFlag} ${JSON.stringify(query)} ${JSON.stringify(dir)} 2>/dev/null`, { maxBuffer: 1024*1024, timeout: 10000 }).toString().trim().split('\n').filter(Boolean).slice(0, 50);
      } catch (e) { fileList = []; }

      const results = [];
      for (const filePath of fileList) {
        if (!filePath) continue;
        try {
          safePath(cfg, filePath); // security check
          let lineFlags = caseSensitive ? '-n' : '-ni';
          if (wholeWord) lineFlags += ' -w';
          const lines = execSync(`grep ${lineFlags} ${JSON.stringify(query)} ${JSON.stringify(filePath)} 2>/dev/null`, { maxBuffer: 512*1024, timeout: 5000 }).toString().trim().split('\n').filter(Boolean).slice(0, 20);
          const matches = lines.map(l => {
            const m = l.match(/^(\d+):(.*)$/);
            return m ? { line: parseInt(m[1]), text: m[2].trim().slice(0, 200) } : null;
          }).filter(Boolean);
          if (matches.length) results.push({ file: filePath, name: require('path').basename(filePath), matches });
        } catch (_) {}
      }
      res.json({ results, query });
    } catch (e) {
      res.status(e.code === 'EACCES' ? 403 : 500).json({ error: e.message });
    }
  });

  // ── Git: status ─────────────────────────────────────────────────────────────
  app.get('/api/git/status', auth, (req, res) => {
    try {
      const dir = safePath(cfg, req.query.path || cfg.web.rootDir);
      const { execSync } = require('child_process');
      const branch = execSync(`git -C ${JSON.stringify(dir)} rev-parse --abbrev-ref HEAD 2>/dev/null`, { timeout: 5000 }).toString().trim();
      const status = execSync(`git -C ${JSON.stringify(dir)} status --porcelain 2>/dev/null`, { timeout: 5000 }).toString().trim();
      const files = status.split('\n').filter(Boolean).map(l => ({ code: l.slice(0,2).trim(), file: l.slice(3).trim() }));
      const ahead = (() => { try { return execSync(`git -C ${JSON.stringify(dir)} rev-list @{u}..HEAD --count 2>/dev/null`, { timeout: 3000 }).toString().trim(); } catch(_) { return '?'; } })();
      const behind = (() => { try { return execSync(`git -C ${JSON.stringify(dir)} rev-list HEAD..@{u} --count 2>/dev/null`, { timeout: 3000 }).toString().trim(); } catch(_) { return '?'; } })();
      res.json({ branch, files, ahead, behind });
    } catch (e) {
      res.json({ error: 'Not a git repository', branch: null, files: [] });
    }
  });

  // ── Git: log ─────────────────────────────────────────────────────────────────
  app.get('/api/git/log', auth, (req, res) => {
    try {
      const dir = safePath(cfg, req.query.path || cfg.web.rootDir);
      const { execSync } = require('child_process');
      const raw = execSync(`git -C ${JSON.stringify(dir)} log --oneline -30 2>/dev/null`, { timeout: 5000 }).toString().trim();
      const commits = raw.split('\n').filter(Boolean).map(l => {
        const m = l.match(/^([a-f0-9]+)\s(.+)$/);
        return m ? { hash: m[1], message: m[2] } : null;
      }).filter(Boolean);
      res.json({ commits });
    } catch (e) {
      res.json({ commits: [], error: e.message });
    }
  });

  // ── Git: diff for a file ─────────────────────────────────────────────────────
  app.get('/api/git/diff', auth, (req, res) => {
    try {
      const dir = safePath(cfg, req.query.path || cfg.web.rootDir);
      const file = req.query.file ? safePath(cfg, req.query.file) : null;
      const { execSync } = require('child_process');
      const cmd = file
        ? `git -C ${JSON.stringify(dir)} diff HEAD -- ${JSON.stringify(file)} 2>/dev/null`
        : `git -C ${JSON.stringify(dir)} diff HEAD 2>/dev/null`;
      const diff = execSync(cmd, { maxBuffer: 512*1024, timeout: 8000 }).toString();
      res.json({ diff });
    } catch (e) {
      res.json({ diff: '', error: e.message });
    }
  });

  // ── Sudo: authenticate / check / clear ────────────────────────────────────
  app.post('/api/auth/sudo', auth, async (req, res) => {
    const { credential } = req.body || {};
    if (!credential) return res.status(400).json({ error: 'Missing credential' });
    const token = req.headers['x-drift-token'] || '';
    const result = await sudoRun(credential, 'true', 5000);
    if (!result.ok) return res.status(401).json({ error: 'Incorrect sudo password' });
    sudoCredentials.set(token, credential);
    res.json({ ok: true });
  });

  app.post('/api/auth/sudo/clear', auth, (req, res) => {
    sudoCredentials.delete(req.headers['x-drift-token'] || '');
    res.json({ ok: true });
  });

  app.get('/api/auth/sudo/check', auth, (req, res) => {
    res.json({ hasSudo: sudoCredentials.has(req.headers['x-drift-token'] || '') });
  });

  // ── Users ─────────────────────────────────────────────────────────────────
  app.get('/api/users/list', auth, (req, res) => {
    try {
      const raw = fs.readFileSync('/etc/passwd', 'utf8');
      const users = raw.trim().split('\n').map(l => {
        const p = l.split(':');
        return { username: p[0], uid: parseInt(p[2]), gid: parseInt(p[3]), comment: p[4], home: p[5], shell: p[6] };
      }).filter(u => u.uid >= 1000 || u.username === 'root');

      let sudoers = ['root'];
      try {
        const { execSync: es } = require('child_process');
        const sg = es('getent group sudo 2>/dev/null || getent group wheel 2>/dev/null', { timeout: 3000 }).toString().trim();
        const members = sg.split(':')[3];
        if (members) sudoers = sudoers.concat(members.split(',').filter(Boolean));
      } catch (_) {}

      res.json({ users: users.map(u => ({
        ...u,
        hasSudo: sudoers.includes(u.username),
        active: u.shell && !u.shell.includes('nologin') && !u.shell.includes('false'),
      }))});
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.post('/api/users/create', auth, async (req, res) => {
    const token = req.headers['x-drift-token'] || '';
    const cred = sudoCredentials.get(token);
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { username, password, shell = '/bin/bash' } = req.body || {};
    if (!username || !/^[a-z_][a-z0-9_-]{0,30}$/.test(username))
      return res.status(400).json({ error: 'Invalid username' });
    const r = await sudoRun(cred, `useradd -m -s ${shell} ${username}`);
    if (!r.ok) return res.status(500).json({ error: r.output || 'useradd failed' });
    if (password) {
      const r2 = await sudoRun(cred, `echo ${JSON.stringify(username + ':' + password)} | chpasswd`);
      if (!r2.ok) return res.json({ ok: true, warning: 'User created but password not set: ' + r2.output });
    }
    res.json({ ok: true });
  });

  app.post('/api/users/delete', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { username, removeHome } = req.body || {};
    if (!username) return res.status(400).json({ error: 'Missing username' });
    const flag = removeHome ? '-r' : '';
    const r = await sudoRun(cred, `userdel ${flag} ${username}`);
    if (!r.ok) return res.status(500).json({ error: r.output || 'userdel failed' });
    res.json({ ok: true });
  });

  app.post('/api/users/passwd', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { username, password } = req.body || {};
    if (!username || !password) return res.status(400).json({ error: 'Missing fields' });
    const r = await sudoRun(cred, `echo ${JSON.stringify(username + ':' + password)} | chpasswd`);
    if (!r.ok) return res.status(500).json({ error: r.output || 'chpasswd failed' });
    res.json({ ok: true });
  });

  app.post('/api/users/sudo', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { username, grant } = req.body || {};
    if (!username) return res.status(400).json({ error: 'Missing username' });
    const sudoGroup = await sudoRun(cred, 'getent group sudo >/dev/null 2>&1 && echo sudo || echo wheel');
    const grpLines = sudoGroup.output.split('\n').map(l => l.trim());
    const grp = grpLines.find(l => l === 'sudo' || l === 'wheel') || 'sudo';
    const cmd = grant ? `usermod -aG ${grp} ${username}` : `gpasswd -d ${username} ${grp}`;
    const r = await sudoRun(cred, cmd);
    if (!r.ok) return res.status(500).json({ error: r.output || 'group change failed' });
    res.json({ ok: true });
  });

  app.get('/api/users/groups', auth, (req, res) => {
    try {
      const raw = fs.readFileSync('/etc/group', 'utf8');
      const groups = raw.trim().split('\n').map(l => {
        const p = l.split(':');
        return { name: p[0], gid: parseInt(p[2]), members: p[3] ? p[3].split(',').filter(Boolean) : [] };
      });
      res.json({ groups });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // ── Services ──────────────────────────────────────────────────────────────
  app.get('/api/services/list', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    try {
      const raw = es('systemctl list-units --type=service --all --no-pager --no-legend 2>/dev/null', { timeout: 10000, maxBuffer: 2*1024*1024 }).toString().trim();
      const services = raw.split('\n').filter(Boolean).map(l => {
        const m = l.trim().match(/^(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(.*)$/);
        if (!m) return null;
        return { unit: m[1].replace('.service',''), load: m[2], active: m[3], sub: m[4], description: m[5] };
      }).filter(Boolean).slice(0, 200);
      res.json({ services });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.post('/api/services/action', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { name, action } = req.body || {};
    const allowed = ['start', 'stop', 'restart', 'enable', 'disable', 'reload'];
    if (!name || !allowed.includes(action)) return res.status(400).json({ error: 'Invalid action' });
    const r = await sudoRun(cred, `systemctl ${action} ${name}`);
    res.json({ ok: r.ok, output: r.output });
  });

  app.get('/api/services/status', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    const { name } = req.query;
    if (!name) return res.status(400).json({ error: 'Missing name' });
    try {
      const out = es(`systemctl status ${name} --no-pager 2>&1`, { timeout: 5000, maxBuffer: 512*1024 }).toString();
      res.json({ output: out });
    } catch (e) { res.json({ output: (e.stdout || e.message || '').toString() }); }
  });

  // ── Packages ──────────────────────────────────────────────────────────────
  app.get('/api/packages/list', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    try {
      const raw = es('dpkg -l 2>/dev/null | grep "^ii"', { timeout: 15000, maxBuffer: 4*1024*1024 }).toString();
      const pkgs = raw.trim().split('\n').filter(Boolean).map(l => {
        const p = l.trim().split(/\s+/);
        return { name: p[1], version: p[2], arch: p[3], description: p.slice(4).join(' ') };
      });
      res.json({ packages: pkgs });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.post('/api/packages/search', auth, (req, res) => {
    const { query } = req.body || {};
    if (!query) return res.json({ results: [] });
    const { execSync: es } = require('child_process');
    try {
      const raw = es(`apt-cache search ${JSON.stringify(query)} 2>/dev/null | head -50`, { timeout: 10000, maxBuffer: 1024*1024 }).toString();
      const results = raw.trim().split('\n').filter(Boolean).map(l => {
        const i = l.indexOf(' - ');
        return i > -1 ? { name: l.slice(0, i), description: l.slice(i + 3) } : { name: l, description: '' };
      });
      res.json({ results });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.get('/api/packages/updates', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    try {
      const raw = es('apt list --upgradable 2>/dev/null | grep -v "Listing..." | head -100', { timeout: 15000, maxBuffer: 1024*1024 }).toString();
      const updates = raw.trim().split('\n').filter(Boolean).map(l => {
        const m = l.match(/^(\S+)\/\S+\s+(\S+)\s+\S+\s+\[upgradable from:\s+(\S+)\]/);
        return m ? { name: m[1], newVersion: m[2], oldVersion: m[3] } : { name: l, newVersion: '', oldVersion: '' };
      });
      res.json({ updates });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.post('/api/packages/action', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { name, action } = req.body || {};
    const allowed = ['install', 'remove', 'purge', 'update'];
    if (!allowed.includes(action)) return res.status(400).json({ error: 'Invalid action' });
    const cmd = action === 'update'
      ? 'DEBIAN_FRONTEND=noninteractive apt-get update -q'
      : `DEBIAN_FRONTEND=noninteractive apt-get ${action} -y ${name}`;
    const r = await sudoRun(cred, cmd, 120000);
    res.json({ ok: r.ok, output: r.output });
  });

  // ── Logs ──────────────────────────────────────────────────────────────────
  app.get('/api/logs/journal', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    const { unit, lines = 200, priority } = req.query;
    const unitFlag = unit ? `-u ${unit}` : '';
    const prioFlag = priority ? `-p ${priority}` : '';
    try {
      const raw = es(`journalctl ${unitFlag} ${prioFlag} -n ${parseInt(lines)} --no-pager --output=short-iso 2>/dev/null`, { timeout: 10000, maxBuffer: 2*1024*1024 }).toString();
      res.json({ output: raw });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.get('/api/logs/files', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    try {
      const raw = es('find /var/log -maxdepth 2 -type f -name "*.log" 2>/dev/null | head -60', { timeout: 5000 }).toString();
      res.json({ files: raw.trim().split('\n').filter(Boolean) });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.get('/api/logs/file', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    const { file, lines = 200 } = req.query;
    if (!file || !file.startsWith('/var/log/')) return res.status(400).json({ error: 'Invalid log path' });
    try {
      const raw = es(`tail -n ${parseInt(lines)} ${JSON.stringify(file)} 2>/dev/null`, { timeout: 5000, maxBuffer: 2*1024*1024 }).toString();
      res.json({ output: raw });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // ── Firewall ──────────────────────────────────────────────────────────────
  app.get('/api/firewall/status', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    try {
      const raw = es('ufw status verbose 2>/dev/null || echo "ufw not available"', { timeout: 5000 }).toString();
      const enabled = raw.includes('Status: active');
      res.json({ output: raw.trim(), enabled });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.post('/api/firewall/action', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { action, rule } = req.body || {};
    const allowed = ['enable', 'disable', 'allow', 'deny', 'delete', 'reload'];
    if (!allowed.includes(action)) return res.status(400).json({ error: 'Invalid action' });
    const cmd = rule ? `ufw ${action} ${rule}` : `ufw --force ${action}`;
    const r = await sudoRun(cred, cmd);
    res.json({ ok: r.ok, output: r.output });
  });

  app.get('/api/firewall/rules', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    try {
      const raw = es('ufw status numbered 2>/dev/null || echo "ufw not available"', { timeout: 5000 }).toString();
      const rules = [];
      raw.split('\n').forEach(l => {
        const m = l.match(/^\[\s*(\d+)\]\s+(.+?)\s{2,}(.+?)\s{2,}(.+)$/);
        if (m) rules.push({ num: m[1], to: m[2].trim(), action: m[3].trim(), from: m[4].trim() });
      });
      res.json({ rules, raw: raw.trim() });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // ── Cron ──────────────────────────────────────────────────────────────────
  app.get('/api/cron/list', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    const { user } = req.query;
    try {
      const cmd = user ? `crontab -u ${user} -l 2>/dev/null` : 'crontab -l 2>/dev/null';
      const raw = es(cmd, { timeout: 5000 }).toString();
      const lines = raw.trim().split('\n').filter(l => l && !l.startsWith('#'));
      res.json({ entries: lines, raw: raw.trim() });
    } catch (e) { res.json({ entries: [], raw: '' }); }
  });

  app.post('/api/cron/save', auth, (req, res) => {
    const { content, user } = req.body || {};
    if (content === undefined) return res.status(400).json({ error: 'Missing content' });
    const { execSync: es } = require('child_process');
    const tmpFile = require('os').tmpdir() + '/drift-cron-' + Date.now() + '.txt';
    try {
      fs.writeFileSync(tmpFile, content, 'utf8');
      const cmd = user ? `crontab -u ${user} ${tmpFile}` : `crontab ${tmpFile}`;
      es(cmd, { timeout: 5000 });
      fs.unlinkSync(tmpFile);
      res.json({ ok: true });
    } catch (e) {
      try { fs.unlinkSync(tmpFile); } catch (_) {}
      res.status(500).json({ error: e.message });
    }
  });

  // ── System: dashboard stats ───────────────────────────────────────────────
  app.get('/api/system/stats', auth, (req, res) => {
    const { execSync: es } = require('child_process');
    const cpus = os.cpus();
    const total = os.totalmem();
    const free = os.freemem();
    const load = os.loadavg();
    let disk = '';
    try { disk = es('df -h / 2>/dev/null | tail -1', { timeout: 3000 }).toString().trim(); } catch (_) {}
    let netStats = '';
    try { netStats = es('cat /proc/net/dev 2>/dev/null | grep -v lo | tail -5', { timeout: 2000 }).toString().trim(); } catch (_) {}
    res.json({
      hostname: os.hostname(),
      platform: os.platform(),
      release: os.release(),
      uptime: os.uptime(),
      cpu: { cores: cpus.length, model: cpus[0]?.model?.trim() || '?', load1: load[0], load5: load[1], load15: load[2] },
      memory: { total, free, used: total - free, usedPct: Math.round((total - free) / total * 100) },
      disk,
      netStats,
    });
  });

  // ── Apps: discover all running applications ───────────────────────────────
  app.get('/api/apps/list', auth, async (req, res) => {
    function sh(cmd, timeout = 8000) {
      return new Promise(r => {
        require('child_process').exec(cmd, { timeout, maxBuffer: 2 * 1024 * 1024 }, (e, o) => r((o || '').trim()));
      });
    }

    const [ssOut, svcOut, dockerOut, pm2Out, supOut, procOut] = await Promise.all([
      sh('ss -tulnp 2>/dev/null'),
      sh('systemctl list-units --type=service --all --no-pager --no-legend 2>/dev/null'),
      sh('docker ps -a --format "{{.ID}}\\t{{.Image}}\\t{{.Status}}\\t{{.Ports}}\\t{{.Names}}" 2>/dev/null'),
      sh('pm2 jlist 2>/dev/null || echo "[]"'),
      sh('supervisorctl status 2>/dev/null || echo ""'),
      sh('ps -eo pid,ppid,user,%cpu,%mem,etime,cmd --no-header 2>/dev/null | grep -E "(node|python3?|ruby|php|gunicorn|uvicorn|puma|unicorn|bun|deno|go\\s)" | grep -v grep | head -60'),
    ]);

    // Parse ss: port → { pid, pname }
    const portsByPid = new Map();
    for (const line of ssOut.split('\n')) {
      const m = line.match(/(?:tcp|udp)\s+\S+\s+\d+\s+\d+\s+\S+:(\d+)\s+\S+\s+users:\(\("([^"]+)",pid=(\d+)/);
      if (!m) continue;
      const [, port, pname, pid] = [, m[1], m[2], m[3]];
      const k = parseInt(pid);
      if (!portsByPid.has(k)) portsByPid.set(k, { ports: [], pname });
      portsByPid.get(k).ports.push(parseInt(port));
    }

    // Parse systemctl
    const services = {};
    for (const line of svcOut.split('\n')) {
      const m = line.trim().match(/^(\S+)\.service\s+\S+\s+(\S+)\s+(\S+)\s+(.*)/);
      if (m) services[m[1]] = { active: m[2], sub: m[3], desc: m[4].trim() };
    }

    const iconMap = {
      nginx:'🌐', apache2:'🌐', httpd:'🌐', caddy:'🌐', traefik:'🌐',
      mysql:'🗄️', mariadb:'🗄️', mysqld:'🗄️',
      postgresql:'🐘', postgres:'🐘', 'postgresql@14':'🐘', 'postgresql@15':'🐘', 'postgresql@16':'🐘',
      redis:'🔴', 'redis-server':'🔴',
      mongodb:'🍃', mongod:'🍃',
      docker:'🐳', containerd:'🐳',
      ssh:'🔑', sshd:'🔑', openssh:'🔑',
      ufw:'🛡️', fail2ban:'🛡️', firewalld:'🛡️',
      node:'💚', nodejs:'💚',
      python3:'🐍', python:'🐍', gunicorn:'🐍', uvicorn:'🐍',
      php:'🔷', 'php-fpm':'🔷', php8:'🔷',
      certbot:'🔒', 'acme.sh':'🔒',
      grafana:'📊', 'grafana-server':'📊', prometheus:'📊',
      elasticsearch:'🔍', kibana:'🔍',
      rabbitmq:'🐰', kafka:'📨',
      nextcloud:'☁️', wordpress:'🌀',
      'minecraft-server':'⛏️', minecraft:'⛏️',
      plesk:'💼', cpanel:'💼',
      postfix:'📧', dovecot:'📧', sendmail:'📧',
      haproxy:'⚖️',
      varnish:'🚀',
    };

    function getIcon(name) {
      const lower = name.toLowerCase().replace(/-service$/, '').replace(/\.service$/, '');
      for (const [k, v] of Object.entries(iconMap)) {
        if (lower === k || lower.startsWith(k)) return v;
      }
      return '⚙️';
    }

    // Get MainPID for each running service
    const pidToService = new Map();
    const runningServices = Object.entries(services).filter(([, s]) => s.sub === 'running');
    await Promise.all(runningServices.map(async ([name]) => {
      const out = await sh(`systemctl show -p MainPID ${name} 2>/dev/null`, 2000);
      const m = out.match(/MainPID=(\d+)/);
      if (m && parseInt(m[1]) > 0) pidToService.set(parseInt(m[1]), name);
    }));

    const apps = [];
    const addedServices = new Set();

    // Build process/service apps from ports
    for (const [pid, { ports, pname }] of portsByPid) {
      const svcName = pidToService.get(pid);
      if (svcName && !addedServices.has(svcName)) {
        addedServices.add(svcName);
        apps.push({ id: 'svc:' + svcName, name: svcName, type: 'service', serviceName: svcName, pid, status: 'running', ports, icon: getIcon(svcName) || getIcon(pname), description: services[svcName]?.desc || '' });
      } else if (!svcName) {
        const ex = apps.find(a => a.type === 'process' && a.name === pname);
        if (ex) ex.ports.push(...ports);
        else apps.push({ id: 'proc:' + pname + ':' + pid, name: pname, type: 'process', pid, status: 'running', ports, icon: getIcon(pname), description: 'PID ' + pid });
      }
    }

    // Add all running services that didn't show up in ports
    for (const [name, info] of Object.entries(services)) {
      if (info.sub !== 'running') continue;
      if (addedServices.has(name)) continue;
      if (apps.find(a => a.id === 'svc:' + name)) continue;
      const skip = ['getty','systemd-','dbus','udev','accounts-','polkit','logind','timesyncd','networkd-','resolved','snapd','colord','rtkit','avahi','bluetooth','cups','ModemManager','packagekit','udisks'];
      if (skip.some(s => name.startsWith(s))) continue;
      apps.push({ id: 'svc:' + name, name, type: 'service', serviceName: name, status: 'running', ports: [], icon: getIcon(name), description: info.desc });
    }

    // Add known stopped services
    const known = ['nginx','apache2','httpd','mysql','mariadb','postgresql','redis','redis-server','mongodb','fail2ban','grafana-server','prometheus','postfix','dovecot','haproxy','varnish','caddy','traefik'];
    for (const name of known) {
      if (services[name] && services[name].sub !== 'running' && !apps.find(a => a.id === 'svc:' + name)) {
        const info = services[name];
        apps.push({ id: 'svc:' + name, name, type: 'service', serviceName: name, status: info.sub === 'failed' ? 'failed' : 'stopped', ports: [], icon: getIcon(name), description: info.desc });
      }
    }

    // Docker containers
    for (const line of dockerOut.split('\n').filter(Boolean)) {
      const parts = line.split('\t');
      if (parts.length < 5) continue;
      const [cid, image, status, portStr, name] = parts.map(p => p.trim());
      const running = status.startsWith('Up');
      const ports = [];
      for (const m of portStr.matchAll(/(\d+)->(\d+)\/tcp/g)) ports.push(parseInt(m[1]));
      apps.push({ id: 'docker:' + cid.slice(0, 12), name: name || cid.slice(0, 12), type: 'docker', image, status: running ? 'running' : 'stopped', ports, icon: '🐳', containerId: cid, description: image });
    }

    // ── pm2 managed apps ────────────────────────────────────────────────────
    try {
      const pm2Apps = JSON.parse(pm2Out || '[]');
      for (const p of pm2Apps) {
        const env = p.pm2_env || {};
        const id = 'pm2:' + (p.pm_id ?? p.name);
        if (apps.find(a => a.id === id)) continue;
        const running = env.status === 'online';
        const uptime = running && env.pm_uptime ? Math.floor((Date.now() - env.pm_uptime) / 1000) : null;
        const script = env.pm_exec_path || env.script || '';
        apps.push({
          id,
          name: p.name || ('pm2-' + p.pm_id),
          type: 'custom',
          source: 'pm2',
          pid: p.pid || null,
          status: running ? 'running' : (env.status === 'errored' ? 'failed' : 'stopped'),
          ports: [],
          icon: getIcon(p.name) || '💚',
          description: script ? script.replace(/^.*\//, '') : ('pm2 #' + p.pm_id),
          uptime,
          cpu: env.monit ? env.monit.cpu : null,
          mem: env.monit ? env.monit.memory : null,
        });
      }
    } catch (_) {}

    // ── supervisor managed apps ──────────────────────────────────────────────
    if (supOut) {
      for (const line of supOut.split('\n').filter(Boolean)) {
        const m = line.match(/^(\S+)\s+(RUNNING|STOPPED|FATAL|STARTING|STOPPING|EXITED|BACKOFF)\s+(.*)$/i);
        if (!m) continue;
        const [, name, rawStatus, detail] = m;
        const id = 'sup:' + name;
        if (apps.find(a => a.id === id)) continue;
        const status = rawStatus.toLowerCase() === 'running' ? 'running'
          : rawStatus.toLowerCase() === 'fatal' ? 'failed' : 'stopped';
        const pidM = detail.match(/pid (\d+)/);
        apps.push({
          id,
          name,
          type: 'custom',
          source: 'supervisor',
          pid: pidM ? parseInt(pidM[1]) : null,
          status,
          ports: [],
          icon: getIcon(name) || '⚙️',
          description: detail.trim(),
        });
      }
    }

    // ── bare custom processes (node/python/etc not already captured) ─────────
    const customProcPids = new Set(apps.map(a => a.pid).filter(Boolean));
    for (const line of procOut.split('\n').filter(Boolean)) {
      const parts = line.trim().split(/\s+/);
      if (parts.length < 7) continue;
      const [pid, , user, cpu, mem, etime, ...cmdParts] = parts;
      const pidNum = parseInt(pid);
      if (customProcPids.has(pidNum)) continue;
      // Skip system/root processes that are clearly not custom apps
      const cmd = cmdParts.join(' ');
      const exe = cmdParts[0] || '';
      if (exe.startsWith('-') || cmd.includes('apt') || cmd.includes('systemd') || cmd.includes('sshd') || cmd.includes('/usr/lib')) continue;
      // Use the script name as app name
      const scriptArg = cmdParts.find(a => a.endsWith('.js') || a.endsWith('.py') || a.endsWith('.rb') || a.endsWith('.ts'));
      const appName = scriptArg ? scriptArg.replace(/^.*\//, '') : exe.replace(/^.*\//, '');
      if (!appName || appName.length < 2) continue;
      const existingId = 'proc:' + appName + ':' + pidNum;
      if (apps.find(a => a.id === existingId || (a.pid === pidNum))) continue;
      customProcPids.add(pidNum);
      apps.push({
        id: existingId,
        name: appName,
        type: 'custom',
        source: 'process',
        pid: pidNum,
        user,
        status: 'running',
        ports: portsByPid.has(pidNum) ? portsByPid.get(pidNum).ports : [],
        icon: getIcon(appName) || (exe.includes('node') || exe.includes('bun') ? '💚' : exe.includes('python') ? '🐍' : exe.includes('ruby') ? '💎' : '⚙️'),
        description: cmd.slice(0, 80),
        cpu: parseFloat(cpu),
        mem: parseFloat(mem),
        etime,
      });
    }

    apps.sort((a, b) => {
      const rank = { running: 0, failed: 1, stopped: 2 };
      const ra = rank[a.status] ?? 3, rb = rank[b.status] ?? 3;
      if (ra !== rb) return ra - rb;
      // custom apps float to top within their status group
      if (a.type === 'custom' && b.type !== 'custom') return -1;
      if (b.type === 'custom' && a.type !== 'custom') return 1;
      return a.name.localeCompare(b.name);
    });

    res.json({ apps });
  });

  // ── Apps: start / stop / restart ──────────────────────────────────────────
  app.post('/api/apps/action', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { id, action } = req.body || {};
    const allowed = ['start', 'stop', 'restart', 'enable', 'disable'];
    if (!allowed.includes(action)) return res.status(400).json({ error: 'Invalid action' });

    if (id.startsWith('svc:')) {
      const r = await sudoRun(cred, `systemctl ${action} ${id.slice(4)}`);
      return res.json({ ok: r.ok, output: r.output });
    }
    if (id.startsWith('docker:')) {
      const act = action === 'enable' ? 'start' : action === 'disable' ? 'stop' : action;
      const r = await sudoRun(cred, `docker ${act} ${id.slice(7)}`);
      return res.json({ ok: r.ok, output: r.output });
    }
    if (id.startsWith('pm2:')) {
      const name = id.slice(4);
      const pm2Action = action === 'enable' ? 'start' : action === 'disable' ? 'stop' : action;
      const r = await sudoRun(cred, `pm2 ${pm2Action} ${name}`);
      return res.json({ ok: r.ok, output: r.output });
    }
    if (id.startsWith('sup:')) {
      const name = id.slice(4);
      const supAction = action === 'enable' ? 'start' : action === 'disable' ? 'stop' : action;
      const r = await sudoRun(cred, `supervisorctl ${supAction} ${name}`);
      return res.json({ ok: r.ok, output: r.output });
    }
    if ((id.startsWith('proc:') || id.startsWith('pm2:') || id.startsWith('sup:')) && action === 'stop') {
      const pid = id.split(':')[2];
      if (pid) {
        const r = await sudoRun(cred, `kill ${pid}`);
        return res.json({ ok: r.ok, output: r.output });
      }
    }
    res.status(400).json({ error: 'Cannot perform this action on this app type' });
  });

  // ── Apps: logs ────────────────────────────────────────────────────────────
  app.get('/api/apps/logs', auth, (req, res) => {
    const { id, lines = 150 } = req.query;
    if (!id) return res.status(400).json({ error: 'Missing id' });
    let cmd;
    if (id.startsWith('svc:')) cmd = `journalctl -u ${id.slice(4)} -n ${parseInt(lines)} --no-pager --output=short-iso 2>/dev/null`;
    else if (id.startsWith('docker:')) cmd = `docker logs --tail ${parseInt(lines)} ${id.slice(7)} 2>&1`;
    else if (id.startsWith('pm2:')) cmd = `pm2 logs ${id.slice(4)} --lines ${parseInt(lines)} --nostream 2>/dev/null || pm2 logs ${id.slice(4)} --lines ${parseInt(lines)} 2>&1 | head -${parseInt(lines)}`;
    else if (id.startsWith('sup:')) cmd = `tail -n ${parseInt(lines)} /var/log/supervisor/${id.slice(4)}-stdout.log 2>/dev/null || journalctl -t ${id.slice(4)} -n ${parseInt(lines)} --no-pager 2>/dev/null || echo "No logs available"`;
    else if (id.startsWith('proc:')) { const pid = id.split(':')[2]; cmd = `journalctl _PID=${pid} -n ${parseInt(lines)} --no-pager 2>/dev/null || echo "No logs available for this process"`; }
    else return res.status(400).json({ error: 'Unsupported type' });
    require('child_process').exec(cmd, { timeout: 10000, maxBuffer: 2 * 1024 * 1024 }, (e, o) => res.json({ output: (o || '').trim() }));
  });

  // ── Apps: change port ─────────────────────────────────────────────────────
  app.post('/api/apps/port', auth, async (req, res) => {
    const cred = sudoCredentials.get(req.headers['x-drift-token'] || '');
    if (!cred) return res.status(403).json({ error: 'Sudo auth required' });
    const { id, oldPort, newPort } = req.body || {};
    if (!oldPort || !newPort || isNaN(newPort) || newPort < 1 || newPort > 65535)
      return res.status(400).json({ error: 'Invalid port values' });
    if (!id.startsWith('svc:')) return res.status(400).json({ error: 'Port editing only supported for system services' });

    const svcName = id.slice(4);
    const configFiles = {
      nginx: ['/etc/nginx/nginx.conf', '/etc/nginx/sites-enabled/default'],
      apache2: ['/etc/apache2/ports.conf'],
      httpd: ['/etc/httpd/conf/httpd.conf'],
      mysql: ['/etc/mysql/mysql.conf.d/mysqld.cnf', '/etc/mysql/my.cnf'],
      redis: ['/etc/redis/redis.conf'],
      mongodb: ['/etc/mongod.conf'],
      caddy: ['/etc/caddy/Caddyfile'],
    };
    const files = configFiles[svcName];
    if (!files) return res.status(400).json({ error: `Auto port-change not supported for "${svcName}". Edit the config file in the Files manager.` });

    // Try each known config file
    const { execSync: es } = require('child_process');
    let changed = false;
    let changedFile = '';
    for (const f of files) {
      try {
        const content = es(`cat ${f} 2>/dev/null`, { timeout: 2000 }).toString();
        if (content.includes(String(oldPort))) {
          const r = await sudoRun(cred, `sed -i 's/\\b${oldPort}\\b/${newPort}/g' ${f}`);
          if (r.ok) { changed = true; changedFile = f; break; }
        }
      } catch (_) {}
    }
    if (!changed) return res.status(404).json({ error: `Port ${oldPort} not found in config files for ${svcName}` });

    const r2 = await sudoRun(cred, `systemctl restart ${svcName}`);
    res.json({ ok: true, message: `Port changed in ${changedFile}. ${svcName} restarted.`, restarted: r2.ok });
  });

  // ── PM2: list ─────────────────────────────────────────────────────────────
  app.get('/api/pm2/list', auth, (req, res) => {
    require('child_process').exec('pm2 jlist 2>/dev/null', { timeout: 8000, maxBuffer: 2*1024*1024 }, (err, out) => {
      if (!out || out.trim() === '' || out.trim() === '[]') return res.json({ apps: [], unavailable: true });
      try {
        const raw = JSON.parse(out.trim());
        const apps = raw.map(p => ({
          id: p.pm_id,
          name: p.name,
          pid: p.pid || null,
          status: p.pm2_env?.status || 'stopped',
          cpu: p.monit?.cpu ?? null,
          mem: p.monit?.memory ?? null,
          uptime: (p.pm2_env?.status === 'online' && p.pm2_env?.pm_uptime)
            ? Math.floor((Date.now() - p.pm2_env.pm_uptime) / 1000) : null,
          restarts: p.pm2_env?.restart_time ?? 0,
          script: p.pm2_env?.pm_exec_path || p.pm2_env?.script || '',
          mode: p.pm2_env?.exec_mode || 'fork',
          watching: p.pm2_env?.watch || false,
          namespace: p.pm2_env?.namespace || 'default',
        }));
        res.json({ apps });
      } catch (e) {
        res.json({ apps: [], error: 'Parse error: ' + e.message });
      }
    });
  });

  // ── PM2: action (no sudo — pm2 runs as current user) ──────────────────────
  app.post('/api/pm2/action', auth, (req, res) => {
    const { id, action } = req.body || {};
    const allowed = ['start', 'stop', 'restart', 'reload', 'delete'];
    if (!allowed.includes(action)) return res.status(400).json({ error: 'Invalid action' });
    if (id === undefined || id === null) return res.status(400).json({ error: 'Missing id' });
    require('child_process').exec(`pm2 ${action} ${id} 2>&1`, { timeout: 15000 }, (err, out) => {
      res.json({ ok: !err, output: (out || '').trim() });
    });
  });

  // ── PM2: start a new process ───────────────────────────────────────────────
  app.post('/api/pm2/start', auth, (req, res) => {
    const { script, name, args, watch } = req.body || {};
    if (!script) return res.status(400).json({ error: 'Missing script path' });
    const safeName = name ? `--name ${JSON.stringify(String(name).replace(/[^a-zA-Z0-9_.-]/g, '_'))} ` : '';
    const safeScript = JSON.stringify(String(script));
    const watchFlag = watch ? '--watch ' : '';
    const argsStr = args ? ` -- ${String(args)}` : '';
    const cmd = `pm2 start ${safeScript} ${safeName}${watchFlag}2>&1${argsStr}`;
    require('child_process').exec(cmd, { timeout: 20000 }, (err, out) => {
      res.json({ ok: !err, output: (out || '').trim() });
    });
  });

  // ── PM2: logs ─────────────────────────────────────────────────────────────
  app.get('/api/pm2/logs', auth, (req, res) => {
    const { id, lines = 120 } = req.query;
    const n = parseInt(lines);
    const target = id !== undefined ? String(id) : 'all';
    require('child_process').exec(
      `pm2 logs ${target} --lines ${n} --nostream --raw 2>&1 | tail -n ${n}`,
      { timeout: 12000, maxBuffer: 2*1024*1024 },
      (err, out) => res.json({ output: (out || 'No logs available').trim() })
    );
  });

  // ── PM2: save process list ─────────────────────────────────────────────────
  app.post('/api/pm2/save', auth, (req, res) => {
    require('child_process').exec('pm2 save 2>&1', { timeout: 10000 }, (err, out) => {
      res.json({ ok: !err, output: (out || '').trim() });
    });
  });

  // ── Apps: get config file paths for a service ─────────────────────────────
  app.get('/api/apps/config', auth, (req, res) => {
    const { id } = req.query;
    if (!id || !id.startsWith('svc:')) return res.status(400).json({ error: 'Services only' });
    const svcName = id.slice(4);
    const { execSync: es } = require('child_process');
    let unitFile = '';
    let configFiles = [];
    try {
      unitFile = es(`systemctl show -p FragmentPath ${svcName} 2>/dev/null`, { timeout: 3000 }).toString().match(/FragmentPath=(.*)/)?.[1]?.trim() || '';
    } catch (_) {}
    const knownConfigs = {
      nginx: ['/etc/nginx/nginx.conf', '/etc/nginx/sites-available', '/etc/nginx/sites-enabled'],
      apache2: ['/etc/apache2/apache2.conf', '/etc/apache2/ports.conf', '/etc/apache2/sites-enabled'],
      mysql: ['/etc/mysql/mysql.conf.d/mysqld.cnf'],
      mariadb: ['/etc/mysql/mariadb.conf.d/50-server.cnf'],
      redis: ['/etc/redis/redis.conf'],
      postgresql: ['/etc/postgresql'],
      mongodb: ['/etc/mongod.conf'],
      caddy: ['/etc/caddy/Caddyfile'],
      postfix: ['/etc/postfix/main.cf'],
    };
    configFiles = knownConfigs[svcName] || [];
    res.json({ unitFile, configFiles });
  });

  // ── My Apps ───────────────────────────────────────────────────────────────────
  const MYAPPS_PID_FILE = path.join(os.homedir(), '.drift-myapps-pids.json');

  function myappReadPids() {
    try { return JSON.parse(fs.readFileSync(MYAPPS_PID_FILE, 'utf8')); } catch { return {}; }
  }
  function myappWritePids(pids) {
    try { fs.writeFileSync(MYAPPS_PID_FILE, JSON.stringify(pids, null, 2), 'utf8'); } catch {}
  }
  function myappIsAlive(pid) {
    try { process.kill(parseInt(pid), 0); return true; } catch { return false; }
  }

  const MY_APPS = [
    {
      id: 'myapp:personaos', name: 'PersonaOS', icon: '👤',
      description: 'Multi-user virtual desktop environment',
      dir: path.join(os.homedir(), 'PersonaOS'),
      cmd: 'node', args: ['server.js'],
      detectIn: [path.join(os.homedir(), 'PersonaOS', 'server.js')],
      port: { type: 'json', file: path.join(os.homedir(), 'PersonaOS/PersonaOS-config/config.json'), key: 'server.port', default: 3000 },
    },
    {
      id: 'myapp:docuvault', name: 'DocuVault', icon: '📄',
      description: 'Document vault & management',
      dir: path.join(os.homedir(), 'DocuVault/docvault_final'),
      cmd: 'node', args: ['server.js'],
      detectIn: [path.join(os.homedir(), 'DocuVault/docvault_final')],
      port: { type: 'env', file: path.join(os.homedir(), 'DocuVault/docvault_final/.env'), key: 'PORT', default: 3012 },
    },
    {
      id: 'myapp:itcc', name: 'ITControlCenter', icon: '🖥️',
      description: 'Nexus Control Center',
      dir: path.join(os.homedir(), 'ITControlCenter/nexus-control'),
      cmd: 'node', args: ['server/index.js'],
      detectIn: [path.join(os.homedir(), 'ITControlCenter/nexus-control/server/index.js')],
      port: { type: 'env', file: path.join(os.homedir(), 'ITControlCenter/nexus-control/.env'), key: 'PORT', default: 3000 },
    },
    {
      id: 'myapp:retrogrid', name: 'RetroGrid', icon: '🎮',
      description: 'Cloud retro gaming platform',
      dir: path.join(os.homedir(), 'CloudGaming'),
      cmd: 'node', args: ['server/index.js'],
      detectIn: [path.join(os.homedir(), 'CloudGaming/server/index.js')],
      port: { type: 'env', file: path.join(os.homedir(), 'CloudGaming/.env'), key: 'PORT', default: 3000 },
    },
    {
      id: 'myapp:pwdmgr', name: 'PasswordManager', icon: '🔐',
      description: 'Family password manager',
      dir: path.join(os.homedir(), 'PasswordManager/server'),
      cmd: 'node', args: ['server.js'],
      detectIn: [path.join(os.homedir(), 'PasswordManager/server/server.js')],
      port: { type: 'env', file: path.join(os.homedir(), 'PasswordManager/.env'), key: 'PORT', default: 3001 },
    },
    {
      id: 'myapp:dryft', name: 'DryftExplorer', icon: '🗂️',
      description: 'File explorer & server manager (web mode)',
      dir: path.join(os.homedir(), 'DryftExplorer'),
      cmd: 'node', args: ['bin/drift.js', '--web'],
      detectIn: ['drift.js --web', path.join(os.homedir(), 'DryftExplorer/bin/drift.js')],
      port: { type: 'drift-config', default: 7473 },
    },
  ];

  function myappReadPort(portCfg) {
    try {
      if (portCfg.type === 'env') {
        if (!fs.existsSync(portCfg.file)) return portCfg.default;
        const line = fs.readFileSync(portCfg.file, 'utf8').split('\n').find(l => l.startsWith(portCfg.key + '='));
        return line ? (parseInt(line.split('=')[1]) || portCfg.default) : portCfg.default;
      }
      if (portCfg.type === 'json') {
        const data = JSON.parse(fs.readFileSync(portCfg.file, 'utf8'));
        let v = data;
        for (const k of portCfg.key.split('.')) v = v?.[k];
        return parseInt(v) || portCfg.default;
      }
      if (portCfg.type === 'drift-config') {
        resetCache();
        return loadConfig().web.port;
      }
    } catch {}
    return portCfg.default;
  }

  function myappWritePort(portCfg, newPort) {
    if (portCfg.type === 'env') {
      let content = '';
      try { content = fs.readFileSync(portCfg.file, 'utf8'); } catch {}
      const lines = content.split('\n');
      let found = false;
      const updated = lines.map(l => {
        if (l.startsWith(portCfg.key + '=')) { found = true; return `${portCfg.key}=${newPort}`; }
        return l;
      });
      if (!found) updated.unshift(`${portCfg.key}=${newPort}`);
      fs.writeFileSync(portCfg.file, updated.join('\n'), 'utf8');
    } else if (portCfg.type === 'json') {
      const data = JSON.parse(fs.readFileSync(portCfg.file, 'utf8'));
      const keys = portCfg.key.split('.');
      let v = data;
      for (let i = 0; i < keys.length - 1; i++) v = v[keys[i]];
      v[keys[keys.length - 1]] = newPort;
      fs.writeFileSync(portCfg.file, JSON.stringify(data, null, 2) + '\n', 'utf8');
    } else if (portCfg.type === 'drift-config') {
      saveConfig({ web: { port: newPort } });
      resetCache();
    }
  }

  app.get('/api/myapps/list', auth, (req, res) => {
    const pids = myappReadPids();
    let psOut = '';
    try { psOut = require('child_process').execSync('ps -eo pid,cmd --no-header 2>/dev/null', { timeout: 3000 }).toString(); } catch {}

    const result = MY_APPS.map(def => {
      let pid = pids[def.id] ? parseInt(pids[def.id]) : null;
      let running = !!(pid && myappIsAlive(pid));

      if (!running) {
        pid = null;
        for (const line of psOut.split('\n')) {
          if (def.detectIn.some(p => line.includes(p))) {
            const m = line.trim().match(/^(\d+)/);
            if (m) { pid = parseInt(m[1]); running = true; break; }
          }
        }
        // Update PID cache if we found it via ps
        if (running && pid) { pids[def.id] = pid; myappWritePids(pids); }
        else if (!running && pids[def.id]) { delete pids[def.id]; myappWritePids(pids); }
      }

      return { id: def.id, name: def.name, icon: def.icon, description: def.description, dir: def.dir, status: running ? 'running' : 'stopped', pid: pid || null, port: myappReadPort(def.port) };
    });

    res.json({ apps: result });
  });

  app.post('/api/myapps/action', auth, (req, res) => {
    const { id, action } = req.body || {};
    const def = MY_APPS.find(a => a.id === id);
    if (!def) return res.status(404).json({ error: 'Unknown app' });
    if (!['start', 'stop', 'restart'].includes(action)) return res.status(400).json({ error: 'Invalid action' });

    const pids = myappReadPids();
    const { spawn, execSync: es } = require('child_process');

    function doStop() {
      const pid = pids[def.id] ? parseInt(pids[def.id]) : null;
      if (pid && myappIsAlive(pid)) try { process.kill(pid, 'SIGTERM'); } catch {}
      try {
        const psOut = es('ps -eo pid,cmd --no-header 2>/dev/null', { timeout: 3000 }).toString();
        for (const line of psOut.split('\n')) {
          if (def.detectIn.some(p => line.includes(p))) {
            const m = line.trim().match(/^(\d+)/);
            if (m) try { process.kill(parseInt(m[1]), 'SIGTERM'); } catch {}
          }
        }
      } catch {}
      delete pids[def.id];
      myappWritePids(pids);
    }

    function doStart() {
      const port = myappReadPort(def.port);
      const env = { ...process.env };
      if (def.port.type === 'env') env[def.port.key] = String(port);
      const proc = spawn(def.cmd, def.args, { cwd: def.dir, detached: true, stdio: 'ignore', env });
      pids[def.id] = proc.pid;
      myappWritePids(pids);
      proc.unref();
      return proc.pid;
    }

    if (action === 'stop') { doStop(); return res.json({ ok: true, message: `${def.name} stopped` }); }
    if (action === 'start') { const pid = doStart(); return res.json({ ok: true, message: `${def.name} started`, pid }); }
    if (action === 'restart') {
      doStop();
      setTimeout(() => { const pid = doStart(); res.json({ ok: true, message: `${def.name} restarted`, pid }); }, 600);
    }
  });

  app.post('/api/myapps/port', auth, (req, res) => {
    const { id, port } = req.body || {};
    const def = MY_APPS.find(a => a.id === id);
    if (!def) return res.status(404).json({ error: 'Unknown app' });
    const newPort = parseInt(port);
    if (!newPort || newPort < 1 || newPort > 65535) return res.status(400).json({ error: 'Invalid port number' });
    try {
      myappWritePort(def.port, newPort);
      res.json({ ok: true, message: `Port updated to ${newPort} in config. Restart the app to apply.` });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });

  return app;
}

// ─── Helper ───────────────────────────────────────────────────────────────────

function isBinary(buf) {
  for (let i = 0; i < buf.length; i++) {
    if (buf[i] === 0) return true;
  }
  return false;
}

// ─── Start server ─────────────────────────────────────────────────────────────

function startServer() {
  const cfg = loadConfig();
  const port = cfg.web.port;
  const app = buildApp(cfg);

  const server = app.listen(port, '0.0.0.0', () => {
    const authNote = cfg.web.password
      ? `  Password:  set in ${CONFIG_PATH}\n`
      : `  Auth:      none (set web.password in ${CONFIG_PATH} to enable)\n`;
    const rootNote = `  Root dir:  ${cfg.web.rootDir}\n`;

    process.stdout.write(
      '\n' +
      '  ██████╗ ██████╗ ██╗███████╗████████╗\n' +
      '  ██╔══██╗██╔══██╗██║██╔════╝╚══██╔══╝\n' +
      '  ██║  ██║██████╔╝██║█████╗     ██║\n' +
      '  ██║  ██║██╔══██╗██║██╔══╝     ██║\n' +
      '  ██████╔╝██║  ██║██║██║        ██║\n' +
      '  ╚═════╝ ╚═╝  ╚═╝╚═╝╚═╝        ╚═╝  web\n' +
      '\n' +
      `  Listening: http://localhost:${port}\n` +
      authNote +
      rootNote +
      '\n  Press Ctrl+C to stop\n\n'
    );
  });

  // ── WebSocket PTY terminal ─────────────────────────────────────────────────
  let pty, WebSocketServer;
  try {
    pty = require('@homebridge/node-pty-prebuilt-multiarch');
    ({ WebSocketServer } = require('ws'));
  } catch (e) {
    console.error('  [terminal] PTY or WS module not found — terminal disabled:', e.message);
  }

  if (pty && WebSocketServer) {
    const wss = new WebSocketServer({ noServer: true });

    server.on('upgrade', (req, socket, head) => {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname !== '/ws/terminal') { socket.destroy(); return; }

      const token = url.searchParams.get('token') || '';
      if (cfg.web.password && !validToken(token)) {
        socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
        socket.destroy();
        return;
      }

      wss.handleUpgrade(req, socket, head, ws => {
        const cols = Math.max(10, parseInt(url.searchParams.get('cols') || '220'));
        const rows = Math.max(5,  parseInt(url.searchParams.get('rows') || '50'));
        const cwd  = terminalCwds.get(token) || cfg.web.rootDir;
        const shell = process.env.SHELL || '/bin/bash';

        let proc;
        try {
          proc = pty.spawn(shell, [], {
            name: 'xterm-256color',
            cols, rows, cwd,
            env: { ...process.env, TERM: 'xterm-256color', COLORTERM: 'truecolor' },
          });
        } catch (e) {
          ws.send(JSON.stringify({ type: 'output', data: `\r\nFailed to start shell: ${e.message}\r\n` }));
          ws.close();
          return;
        }

        proc.onData(data => {
          if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ type: 'output', data }));
        });

        proc.onExit(() => {
          if (ws.readyState === ws.OPEN) {
            ws.send(JSON.stringify({ type: 'exit' }));
            ws.close();
          }
        });

        ws.on('message', raw => {
          try {
            const msg = JSON.parse(raw);
            if (msg.type === 'input')  proc.write(msg.data);
            if (msg.type === 'resize') proc.resize(
              Math.max(10, msg.cols),
              Math.max(5,  msg.rows)
            );
          } catch (_) {}
        });

        ws.on('close', () => { try { proc.kill(); } catch (_) {} });
      });
    });
  }

  server.on('error', err => {
    if (err.code === 'EADDRINUSE') {
      console.error(`\n  Port ${port} is already in use. Change web.port in ${CONFIG_PATH}\n`);
    } else {
      console.error('\n  Server error:', err.message);
    }
    process.exit(1);
  });
}

module.exports = { startServer };

// Allow running directly: node src/server.js
if (require.main === module) {
  startServer();
}
