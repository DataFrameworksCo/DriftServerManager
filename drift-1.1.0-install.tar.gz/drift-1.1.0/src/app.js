'use strict';

const blessed = require('blessed');
const path = require('path');
const fs = require('fs');
const { exec, spawn } = require('child_process');
const { loadConfig, CONFIG_PATH } = require('./config');

const {
  listDirectory, deleteEntry, renameEntry,
  copyEntry, moveEntry, createFile, createDirectory, formatSize,
} = require('./fileops');
const { getFilePreview } = require('./preview');
const { flatList, runTool } = require('./tools');

// ─── State ────────────────────────────────────────────────────────────────────

const state = {
  cwd: process.argv[2] ? path.resolve(process.argv[2]) : process.cwd(),
  entries: [],      // all entries in current directory
  filtered: [],     // entries after search filter
  selectedIdx: 0,
  // search
  searchMode: false,
  searchQuery: '',

  // inline input prompt (rename, new file, etc.)
  inputMode: null,  // { prompt, value, callback } | null

  // confirm dialog
  confirmMode: null, // { message, callback } | null

  // clipboard
  clipboard: null,  // { srcPath, op: 'copy' | 'cut' } | null

  // message auto-clear timer
  msgTimer: null,

  // set from config on startup
  showHidden: false,

  // true while an external editor is open — blocks all blessed keypress handling
  editorOpen: false,

  // tools panel
  toolsMode: false,
  toolRows: [],
  toolIdx: 0,
  toolOutput: '',
  toolRunning: false,
  toolRefreshTimer: null,
};

// ─── Screen & widgets ─────────────────────────────────────────────────────────

const screen = blessed.screen({
  smartCSR: true,
  title: 'Drift',
  fullUnicode: true,
  forceUnicode: true,
  cursor: { artificial: true, shape: 'line', blink: true, color: 'white' },
});

/** Top bar: logo + current path */
const header = blessed.box({
  parent: screen,
  top: 0, left: 0, right: 0, height: 1,
  tags: true,
  style: { bg: 'blue', fg: 'white', bold: true },
});

/** Left panel: file/directory list */
const listBox = blessed.box({
  parent: screen,
  top: 1, left: 0,
  width: '38%', bottom: 2,
  border: { type: 'line' },
  scrollable: true,
  tags: true,
  style: { border: { fg: 'blue' } },
  scrollbar: { ch: ' ', style: { bg: 'blue' } },
});

/** Right panel: file preview */
const previewBox = blessed.box({
  parent: screen,
  top: 1, left: '38%', right: 0, bottom: 2,
  border: { type: 'line' },
  scrollable: true,
  alwaysScroll: true,
  tags: true,
  style: { border: { fg: 'cyan' } },
  scrollbar: { ch: ' ', style: { bg: 'cyan' } },
  mouse: true,
});

/** Second-to-last row: key hint bar */
const hintBar = blessed.box({
  parent: screen,
  bottom: 1, left: 0, right: 0, height: 1,
  tags: true,
  style: { bg: 'blue', fg: 'white' },
});

/** Last row: messages / input / confirm prompts */
const msgBar = blessed.box({
  parent: screen,
  bottom: 0, left: 0, right: 0, height: 1,
  tags: true,
  style: { bg: 'black', fg: 'white' },
});

// ─── Rendering ────────────────────────────────────────────────────────────────

function renderHeader() {
  if (state.toolsMode) {
    header.setContent(' {bold}DRIFT{/bold}  {cyan-fg}Tools{/cyan-fg}');
    return;
  }
  const home = process.env.HOME || '';
  const display = state.cwd.startsWith(home)
    ? '~' + state.cwd.slice(home.length)
    : state.cwd;
  const clip = state.clipboard
    ? `  {yellow-fg}[${state.clipboard.op === 'copy' ? 'copy' : 'cut'}: ${escTag(path.basename(state.clipboard.srcPath))}]{/yellow-fg}`
    : '';
  header.setContent(` {bold}DRIFT{/bold}  {white-fg}${escTag(display)}{/white-fg}${clip}`);
}

function renderList() {
  if (state.filtered.length === 0) {
    const msg = state.searchMode
      ? `\n  {gray-fg}No results for "${escTag(state.searchQuery)}"{/gray-fg}`
      : '\n  {gray-fg}(empty){/gray-fg}';
    listBox.setContent(msg);
    screen.render();
    return;
  }

  const lines = state.filtered.map((entry, i) => {
    const sel = i === state.selectedIdx;
    const icon = entry.isDirectory ? '▸' : ' ';
    const suffix = entry.isDirectory ? '/' : '';
    const name = entry.name + suffix;

    // truncate long names to fit panel width (approx)
    const maxLen = Math.max(10, (listBox.width || 40) - 7);
    const display = name.length > maxLen
      ? name.slice(0, maxLen - 2) + '…'
      : name;

    if (sel) {
      return `{black-fg}{white-bg} ${icon} ${escTag(display)} {/white-bg}{/black-fg}`;
    }
    if (entry.isDirectory) {
      return `{cyan-fg} ${icon} ${escTag(display)}{/cyan-fg}`;
    }

    // colour regular files by extension group
    const ext = path.extname(entry.name).slice(1).toLowerCase();
    if (['js', 'mjs', 'ts', 'jsx', 'tsx'].includes(ext))
      return `{yellow-fg} ${icon} ${escTag(display)}{/yellow-fg}`;
    if (['json', 'yaml', 'yml', 'toml'].includes(ext))
      return `{green-fg} ${icon} ${escTag(display)}{/green-fg}`;
    if (['md', 'txt', 'rst'].includes(ext))
      return `{white-fg} ${icon} ${escTag(display)}{/white-fg}`;
    if (['png', 'jpg', 'jpeg', 'gif', 'svg', 'ico', 'webp'].includes(ext))
      return `{magenta-fg} ${icon} ${escTag(display)}{/magenta-fg}`;
    if (['sh', 'bash', 'zsh', 'fish'].includes(ext))
      return `{green-fg} ${icon} ${escTag(display)}{/green-fg}`;
    if (entry.isSymlink)
      return `{cyan-fg} ${icon} ${escTag(display)}{/cyan-fg}`;
    return ` ${icon} ${escTag(display)}`;
  });

  listBox.setContent(lines.join('\n'));

  // keep selected row visible
  const visibleRows = Math.max(1, (listBox.height || 20) - 2);
  const scrollTarget = Math.max(0, state.selectedIdx - Math.floor(visibleRows / 2));
  listBox.scrollTo(scrollTarget);

  screen.render();
}

function renderPreview() {
  if (state.filtered.length === 0) {
    previewBox.setContent('');
    screen.render();
    return;
  }
  const entry = state.filtered[state.selectedIdx];
  if (!entry) return;
  previewBox.setContent(getFilePreview(entry));
  previewBox.scrollTo(0);
  screen.render();
}

function renderHints() {
  if (state.toolsMode) {
    renderToolHints();
    return;
  }
  if (state.searchMode) {
    hintBar.setContent(
      '  {bold}/{/bold} type to filter  ' +
      '{bold}↑↓{/bold} navigate  ' +
      '{bold}Enter{/bold} confirm  ' +
      '{bold}Esc{/bold} cancel search'
    );
    return;
  }
  hintBar.setContent(
    '  {bold}↑↓{/bold} nav  ' +
    '{bold}Enter{/bold} edit/open  ' +
    '{bold}Bksp{/bold} up  ' +
    '{bold}/{/bold} search  ' +
    '{bold}e{/bold} export  ' +
    '{bold}d{/bold} del  ' +
    '{bold}r{/bold} rename  ' +
    '{bold}c{/bold} copy  ' +
    '{bold}m{/bold} cut  ' +
    '{bold}p{/bold} paste  ' +
    '{bold}n{/bold} file  ' +
    '{bold}N{/bold} dir  ' +
    '{bold}.{/bold} hidden  ' +
    '{bold}t{/bold} tools  ' +
    '{bold}q{/bold} quit'
  );
}

function showMsg(text, type = 'info', ms = 3500) {
  if (state.msgTimer) clearTimeout(state.msgTimer);
  const color = type === 'error' ? 'red-fg'
    : type === 'success' ? 'green-fg'
    : 'white-fg';
  msgBar.setContent(` {${color}}${escTag(text)}{/${color}}`);
  screen.render();
  state.msgTimer = setTimeout(() => {
    if (!state.inputMode && !state.confirmMode) {
      msgBar.setContent('');
      screen.render();
    }
  }, ms);
}

function clearMsg() {
  if (state.msgTimer) clearTimeout(state.msgTimer);
  msgBar.setContent('');
  screen.render();
}

function renderInputPrompt() {
  if (!state.inputMode) return;
  const { prompt, value } = state.inputMode;
  msgBar.setContent(` {bold}${escTag(prompt)}:{/bold}  ${escTag(value)}{white-fg}▌{/white-fg}`);
  screen.render();
}

function renderConfirm() {
  if (!state.confirmMode) return;
  msgBar.setContent(` {bold}{yellow-fg}${escTag(state.confirmMode.message)}{/yellow-fg}{/bold}  {white-fg}[y]{/white-fg} yes  {white-fg}[n/Esc]{/white-fg} no`);
  screen.render();
}

function fullRender() {
  if (state.toolsMode) {
    renderToolsPanel();
    return;
  }
  renderHeader();
  renderHints();
  renderList();
  renderPreview();
}

// ─── Directory navigation ─────────────────────────────────────────────────────

function loadDir(dirPath, selectName = null) {
  const { entries, error } = listDirectory(dirPath, state.showHidden);

  if (error) {
    showMsg(`Cannot open: ${error}`, 'error');
    return false;
  }

  state.cwd = dirPath;
  state.entries = entries;
  state.searchMode = false;
  state.searchQuery = '';
  state.filtered = [...entries];

  if (selectName) {
    const idx = entries.findIndex(e => e.name === selectName);
    state.selectedIdx = idx >= 0 ? idx : 0;
  } else {
    state.selectedIdx = 0;
  }

  fullRender();
  return true;
}

function moveSelection(delta) {
  if (state.filtered.length === 0) return;
  state.selectedIdx = Math.max(0, Math.min(state.filtered.length - 1, state.selectedIdx + delta));
  renderList();
  renderPreview();
}

// ─── Editable extensions ──────────────────────────────────────────────────────

const EDITABLE_EXTS = new Set([
  'txt', 'md', 'markdown', 'rst', 'log',
  'js', 'mjs', 'cjs', 'ts', 'jsx', 'tsx', 'vue', 'svelte',
  'css', 'scss', 'sass', 'less',
  'html', 'htm', 'xml', 'svg',
  'yaml', 'yml', 'toml', 'ini', 'cfg', 'conf', 'env',
  'sh', 'bash', 'zsh', 'fish',
  'py', 'rb', 'go', 'rs', 'java', 'c', 'cpp', 'h', 'hpp',
  'cs', 'php', 'swift', 'kt', 'lua', 'r',
  'sql', 'graphql', 'gql', 'json',
  'dockerfile', 'makefile', 'gitignore', 'gitattributes', 'editorconfig',
  'csv', 'tsv',
]);

function canEdit(entry) {
  if (entry.isDirectory) return false;
  const ext = path.extname(entry.name).slice(1).toLowerCase();
  return EDITABLE_EXTS.has(ext) || !ext;
}

function openSelected() {
  const entry = state.filtered[state.selectedIdx];
  if (!entry) return;

  if (entry.isDirectory) {
    loadDir(entry.path);
  } else if (canEdit(entry)) {
    openInEditor(entry);
  } else {
    openWithSystem(entry);
  }
}

/**
 * Spawn $EDITOR (or nano) in the foreground, suspending blessed while it runs.
 * When the editor exits, drift resumes and refreshes.
 */
function openInEditor(entry) {
  const cfg = loadConfig();
  const editorCmd = cfg.editor.command || process.env.EDITOR || process.env.VISUAL || 'nano';

  // Suspend blessed — restore normal terminal; lock keypress handler
  state.editorOpen = true;
  screen.leave();

  const child = spawn(editorCmd, [entry.path], {
    stdio: 'inherit',
    env: process.env,
    shell: false,
  });

  function resume(err) {
    // Re-enter blessed alternate buffer; unlock keypress handler
    screen.enter();
    screen.alloc();
    state.editorOpen = false;
    // Reload dir so file changes/timestamps reflect
    loadDir(state.cwd, entry.name);
    if (err) showMsg(`Editor error: ${err.message}`, 'error');
  }

  child.on('close', () => resume(null));
  child.on('error', err => {
    // e.g. editor not found — try falling back to nano
    if (editorCmd !== 'nano') {
      const fallback = spawn('nano', [entry.path], {
        stdio: 'inherit',
        env: process.env,
        shell: false,
      });
      fallback.on('close', () => resume(null));
      fallback.on('error', e2 => resume(e2));
    } else {
      resume(err);
    }
  });
}

function openWithSystem(entry) {
  const p = entry.path;
  if (process.platform === 'darwin') {
    exec(`open "${p}"`, err => {
      if (err) showMsg(`Cannot open: ${err.message}`, 'error');
    });
  } else if (process.platform === 'linux') {
    exec(`xdg-open "${p}" 2>/dev/null`, err => {
      if (err) showMsg('Cannot open binary file (no system opener)', 'error');
    });
  } else {
    showMsg('No system opener available for this file type', 'info');
  }
}

// ─── Export / Convert ─────────────────────────────────────────────────────────

function opExportAs() {
  const entry = state.filtered[state.selectedIdx];
  if (!entry || entry.isDirectory) {
    showMsg('Select a file to export', 'error');
    return;
  }

  startInput('Export as (new filename)', entry.name, newName => {
    if (!newName || newName === entry.name) return;
    const destExt = path.extname(newName).slice(1).toLowerCase();
    const dest = path.join(state.cwd, newName);

    if (destExt === 'pdf') {
      exportToPdf(entry.path, dest);
    } else {
      // Text-to-text: copy content to new filename
      const res = copyEntry(entry.path, dest);
      if (res.success) {
        showMsg(`Exported as "${newName}"`, 'success');
        loadDir(state.cwd, newName);
      } else {
        showMsg(`Export failed: ${res.error}`, 'error');
      }
    }
  });
}

function exportToPdf(srcPath, destPath) {
  showMsg('Converting to PDF…', 'info', 10000);
  exec('which pandoc', pandocErr => {
    if (pandocErr) {
      showMsg('PDF export needs pandoc — run: sudo apt install pandoc', 'error');
      return;
    }
    exec(`pandoc "${srcPath}" -o "${destPath}"`, err => {
      if (err) {
        showMsg(`PDF export failed: ${err.message}`, 'error');
      } else {
        showMsg(`Exported as "${path.basename(destPath)}"`, 'success');
        loadDir(state.cwd, path.basename(destPath));
      }
    });
  });
}

function goUp() {
  const parent = path.dirname(state.cwd);
  if (parent === state.cwd) return; // already at root
  const fromName = path.basename(state.cwd);
  loadDir(parent, fromName);
}

// ─── Search ───────────────────────────────────────────────────────────────────

function enterSearch() {
  state.searchMode = true;
  state.searchQuery = '';
  state.filtered = [...state.entries];
  state.selectedIdx = 0;
  renderHints();
  renderList();
  renderPreview();
}

function exitSearch(keep = false) {
  state.searchMode = false;
  if (!keep) {
    state.searchQuery = '';
    state.filtered = [...state.entries];
    state.selectedIdx = 0;
  }
  renderHints();
  renderList();
  renderPreview();
}

function applySearch() {
  const q = state.searchQuery.toLowerCase();
  state.filtered = q
    ? state.entries.filter(e => fuzzyMatch(e.name.toLowerCase(), q))
    : [...state.entries];
  state.selectedIdx = 0;
  renderHints();
  renderList();
  renderPreview();
}

function fuzzyMatch(str, pattern) {
  let si = 0;
  for (let pi = 0; pi < pattern.length; pi++) {
    const idx = str.indexOf(pattern[pi], si);
    if (idx === -1) return false;
    si = idx + 1;
  }
  return true;
}

// ─── Inline input prompt ──────────────────────────────────────────────────────

function startInput(prompt, defaultVal, cb) {
  state.inputMode = { prompt, value: defaultVal || '', callback: cb };
  renderInputPrompt();
}

function finishInput(cancelled = false) {
  const { value, callback } = state.inputMode;
  state.inputMode = null;
  clearMsg();
  callback(cancelled ? null : value.trim());
}

// ─── Confirm dialog ───────────────────────────────────────────────────────────

function startConfirm(message, cb) {
  state.confirmMode = { message, callback: cb };
  renderConfirm();
}

function finishConfirm(yes) {
  const cb = state.confirmMode.callback;
  state.confirmMode = null;
  clearMsg();
  cb(yes);
}

// ─── File operations ──────────────────────────────────────────────────────────

function opDelete() {
  const entry = state.filtered[state.selectedIdx];
  if (!entry) return;
  startConfirm(`Delete "${entry.name}"?`, yes => {
    if (!yes) { showMsg('Cancelled'); return; }
    const res = deleteEntry(entry.path);
    if (res.success) {
      showMsg(`Deleted "${entry.name}"`, 'success');
      loadDir(state.cwd);
    } else {
      showMsg(`Error: ${res.error}`, 'error');
    }
  });
}

function opRename() {
  const entry = state.filtered[state.selectedIdx];
  if (!entry) return;
  startInput('Rename to', entry.name, newName => {
    if (!newName || newName === entry.name) return;
    const dest = path.join(state.cwd, newName);
    const res = renameEntry(entry.path, dest);
    if (res.success) {
      showMsg(`Renamed to "${newName}"`, 'success');
      loadDir(state.cwd, newName);
    } else {
      showMsg(`Error: ${res.error}`, 'error');
    }
  });
}

function opCopy() {
  const entry = state.filtered[state.selectedIdx];
  if (!entry) return;
  state.clipboard = { srcPath: entry.path, op: 'copy' };
  showMsg(`Copied "${entry.name}" — press p to paste`, 'success');
  renderHeader();
}

function opCut() {
  const entry = state.filtered[state.selectedIdx];
  if (!entry) return;
  state.clipboard = { srcPath: entry.path, op: 'cut' };
  showMsg(`Cut "${entry.name}" — press p to paste`, 'info');
  renderHeader();
}

function opPaste() {
  if (!state.clipboard) { showMsg('Nothing in clipboard', 'error'); return; }
  const { srcPath, op } = state.clipboard;
  const baseName = path.basename(srcPath);
  let dest = path.join(state.cwd, baseName);

  // avoid collision: append _copy if pasting into same directory
  if (srcPath === dest && op === 'copy') {
    const ext = path.extname(baseName);
    const base = path.basename(baseName, ext);
    dest = path.join(state.cwd, `${base}_copy${ext}`);
  }

  const res = op === 'copy' ? copyEntry(srcPath, dest) : moveEntry(srcPath, dest);

  if (res.success) {
    if (op === 'cut') state.clipboard = null;
    showMsg(`Pasted "${path.basename(dest)}"`, 'success');
    loadDir(state.cwd, path.basename(dest));
    renderHeader();
  } else {
    showMsg(`Error: ${res.error}`, 'error');
  }
}

function opNewFile() {
  startInput('New file name', '', name => {
    if (!name) return;
    const res = createFile(path.join(state.cwd, name));
    if (res.success) {
      showMsg(`Created "${name}"`, 'success');
      loadDir(state.cwd, name);
    } else {
      showMsg(`Error: ${res.error}`, 'error');
    }
  });
}

function opNewDir() {
  startInput('New folder name', '', name => {
    if (!name) return;
    const res = createDirectory(path.join(state.cwd, name));
    if (res.success) {
      showMsg(`Created folder "${name}"`, 'success');
      loadDir(state.cwd, name);
    } else {
      showMsg(`Error: ${res.error}`, 'error');
    }
  });
}

// ─── Tools panel ──────────────────────────────────────────────────────────────

function enterToolsMode() {
  state.toolsMode = true;
  state.toolRows = flatList();
  state.toolIdx = state.toolRows.findIndex(r => r.type === 'tool');
  if (state.toolIdx < 0) state.toolIdx = 0;
  state.toolOutput = '{gray-fg}Select a tool and press Enter to run it.{/gray-fg}';
  clearToolRefresh();
  renderToolsPanel();
}

function exitToolsMode() {
  clearToolRefresh();
  state.toolsMode = false;
  fullRender();
}

function clearToolRefresh() {
  if (state.toolRefreshTimer) {
    clearTimeout(state.toolRefreshTimer);
    state.toolRefreshTimer = null;
  }
}

function moveToolCursor(delta) {
  let next = state.toolIdx + delta;
  while (next >= 0 && next < state.toolRows.length) {
    if (state.toolRows[next].type === 'tool') {
      state.toolIdx = next;
      renderToolList();
      // show last output or placeholder for new selection
      state.toolOutput = '{gray-fg}Press Enter to run this tool.{/gray-fg}';
      renderToolOutput();
      return;
    }
    next += delta;
  }
}

function runSelectedTool(arg) {
  const row = state.toolRows[state.toolIdx];
  if (!row || row.type !== 'tool') return;

  if (row.needsArg && !arg) {
    // prompt for the argument first
    startInput(row.argPrompt || 'Argument', '', value => {
      if (value !== null) runSelectedTool(value);
    });
    return;
  }

  clearToolRefresh();
  state.toolRunning = true;
  state.toolOutput = '{gray-fg}Running…{/gray-fg}';
  renderToolOutput();

  const ctx = {
    cwd: state.cwd,
    selectedFile: state.filtered[state.selectedIdx]
      ? state.filtered[state.selectedIdx].path
      : null,
  };

  runTool(row.id, arg || null, ctx).then(output => {
    state.toolRunning = false;
    state.toolOutput = output;
    renderToolOutput();

    // schedule auto-refresh if the tool supports it
    if (row.autoRefresh) {
      state.toolRefreshTimer = setTimeout(() => {
        if (state.toolsMode && state.toolRows[state.toolIdx] &&
            state.toolRows[state.toolIdx].id === row.id) {
          runSelectedTool(arg);
        }
      }, row.autoRefresh);
    }
  }).catch(err => {
    state.toolRunning = false;
    state.toolOutput = `{red-fg}Error: ${escTag(err.message)}{/red-fg}`;
    renderToolOutput();
  });
}

function renderToolList() {
  const lines = state.toolRows.map((row, i) => {
    if (row.type === 'category') {
      return `\n {cyan-fg}{bold}${escTag(row.label)}{/bold}{/cyan-fg}`;
    }
    const sel = i === state.toolIdx;
    const icon = state.toolRunning && sel ? '{yellow-fg}⟳{/yellow-fg}' : ' ';
    if (sel) {
      return `{black-fg}{white-bg} ${icon} ${escTag(row.label)} {/white-bg}{/black-fg}`;
    }
    return `   ${escTag(row.label)}`;
  });

  listBox.setContent(lines.join('\n'));
  const visibleRows = Math.max(1, (listBox.height || 20) - 2);
  listBox.scrollTo(Math.max(0, state.toolIdx - Math.floor(visibleRows / 2)));
  screen.render();
}

function renderToolOutput() {
  previewBox.setContent(state.toolOutput || '');
  previewBox.scrollTo(0);
  screen.render();
}

function renderToolHints() {
  hintBar.setContent(
    '  {bold}↑↓{/bold} select  ' +
    '{bold}Enter{/bold} run  ' +
    '{bold}r{/bold} re-run  ' +
    '{bold}Esc/t{/bold} back to files  ' +
    '{bold}q{/bold} quit'
  );
}

function renderToolsPanel() {
  renderHeader();
  renderToolHints();
  renderToolList();
  renderToolOutput();
}

// ─── Keyboard handling ────────────────────────────────────────────────────────

screen.on('keypress', (ch, key) => {
  // ── editor lock ─────────────────────────────────────────────────────────────
  // While an external editor is open, blessed must not process any keys —
  // all input belongs to the editor process.
  if (state.editorOpen) return;

  // ── confirm mode ────────────────────────────────────────────────────────────
  if (state.confirmMode) {
    if (key.name === 'y') finishConfirm(true);
    else finishConfirm(false);
    return;
  }

  // ── input prompt mode ────────────────────────────────────────────────────────
  if (state.inputMode) {
    if (key.name === 'enter') {
      finishInput(false);
    } else if (key.name === 'escape') {
      finishInput(true);
    } else if (key.name === 'backspace') {
      state.inputMode.value = state.inputMode.value.slice(0, -1);
      renderInputPrompt();
    } else if (ch && ch.length === 1 && !key.ctrl && !key.meta) {
      state.inputMode.value += ch;
      renderInputPrompt();
    }
    return;
  }

  // ── tools mode ───────────────────────────────────────────────────────────────
  if (state.toolsMode) {
    if (key.ctrl && key.name === 'c') { clearToolRefresh(); process.exit(0); }
    switch (key.name) {
      case 'up':   case 'k':  moveToolCursor(-1); break;
      case 'down': case 'j':  moveToolCursor(1);  break;
      case 'pageup':          moveToolCursor(-10); break;
      case 'pagedown':        moveToolCursor(10);  break;
      case 'enter':           runSelectedTool();   break;
      case 'r':               runSelectedTool();   break;
      case 'escape': case 't': exitToolsMode();    break;
      case 'q':               clearToolRefresh(); process.exit(0); break;
    }
    return;
  }

  // ── search mode ──────────────────────────────────────────────────────────────
  if (state.searchMode) {
    if (key.name === 'escape') {
      exitSearch(false);
    } else if (key.name === 'enter') {
      exitSearch(true); // keep filtered results + current selection
    } else if (key.name === 'backspace') {
      state.searchQuery = state.searchQuery.slice(0, -1);
      applySearch();
    } else if (key.name === 'up') {
      moveSelection(-1);
    } else if (key.name === 'down') {
      moveSelection(1);
    } else if (ch && ch.length === 1 && !key.ctrl && !key.meta) {
      state.searchQuery += ch;
      applySearch();
    }
    return;
  }

  // ── normal mode ──────────────────────────────────────────────────────────────
  if (key.ctrl && key.name === 'c') process.exit(0);

  switch (key.name) {
    case 'up':    case 'k':  moveSelection(-1);  break;
    case 'down':  case 'j':  moveSelection(1);   break;
    case 'pageup':           moveSelection(-10); break;
    case 'pagedown':         moveSelection(10);  break;
    case 'g':                moveSelection(-Infinity); break;
    case 'G':                moveSelection(Infinity);  break;
    case 'enter': case 'l':  openSelected();     break;
    case 'backspace': case 'h': goUp();          break;
    case '/':    enterSearch();  break;
    case 'e':    opExportAs();   break;
    case 'd':    opDelete();     break;
    case 'r':    opRename();     break;
    case 'c':    opCopy();       break;
    case 'm':    opCut();        break;
    case 'x':    opCut();        break;
    case 'p':    opPaste();      break;
    case 'n':
      if (ch === 'N') opNewDir();
      else opNewFile();
      break;
    case 'N':    opNewDir();     break;
    case '.':
      state.showHidden = !state.showHidden;
      loadDir(state.cwd);
      showMsg(`Hidden files ${state.showHidden ? 'shown' : 'hidden'}`, 'info');
      break;
    case 't':    enterToolsMode(); break;
    case 'q':
      process.exit(0);
  }
});

// handle Ctrl-C at screen level too
screen.key(['C-c'], () => process.exit(0));

// rerender on terminal resize
screen.on('resize', () => {
  setTimeout(fullRender, 50);
});

// ─── Utilities ────────────────────────────────────────────────────────────────

function escTag(str) {
  return String(str).replace(/\{/g, '\\{');
}

// ─── Launch sequence ──────────────────────────────────────────────────────────

const LOGO = [
  '',
  '   {cyan-fg}{bold}██████╗ ██████╗ ██╗███████╗████████╗{/bold}{/cyan-fg}',
  '   {cyan-fg}{bold}██╔══██╗██╔══██╗██║██╔════╝╚══██╔══╝{/bold}{/cyan-fg}',
  '   {cyan-fg}{bold}██║  ██║██████╔╝██║█████╗     ██║{/bold}{/cyan-fg}',
  '   {cyan-fg}{bold}██║  ██║██╔══██╗██║██╔══╝     ██║{/bold}{/cyan-fg}',
  '   {cyan-fg}{bold}██████╔╝██║  ██║██║██║        ██║{/bold}{/cyan-fg}',
  '   {cyan-fg}{bold}╚═════╝ ╚═╝  ╚═╝╚═╝╚═╝        ╚═╝{/bold}{/cyan-fg}',
  '',
  '   {gray-fg}fast terminal file explorer{/gray-fg}',
  '',
].join('\n');

function showSplash() {
  return new Promise(resolve => {
    const splash = blessed.box({
      parent: screen,
      top: 'center', left: 'center',
      width: 44, height: 12,
      tags: true,
      content: LOGO,
      border: { type: 'line' },
      style: { border: { fg: 'cyan' }, bg: 'black' },
    });
    screen.render();
    setTimeout(() => {
      splash.destroy();
      resolve();
    }, 750);
  });
}

async function main() {
  // Apply config defaults
  const cfg = loadConfig();
  state.showHidden = cfg.showHidden || false;

  await showSplash();
  loadDir(state.cwd);
}

main().catch(err => {
  // graceful crash: restore terminal then print error
  try { screen.destroy(); } catch (_) {}
  console.error('drift crashed:', err.message);
  process.exit(1);
});
