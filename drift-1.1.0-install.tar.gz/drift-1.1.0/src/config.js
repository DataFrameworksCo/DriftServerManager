'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');

const CONFIG_PATH = path.join(os.homedir(), '.drift-config.json');

const DEFAULTS = {
  // ── General ────────────────────────────────────────────────────────────────
  theme: 'default',       // 'default' | 'light'
  showHidden: false,
  confirmDelete: true,    // ask before deleting files
  sortBy: 'name',         // 'name' | 'size' | 'modified'
  sortDir: 'asc',         // 'asc' | 'desc'
  showSizes: true,        // show file sizes in list

  // ── Editor ─────────────────────────────────────────────────────────────────
  editor: {
    command: '',           // override $EDITOR, e.g. "nano" or "vim"
    tabSize: 2,
    wordWrap: false,
    lineNumbers: true,
  },

  // ── Stored credentials (keys) ──────────────────────────────────────────────
  // { [name]: value }  — stored in plain text, treat like a password manager
  keys: {},

  // ── Web server ─────────────────────────────────────────────────────────────
  web: {
    enabled: false,        // informational — actual start is via `drift --web`
    port: 7473,
    password: '',          // empty = no auth required
    rootDir: os.homedir(), // restrict web access to this dir and below
    readOnly: false,       // disallow write ops over the web
    allowUpload: true,     // allow file uploads via web UI
    showHidden: false,     // show hidden files in web file tree
  },
};

let _cache = null;

function loadConfig() {
  if (_cache) return _cache;

  try {
    if (fs.existsSync(CONFIG_PATH)) {
      const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
      const user = JSON.parse(raw);
      _cache = deepMerge(DEFAULTS, user);
    } else {
      _cache = deepMerge(DEFAULTS, {});
    }
  } catch (_) {
    _cache = deepMerge(DEFAULTS, {});
  }

  // resolve ~ in rootDir
  if (typeof _cache.web.rootDir === 'string' && _cache.web.rootDir.startsWith('~')) {
    _cache.web.rootDir = path.join(os.homedir(), _cache.web.rootDir.slice(1));
  }

  return _cache;
}

function saveConfig(updates) {
  const current = loadConfig();
  const merged = deepMerge(current, updates);
  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(merged, null, 2) + '\n', 'utf8');
    _cache = merged;
    return { success: true, path: CONFIG_PATH };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

function resetCache() {
  _cache = null;
}

function deepMerge(base, override) {
  const out = Object.assign({}, base);
  for (const key of Object.keys(override || {})) {
    if (
      override[key] !== null &&
      typeof override[key] === 'object' &&
      !Array.isArray(override[key]) &&
      typeof base[key] === 'object' &&
      base[key] !== null
    ) {
      out[key] = deepMerge(base[key], override[key]);
    } else if (override[key] !== undefined) {
      out[key] = override[key];
    }
  }
  return out;
}

module.exports = { loadConfig, saveConfig, resetCache, CONFIG_PATH, DEFAULTS };
